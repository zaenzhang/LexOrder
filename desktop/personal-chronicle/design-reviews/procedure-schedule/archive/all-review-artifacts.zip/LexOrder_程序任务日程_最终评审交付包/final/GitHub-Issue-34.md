# GitHub Issue #34

**标题：** [Desktop][Chronicle] 程序管理与当前程序任务工作区重构（个人版）  
**状态：** Open  
**链接：** https://github.com/zaenzhang/LexOrder/issues/34

Issue 正文已提交到 GitHub，包含：
- 程序总览 → 当前程序任务工作区两层页面结构
- 新建程序、新建任务和任务详情的页面交互
- Procedure / Stage / Task / Deadline / Hearing / Intake 业务边界
- 已终结程序、历史补录、上海时区和责任处置校验
- 服务端待复核缺口
- 验收标准、非目标和单工作区单写者要求

/*
 * In-place refinement for the original LexOrder document lifecycle preview.
 * The React app remains the source of truth for business actions and detail
 * rendering. This layer only reorganizes navigation/list/inspector and adds
 * a full-page template wizard that writes the same synthetic document shape.
 */
(() => {
  const STORAGE_KEY = 'lex-docs-95-v3';
  const SCENE_KEY = 'lex-docs-scene-v3';
  // One shared case-navigation hierarchy. Drafting, review, sealing and
  // delivery are object types inside the single 文书与交付 workspace.
  const sections = [
    ['overview', '概览', 'grid'],
    ['tasks', '程序与任务', 'calendar'],
    ['materials', '材料与卷宗', 'folder'],
    ['evidence', '事实与研究', 'list'],
    ['delivery', '文书与交付', 'file'],
    ['records', '办理记录', 'clock'],
    ['finance', '案件财务', 'wallet'],
    ['archive', '结案与归档', 'archive'],
  ];
  const labels = {
    DRAFT: '草稿', PENDING_REVIEW: '待复核', APPROVED: '已批准', FILED: '已入卷',
    PREPARED: '已冻结', EXPORTED: '已导出，未登记发送', SENT: '已登记送出',
    RECEIVED: '收悉', REPLIED: '客户回复', CONTENT_CONFIRMED: '客户确认内容',
    SEND_CORRECTION: '发送更正', PENDING: '待决定', STAMPED: '已登记实盖',
    CANCELLED: '已撤销', REJECTED: '已驳回', UNAVAILABLE: '记录不可查看',
  };
  const colors = {
    DRAFT: 'neutral', PENDING_REVIEW: 'amber', APPROVED: 'green', FILED: 'green',
    PREPARED: 'neutral', EXPORTED: 'blue', SENT: 'blue', RECEIVED: 'green',
    PENDING: 'amber', STAMPED: 'green', REJECTED: 'neutral', CANCELLED: 'neutral',
    UNAVAILABLE: 'neutral',
  };

  const styleText = `
    .sidebar{overflow-y:auto;overscroll-behavior:contain}
    .sidebar .context{display:none!important}
    .sidebar .navitem.active{background:var(--sidebar-accent);color:var(--sidebar-accent-foreground);font-weight:650}
    #lex-global-nav,#lex-matter-nav,#lex-global-footer{display:grid;gap:3px}
    #lex-global-nav{margin:2px 0 13px;padding-bottom:12px;border-bottom:1px solid var(--border)}
    .lex-nav-caption{padding:8px 10px 5px;color:var(--muted-foreground);font-size:11px;font-weight:650;letter-spacing:.04em}
    .lex-global-item{display:flex;align-items:center;gap:9px;width:100%;min-height:33px;padding:7px 10px;border-radius:7px;text-align:left;color:var(--muted-foreground);font-size:13px}
    .lex-global-item svg{width:16px;height:16px;flex:none}
    .lex-global-item.active{background:var(--sidebar-accent);color:var(--sidebar-accent-foreground);font-weight:650}
    .lex-global-item:disabled{opacity:.62;cursor:default}
    .lex-global-item:disabled:hover{background:transparent}
    #lex-matter-nav{display:grid;gap:3px}
    #lex-matter-nav .navitem{width:100%;font-size:13px;line-height:1.35}
    #lex-matter-nav .navitem svg{flex:none}
    #lex-case-meta{display:grid;gap:3px;padding:4px 10px 10px}
    #lex-case-meta strong{font-size:12px;font-weight:650;color:var(--foreground)}
    #lex-case-meta small{font-size:10px;color:var(--muted-foreground);font-family:ui-monospace,monospace}
    #lex-global-footer{padding-top:10px;margin-top:10px;border-top:1px solid var(--border)}
    #lex-case-switcher{display:flex;align-items:center;gap:7px;margin-left:auto;margin-right:12px;white-space:nowrap}
    #lex-case-switcher span{font-size:11px;color:var(--muted-foreground)}
    #lex-case-switcher select{height:31px;max-width:190px;border:1px solid var(--border);border-radius:7px;background:var(--card);padding:4px 24px 4px 8px;color:var(--foreground);font-size:12px}
    @media(max-width:780px){#lex-global-nav,#lex-matter-nav,#lex-global-footer,#lex-case-meta{display:none!important}#lex-case-switcher{margin-left:auto}#lex-case-switcher span{display:none}}
    .content .tabs,.content .sectionhead{display:none!important}
    .lex-doc-actions{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:14px 0 18px}
    .lex-doc-actions .btn{min-height:34px}
    .board{grid-template-columns:var(--lex-list-width,300px) 5px minmax(0,1fr) 5px var(--lex-inspector-width,245px);min-height:calc(100vh - 215px);box-shadow:var(--surface-shadow);align-items:stretch}
    .queue{border-right:1px solid var(--border);padding:14px 0;min-height:480px;overflow:auto}
    .queue .qhead{margin:0 14px 12px;display:flex;align-items:center;justify-content:space-between}
    .queue .tools{margin:0 12px 12px;display:flex;align-items:center;gap:7px}
    .queue .search{flex:1;min-width:0}
    .queue .search input{min-width:0}
    .lex-select{height:33px;min-width:72px;max-width:116px;padding:4px 22px 4px 8px;border:1px solid var(--border);border-radius:7px;background:var(--card);font-size:12px}
    .queue .row{padding:12px 11px;gap:9px;color:var(--foreground);text-decoration:none}
    .queue .row.sel{background:var(--accent);border-left-color:var(--primary)}
    .queue .row:hover{background:var(--muted)}
    .queue .rowmain{min-width:0;flex:1;display:grid;gap:2px}
    .queue .rowmain strong{font-size:13px;overflow-wrap:anywhere}
    .queue .rowmain small{font-size:11px;color:var(--muted-foreground);line-height:1.45}
    .queue .fileIcon{width:30px;height:32px;display:grid;place-items:center;flex:none}
    .lex-pill{display:inline-flex;align-items:center;white-space:nowrap;font-size:11px;line-height:1.4;padding:3px 7px;border-radius:999px;background:var(--muted);color:var(--muted-foreground)}
    .lex-pill.green{background:color-mix(in oklch,var(--success) 13%,var(--card));color:var(--success)}
    .lex-pill.amber{background:color-mix(in oklch,var(--warning) 16%,var(--card));color:var(--warning-foreground)}
    .lex-pill.blue{background:color-mix(in oklch,var(--info) 13%,var(--card));color:var(--info)}
    .detail{border-right:1px solid var(--border);padding:22px clamp(16px,2vw,30px);min-width:0;min-height:480px;overflow-wrap:anywhere}
    .lex-resize-handle{width:5px;cursor:col-resize;touch-action:none;position:relative;z-index:2;background:transparent;outline:none}
    .lex-resize-handle:after{content:"";position:absolute;top:0;bottom:0;left:2px;width:1px;background:var(--border)}
    .lex-resize-handle:hover:after,.lex-resize-handle:focus-visible:after{left:1px;width:3px;background:var(--primary)}
    .lex-resize-handle:focus-visible{outline:2px solid var(--ring);outline-offset:-1px}
    .queue .row[aria-current="page"]{background:var(--accent);border-left-color:var(--primary)}
    .queue .row:focus-visible{outline:2px solid var(--ring);outline-offset:-2px}
    .inspector{min-width:0;background:var(--card);overflow:auto;padding:0 15px 18px}
    .inspectorHead,.lex-inspector-head{position:sticky;top:0;z-index:1;background:var(--card);padding:15px 0 12px;border-bottom:1px solid var(--border);font-weight:650;font-size:14px}
    .inspector section,.lex-template-inspector section{display:grid;gap:5px;padding:13px 0;border-bottom:1px solid var(--border);font-size:13px;overflow-wrap:anywhere}
    .inspector section small,.lex-template-inspector section small{font-size:11px;color:var(--muted-foreground)}
    .inspector section strong,.lex-template-inspector section strong{font-weight:600}
    .inspector section p,.lex-template-inspector section p{font-size:12px;line-height:1.55;color:var(--muted-foreground)}
    .inspector section a{font-size:12px;line-height:1.5}
    .lex-error-state{grid-column:1/-1;min-height:430px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;text-align:center;color:var(--muted-foreground)}
    .lex-error-state h2{font-size:21px;color:var(--foreground)}
    .lex-error-state p{font-size:13px}
    .lex-section-placeholder{max-width:680px;min-height:390px;margin:20px auto;display:flex;flex-direction:column;align-items:flex-start;justify-content:center;gap:12px;color:var(--muted-foreground)}
    .lex-section-placeholder h2{font-size:22px;color:var(--foreground)}
    .lex-section-placeholder p{font-size:14px;line-height:1.7}
    .lex-placeholder-icon{width:40px;height:40px;display:grid;place-items:center;border:1px solid var(--border);border-radius:9px;background:var(--card)}
    .lex-template-overlay{position:fixed;z-index:80;inset:55px 0 0 230px;overflow:auto;background:var(--background);padding:28px clamp(20px,3vw,44px) 22px}
    .lex-template-page{max-width:1360px;margin:0 auto;display:grid;gap:22px;min-height:100%}
    .lex-template-page>header{display:flex;align-items:flex-start;justify-content:space-between;gap:20px}
    .lex-template-page>header>div{display:grid;gap:5px}
    .lex-template-page>header p{font-size:12px;color:var(--muted-foreground)}
    .lex-template-page>header h1{font-size:27px;letter-spacing:-.7px;line-height:1.3}
    .lex-template-page>header span{font-size:13px;color:var(--muted-foreground)}
    .lex-stepper{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:0;list-style:none;margin:0;padding:0;border-bottom:1px solid var(--border)}
    .lex-stepper li{display:flex;align-items:center;gap:9px;padding:0 0 13px;color:var(--muted-foreground);font-size:13px;position:relative}
    .lex-stepper li:after{content:"";position:absolute;bottom:-1px;left:0;right:12px;height:2px;background:transparent}
    .lex-stepper li.current{color:var(--foreground);font-weight:650}
    .lex-stepper li.current:after,.lex-stepper li.done:after{background:var(--primary)}
    .lex-stepper li span{width:24px;height:24px;border-radius:50%;display:grid;place-items:center;border:1px solid var(--border);background:var(--card);font-size:12px}
    .lex-stepper li.current span,.lex-stepper li.done span{background:var(--primary);border-color:var(--primary);color:var(--primary-foreground)}
    .lex-template-layout{display:grid;grid-template-columns:minmax(0,1fr) 265px;gap:24px;align-items:start}
    .lex-template-main{min-width:0;display:grid;gap:18px;padding:4px 0}
    .lex-template-main h2{font-size:19px;font-weight:650}
    .lex-template-choices{display:grid;gap:8px;max-width:820px}
    .lex-template-choice{display:flex;align-items:center;gap:12px;text-align:left;padding:14px;border:1px solid var(--border);border-radius:9px;background:var(--card);width:100%;min-width:0;color:var(--foreground)}
    .lex-template-choice:hover{background:var(--muted)}
    .lex-template-choice.selected{border-color:var(--primary);background:var(--accent);box-shadow:0 0 0 1px color-mix(in oklch,var(--primary) 15%,transparent)}
    .lex-template-choice>span:nth-child(2){display:grid;gap:3px;flex:1;min-width:0}
    .lex-template-choice strong{font-size:14px;font-weight:600}
    .lex-template-choice small{font-size:12px;color:var(--muted-foreground)}
    .lex-template-choice em{font-style:normal;font-size:11px;color:var(--primary)}
    .lex-file-icon{width:32px;height:34px;display:grid;place-items:center;border:1px solid var(--border);border-radius:7px;color:var(--muted-foreground)}
    .lex-form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:15px;max-width:860px}
    .lex-form-grid label{display:grid;gap:6px;font-size:13px;font-weight:550}
    .lex-form-grid .wide{grid-column:1/-1}
    .lex-form-grid input,.lex-form-grid select,.lex-form-grid textarea{width:100%;border:1px solid var(--border);border-radius:7px;background:var(--card);padding:8px 10px;font-size:14px;color:var(--foreground)}
    .lex-form-grid textarea{min-height:160px;resize:vertical;line-height:1.6}
    .lex-source-picker{display:grid;gap:8px;padding:12px;border:1px solid var(--border);border-radius:8px;background:var(--card)}
    .lex-source-picker>strong{font-size:13px}
    .lex-source-picker>p{font-size:12px;color:var(--muted-foreground)}
    .lex-source-picker>div{display:flex;gap:14px;flex-wrap:wrap}
    .lex-source-picker label{display:flex;align-items:center;gap:6px;font-size:12px;font-weight:450}
    .lex-source-picker input{width:auto;accent-color:var(--primary)}
    .lex-form-grid input:focus,.lex-form-grid select:focus,.lex-form-grid textarea:focus{outline:2px solid var(--ring);outline-offset:2px}
    .lex-template-main .fieldHint{font-size:12px;color:var(--muted-foreground)}
    .lex-template-inspector{border:1px solid var(--border);border-radius:9px;background:var(--card);padding:0 14px 8px}
    .lex-template-inspector section{padding:13px 0}
    .lex-review-summary{display:grid;gap:10px;border:1px solid var(--border);border-radius:9px;background:var(--card);padding:15px;max-width:860px}
    .lex-review-summary>div{display:grid;grid-template-columns:105px minmax(0,1fr);gap:8px;font-size:13px}
    .lex-review-summary small{color:var(--muted-foreground)}
    .lex-review-summary p{white-space:pre-wrap;line-height:1.6}
    .lex-confirmed{font-size:13px;color:var(--success);display:flex;align-items:center;gap:7px}
    .lex-check{display:flex;align-items:flex-start;gap:8px;font-size:13px}
    .lex-check input{margin-top:4px;accent-color:var(--primary)}
    .lex-template-page>footer{display:flex;align-items:center;justify-content:flex-end;gap:12px;border-top:1px solid var(--border);padding:14px 0 4px;margin-top:auto}
    .lex-template-page>footer span{margin-right:auto;font-size:12px;color:var(--muted-foreground)}
    .lex-template-page button:disabled{opacity:.45;cursor:not-allowed}
    .lex-discard-backdrop{position:fixed;inset:55px 0 0 230px;z-index:90;background:color-mix(in oklch,var(--foreground) 28%,transparent);display:grid;place-items:center;padding:20px}
    .lex-discard{width:min(420px,100%);border:1px solid var(--border);border-radius:12px;background:var(--card);padding:20px;box-shadow:var(--surface-shadow-raised);display:grid;gap:10px}
    .lex-discard p{font-size:13px;color:var(--muted-foreground)}
    .lex-discard>div{display:flex;justify-content:flex-end;gap:8px}
    @media(max-width:1250px){.board{grid-template-columns:var(--lex-list-width,250px) 5px minmax(0,1fr)}.lex-resize-inspector{display:none}.inspector{grid-column:1/-1;border-top:1px solid var(--border);display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:0 18px}.inspectorHead{grid-column:1/-1}.inspector section{padding:10px 0}.lex-template-layout{grid-template-columns:minmax(0,1fr) 235px}}
    @media(max-width:950px){.lex-template-layout{grid-template-columns:1fr}.lex-template-inspector{display:grid;grid-template-columns:1fr 1fr;gap:0 16px}.lex-template-inspector .lex-inspector-head{grid-column:1/-1}}
    @media(max-width:780px){.board{grid-template-columns:1fr}.lex-resize-handle{display:none}.queue{min-height:0;max-height:320px;border-right:0}.detail{min-height:0;border-right:0;border-top:1px solid var(--border)}.inspector{display:block;border-top:1px solid var(--border)}.lex-template-overlay{inset:80px 0 0 0;padding:18px}.lex-discard-backdrop{inset:80px 0 0 0}.lex-template-page>header{display:grid}.lex-stepper li{font-size:11px;gap:5px}.lex-stepper li span{width:22px;height:22px}.lex-form-grid{grid-template-columns:1fr}.lex-form-grid .wide{grid-column:auto}.lex-template-page>footer{position:sticky;bottom:0;background:var(--background)}}
  `;
  function installStyle() {
    if (document.getElementById('lexorder-ui-refinement')) return;
    const style = document.createElement('style');
    style.id = 'lexorder-ui-refinement';
    style.textContent = styleText;
    document.head.appendChild(style);
  }
  const caseInfo = {
    A: { code: 'CH-2026-001', name: '澄禾设备采购争议', client: '澄禾设备有限公司', opposing: '青岚供应链有限公司', third: '海川运输有限公司', procedures: ['一审 · 买卖合同纠纷', '保全 · 财产保全'], folders: ['工作成果', '诉讼文书', '客户交付'], sources: ['采购合同 V1', '交接清单 V1', '付款凭证 V1'], due: ['11月26日　提交证据目录', '11月27日　保全续期'] },
    B: { code: 'QL-2026-002', name: '青岚仓储交付争议', client: '青岚仓储有限公司', opposing: '澄禾设备有限公司', third: '北辰物流有限公司', procedures: ['仲裁 · 仓储合同争议', '保全执行 · 仓储物保全'], folders: ['工作成果', '仲裁文书', '客户交付'], sources: ['仓储合同 V1', '验收记录 V1', '签收回单 V1'], due: ['11月30日　核对仓储清单', '11月30日　保全核查'] },
  };
  const esc = value => String(value ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  const readDb = () => {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || null; }
    catch { return null; }
  };
  const scene = () => { try { return localStorage.getItem(SCENE_KEY) || 'normal'; } catch { return 'normal'; } };
  const parseRoute = () => {
    const hash = location.hash.slice(1);
    const [path, query = ''] = hash.split('?');
    const parts = path.split('/').filter(Boolean);
    const rawCase = parts[1] || 'A';
    const caseId = caseInfo[rawCase] ? rawCase : Object.keys(caseInfo).find(key => caseInfo[key].code === rawCase) || 'A';
    const section = parts[2] || 'review';
    const id = parts[3] || '';
    const event = parts[4] || '';
    const params = new URLSearchParams(query);
    if (params.get('delivery')) return { caseId, section: 'delivery', id: params.get('delivery'), event: params.get('deliveryEvent') || '' };
    if (params.get('document')) return { caseId, section: params.get('reviewIssue') ? 'review' : 'materials', id: params.get('document'), event: params.get('reviewIssue') || '' };
    if (params.get('deliveryDocument')) return { caseId, section: 'review', id: params.get('deliveryDocument'), event: '' };
    return { caseId, section, id, event };
  };
  const unique = (caseId, prefix) => `${caseId}-${prefix}-${crypto.randomUUID().slice(0, 8)}`;
  const statusOfPack = pack => pack.events.some(event => event.kind === 'SENT') ? 'SENT' : pack.events.some(event => event.kind === 'EXPORTED') ? 'EXPORTED' : 'PREPARED';
  const isWithdrawn = id => scene() === 'withdrawDoc' && id === `${parseRoute().caseId}-D01`;
  const isProofWithdrawn = id => scene() === 'withdrawProof' && id === `${parseRoute().caseId}-M01`;
  const navHash = (caseId, section, id = '', event = '') => `#/matters/${caseId}/${section}${id ? `/${id}` : ''}${event ? `/${event}` : ''}`;
  const navigate = (hash) => {
    const nextIndex = Number(history.state?.lexIndex ?? 0) + 1;
    history.pushState({ lexIndex: nextIndex }, '', hash);
    window.dispatchEvent(new PopStateEvent('popstate'));
  };
  const icon = type => {
    const paths = {
      grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
      folder: '<path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H10l2 2h6.5A2.5 2.5 0 0 1 21 9.5v8a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 3 17.5z"/><path d="M3 10h18"/>',
      list: '<path d="M8 6h13M8 12h13M8 18h13"/><path d="M3 6h.01M3 12h.01M3 18h.01"/>',
      book: '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v17H6.5A2.5 2.5 0 0 0 4 22z"/><path d="M4 5.5v16.5M8 7h8M8 11h8"/>',
      calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4M17 3v4M3 10h18M7 14h3M7 17h3"/>',
      file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h8"/>',
      clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
      wallet: '<rect x="3" y="5" width="18" height="15" rx="2"/><path d="M3 9h18M16 14h2"/>',
      stamp: '<rect x="4" y="14" width="16" height="7" rx="1"/><path d="M8 14V9a4 4 0 0 1 8 0v5M7 18h10"/>',
    };
    return `<svg aria-hidden="true" viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${paths[type] || paths.file}</svg>`;
  };
  const pill = status => `<span class="lex-pill ${colors[status] || 'neutral'}">${esc(labels[status] || status || '—')}</span>`;
  const findSelected = (db, route) => {
    const matter = db?.[route.caseId];
    if (!matter || !route.id) return {};
    return {
      doc: matter.docs.find(item => item.id === route.id),
      pack: matter.packs.find(item => item.id === route.id),
      seal: matter.seals.find(item => item.id === route.id),
      file: [...matter.docs, ...matter.files].find(item => item.id === route.id),
    };
  };
  const getWorkItems = (matter, caseId) => {
    const docs = matter.docs.filter(doc => !(scene() === 'withdrawDoc' && doc.id === `${caseId}-D01`)).map(doc => ({ kind: 'document', id: doc.id, title: doc.title, status: doc.status, version: doc.version, procedure: matter.procedures?.[doc.proc] || caseInfo[caseId].procedures[doc.proc] || '未指定程序', item: doc }));
    const packs = matter.packs.map(pack => ({ kind: 'delivery', id: pack.id, title: scene() === 'withdrawDoc' && pack.doc === `${caseId}-D01` ? '不可查看的清单' : pack.title, status: scene() === 'withdrawDoc' && pack.doc === `${caseId}-D01` ? 'UNAVAILABLE' : statusOfPack(pack), version: null, procedure: pack.recipient, item: pack }));
    const seals = matter.seals.map(seal => ({ kind: 'seal', id: seal.id, title: seal.title, status: seal.status, version: null, procedure: seal.note, item: seal }));
    return [...docs, ...seals, ...packs];
  };
  const state = { type: '全部', status: '全部', search: '', lastGroup: '', template: null, templateSnapshot: null, templateDirty: false, templateHistory: false, observer: null, timer: null, paneWidths: null };
  function sectionFor(route) {
    if (['drafts', 'review', 'delivery', 'seal'].includes(route.section)) return 'delivery';
    if (route.section === 'research') return 'evidence';
    if (route.section === 'template') return 'delivery';
    return sections.some(([key]) => key === route.section) ? route.section : 'delivery';
  }
  function ensureSidebar() {
    const sidebar = document.querySelector('.sidebar');
    if (!sidebar) return;
    const navgroup = sidebar.querySelector('.navgroup');
    const spacer = sidebar.querySelector('.spacer');
    if (!navgroup || !spacer) return;
    const brand = sidebar.querySelector('.brand');
    const legacyContext = sidebar.querySelector('.context');
    const existingNav = sidebar.querySelector('#lex-matter-nav');
    if (!existingNav) {
      const children = [...sidebar.children];
      const legacyImport = children.find(node => node.classList?.contains('navitem') && node.textContent.includes('工作区模板'));
      if (legacyImport) {
        legacyImport.classList.add('lex-legacy-import');
        legacyImport.style.display = 'none';
      }
      const scenesButton = children.find(node => node.classList?.contains('navitem') && node.textContent.includes('验收场景'));
      const userbox = sidebar.querySelector('.userbox');
      children.forEach(node => {
        if (node === brand || node === legacyContext || node === navgroup || node === spacer || node === scenesButton || node === userbox || node === legacyImport) return;
        if (node.parentNode === sidebar) node.remove();
      });
      if (legacyContext) legacyContext.style.display = 'none';

      const global = document.createElement('nav');
      global.id = 'lex-global-nav';
      global.setAttribute('aria-label', '全局导航');
      global.innerHTML = `<div class="lex-nav-caption">工作空间</div>
        <button type="button" class="lex-global-item" disabled>${icon('grid')}<span>今日工作台</span></button>
        <button type="button" class="lex-global-item" disabled>${icon('folder')}<span>案件总览</span></button>
        <button type="button" class="lex-global-item" disabled>${icon('users')}<span>客户与收案</span></button>
        <button type="button" class="lex-global-item" disabled>${icon('calendar')}<span>日程</span></button>
        <button type="button" class="lex-global-item active" aria-current="page">${icon('scale')}<span>办案事务</span></button>
        <button type="button" class="lex-global-item" disabled>${icon('wallet')}<span>全局财务</span></button>`;
      if (brand) brand.insertAdjacentElement('afterend', global);
      navgroup.textContent = '当前案件';
      const caseMeta = document.createElement('div');
      caseMeta.id = 'lex-case-meta';
      navgroup.insertAdjacentElement('afterend', caseMeta);
      const nav = document.createElement('div');
      nav.id = 'lex-matter-nav';
      nav.setAttribute('aria-label', '当前案件导航');
      sections.forEach(([key, label, glyph]) => {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'navitem';
        button.dataset.section = key;
        button.innerHTML = `${icon(glyph)}<span>${label}</span>`;
        button.addEventListener('click', () => navigateSection(key));
        nav.appendChild(button);
      });
      caseMeta.insertAdjacentElement('afterend', nav);
      const globalFooter = document.createElement('div');
      globalFooter.id = 'lex-global-footer';
      globalFooter.innerHTML = `<button type="button" class="lex-global-item" disabled>${icon('book')}<span>资料</span></button><button type="button" class="lex-global-item" disabled>${icon('settings')}<span>设置</span></button>`;
      nav.insertAdjacentElement('afterend', globalFooter);
    }
    if (legacyContext) legacyContext.style.display = 'none';
    syncCaseMeta();
    ensureTopbar();
  }
  function syncCaseMeta() {
    const route = parseRoute();
    const info = caseInfo[route.caseId];
    const meta = document.getElementById('lex-case-meta');
    if (meta && info) meta.innerHTML = `<strong>${esc(info.name)}</strong><small>${esc(info.code)} · 办理中</small>`;
  }
  function ensureTopbar() {
    const top = document.querySelector('.top');
    const oldSelect = document.querySelector('.context select');
    if (!top || !oldSelect) return;
    let switcher = top.querySelector('#lex-case-switcher');
    if (!switcher) {
      switcher = document.createElement('label');
      switcher.id = 'lex-case-switcher';
      const clone = oldSelect.cloneNode(true);
      clone.removeAttribute('id');
      clone.setAttribute('aria-label', '切换当前案件');
      switcher.innerHTML = '<span>当前案件</span>';
      switcher.appendChild(clone);
      clone.addEventListener('change', event => {
        const setter = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value')?.set;
        setter ? setter.call(oldSelect, event.target.value) : oldSelect.value = event.target.value;
        oldSelect.dispatchEvent(new Event('input', { bubbles: true }));
        oldSelect.dispatchEvent(new Event('change', { bubbles: true }));
      });
      const review = top.querySelector('.reviewlink');
      top.insertBefore(switcher, review || null);
    }
    const clone = switcher.querySelector('select');
    if (clone && clone.value !== oldSelect.value) clone.value = oldSelect.value;
  }
  function navigateSection(section) {
    const route = parseRoute();
    const db = readDb();
    const matter = db?.[route.caseId];
    if (!matter) return;
    if (section === 'delivery') {
      state.type = '全部'; state.status = '全部'; state.search = '';
      const selected = ['delivery', 'review', 'drafts', 'seal'].includes(route.section) ? route.id : '';
      const doc = matter.docs.find(item => item.id === selected);
      const pack = matter.packs.find(item => item.id === selected);
      const target = doc ? (doc.status === 'DRAFT' ? 'drafts' : 'review') : pack ? 'delivery' : matter.docs[0] ? (matter.docs[0].status === 'DRAFT' ? 'drafts' : 'review') : 'delivery';
      const id = doc?.id || pack?.id || matter.docs[0]?.id || matter.packs[0]?.id || '';
      navigate(navHash(route.caseId, target, id));
      return;
    }
    if (section === 'materials') {
      const file = matter.files[0] || matter.docs[0];
      navigate(navHash(route.caseId, 'materials', file?.id || ''));
      return;
    }
    if (section === 'seal') {
      navigate(navHash(route.caseId, 'seal', matter.seals[0]?.id || ''));
      return;
    }
    navigate(navHash(route.caseId, section));
  }
  function setActiveNav(route) {
    const active = sectionFor(route);
    document.querySelectorAll('#lex-matter-nav [data-section]').forEach(button => {
      const selected = button.dataset.section === active;
      button.classList.toggle('active', selected);
      if (selected) button.setAttribute('aria-current', 'page'); else button.removeAttribute('aria-current');
    });
  }
  function captureLegacyTriggers() {
    const sectionhead = document.querySelector('.sectionhead');
    if (sectionhead && (!window.__lexSealTrigger || !window.__lexSealTrigger.isConnected)) {
      window.__lexSealTrigger = [...sectionhead.querySelectorAll('button')].find(button => button.textContent.includes('申请用印')) || null;
    }
  }
  function removeOldNavigation() {
    const tabs = document.querySelector('.tabs');
    const sectionhead = document.querySelector('.sectionhead');
    if (tabs && tabs.style.display !== 'none') { tabs.style.display = 'none'; tabs.setAttribute('aria-hidden', 'true'); }
    if (sectionhead && sectionhead.style.display !== 'none') { sectionhead.style.display = 'none'; sectionhead.setAttribute('aria-hidden', 'true'); }
  }
  function ensureActionBar(route) {
    const content = document.querySelector('.content');
    const header = content?.querySelector(':scope > div:first-child');
    if (!content || !header) return;
    let actions = content.querySelector('.lex-doc-actions');
    if (!actions) {
      actions = document.createElement('div');
      actions.className = 'lex-doc-actions';
      header.insertAdjacentElement('afterend', actions);
    }
    const work = ['drafts', 'review', 'delivery', 'seal'].includes(route.section);
    const showSealAction = work && (route.section === 'seal' || state.type === '用印申请');
    const readOnly = scene() === 'readonly' || scene() === 'error';
    const mode = `${work ? 'work' : 'none'}:${state.type}:${showSealAction}`;
    if (actions.dataset.lexMode === mode && actions.dataset.lexReadonly === String(readOnly)) return;
    actions.dataset.lexMode = mode; actions.dataset.lexReadonly = String(readOnly);
    actions.innerHTML = '';
    if (work && !readOnly) {
      actions.appendChild(makeButton('从模板起草', 'primary', openTemplateWizard));
      actions.appendChild(makeButton('导入文书模板', 'outline', () => document.querySelector('.lex-legacy-import')?.click()));
    }
    if (showSealAction && !readOnly) actions.appendChild(makeButton('申请用印', 'outline', () => window.__lexSealTrigger?.click()));
    const h1 = header.querySelector('h1');
    if (h1) h1.textContent = work ? '文书与交付' : (sections.find(([key]) => key === route.section)?.[1] || (route.section === 'archive' ? '归档引用' : route.section === 'seal' ? '用印' : '案内工作区'));
    const description = header.querySelector('p');
    if (description && !description.dataset.lexOriginal) description.dataset.lexOriginal = description.textContent;
  }
  function makeButton(text, kind, handler) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = `btn ${kind === 'primary' ? 'primary' : ''}`;
    button.textContent = text;
    button.addEventListener('click', handler);
    return button;
  }
  function badgeHtml(status) { return pill(status); }
  function renderQueue(route, db) {
    const board = document.querySelector('.board');
    const queue = board?.querySelector('.queue');
    if (!queue) return;
    const matter = db?.[route.caseId];
    if (!matter) return;
    let items = [];
    const work = ['drafts', 'review', 'delivery', 'seal'].includes(route.section);
    if (work) items = getWorkItems(matter, route.caseId);
    else if (route.section === 'seal') items = matter.seals.map(item => ({ kind: 'seal', id: item.id, title: item.title, status: item.status, procedure: item.note, item }));
    else if (route.section === 'materials') items = [...matter.docs, ...matter.files].filter(item => !(scene() === 'withdrawDoc' && item.id === `${route.caseId}-D01`) && !(scene() === 'withdrawProof' && item.id === `${route.caseId}-M01`)).map(item => ({ kind: 'material', id: item.id, title: item.title, status: item.status || '原件', version: item.version, procedure: '固定原件', item }));
    else if (route.section === 'archive') items = matter.packs.map(item => ({ kind: 'archive', id: item.id, title: item.title, status: statusOfPack(item), procedure: item.recipient, item }));
    const type = state.type;
    const search = state.search.trim().toLowerCase();
    items = items.filter(entry => (type === '全部' || (type === '文书版本' && entry.kind === 'document') || (type === '用印申请' && entry.kind === 'seal') || (type === '交付清单' && entry.kind === 'delivery'))
      && (state.status === '全部' || entry.status === state.status)
      && (!search || `${entry.title} ${entry.id} ${entry.procedure || ''}`.toLowerCase().includes(search)));
    const signature = `${route.caseId}|${route.section}|${route.id}|${scene()}|${type}|${state.status}|${search}|${items.map(x => x.id + ':' + x.status).join(',')}`;
    const last = queue.dataset.lexSignature;
    if (last === signature && queue.dataset.lexEnhanced === '1') return;
    const title = work ? '文书与交付列表' : route.section === 'materials' ? '材料列表' : '归档引用列表';
    const statusOptions = [...new Set(items.map(item => item.status))];
    const searchWasFocused = document.activeElement === queue.querySelector('input[aria-label="搜索当前列表"]');
    const searchSelection = searchWasFocused ? queue.querySelector('input[aria-label="搜索当前列表"]').selectionStart : null;
    queue.innerHTML = `<div class="qhead"><strong>${title}</strong><span>${items.length} 项</span></div>
      <div class="tools"><label class="search">${icon('list')}<input aria-label="搜索当前列表" placeholder="搜索名称、编号或接收人" value="${esc(state.search)}"></label>
      ${work ? `<select class="lex-select" aria-label="对象类型筛选"><option>全部</option><option>文书版本</option><option>用印申请</option><option>交付清单</option></select>` : ''}
      <select class="lex-select" aria-label="状态筛选"><option>全部</option>${statusOptions.map(status => `<option value="${esc(status)}">${esc(labels[status] || status)}</option>`).join('')}</select></div>
      <div class="rows">${items.map(entry => {
        const selected = route.id === entry.id;
        const unavailable = entry.status === 'UNAVAILABLE' || (entry.kind === 'archive' && scene() === 'withdrawDoc' && entry.item.doc === `${route.caseId}-D01`);
        const iconName = entry.kind === 'delivery' || entry.kind === 'archive' ? 'package' : entry.kind === 'seal' ? 'stamp' : entry.kind === 'material' ? 'folder' : 'file';
        const meta = entry.kind === 'document' ? `V${entry.version} · ${entry.procedure || '未指定程序'}` : entry.kind === 'delivery' || entry.kind === 'archive' ? `${unavailable ? '原记录仍保留' : entry.item.recipient} · ${rawTitle(matter, entry.item.doc)}` : entry.kind === 'seal' ? `${entry.item.pages} 页 · ${entry.item.copies} 份` : `V${entry.version || 1} · 固定原件`;
        const target = entry.kind === 'document' ? (entry.status === 'DRAFT' ? 'drafts' : 'review') : entry.kind === 'seal' ? 'seal' : entry.kind === 'material' ? 'materials' : entry.kind === 'archive' ? 'archive' : 'delivery';
        return `<a class="row ${selected ? 'sel' : ''}" ${selected ? 'aria-current="page"' : ''} data-lex-row="${esc(entry.id)}" data-lex-target="${target}" href="${navHash(route.caseId, target, entry.id)}"><span class="fileIcon">${icon(iconName)}</span><span class="rowmain"><strong>${esc(unavailable ? '不可查看的清单' : entry.title)}</strong><small>${esc(meta)}</small></span>${badgeHtml(unavailable ? 'UNAVAILABLE' : entry.status)}</a>`;
      }).join('')}</div>${items.length ? '' : `<div class="empty"><span>${icon('file')}</span><p>${search || type !== '全部' || state.status !== '全部' ? '没有匹配的记录' : `本案暂无${work ? (type === '用印申请' ? '用印申请' : '文书或交付记录') : title.replace('列表', '')}`}</p><button class="btn" data-lex-clear>清除筛选</button></div>`}`;
    queue.dataset.lexSignature = signature;
    queue.dataset.lexEnhanced = '1';
    const searchInput = queue.querySelector('input[aria-label="搜索当前列表"]');
    searchInput?.addEventListener('input', event => { state.search = event.target.value; scheduleRender(); });
    if (searchWasFocused && searchInput) { searchInput.focus(); if (searchSelection != null) searchInput.setSelectionRange(searchSelection, searchSelection); }
    const selects = queue.querySelectorAll('select.lex-select');
    if (work && selects.length === 2) {
      selects[0].value = state.type;
      selects[0].addEventListener('change', event => { state.type = event.target.value; scheduleRender(); });
      selects[1].value = state.status;
      selects[1].addEventListener('change', event => { state.status = event.target.value; scheduleRender(); });
    } else if (selects.length) {
      selects[0].value = state.status;
      selects[0].addEventListener('change', event => { state.status = event.target.value; scheduleRender(); });
    }
    bindListKeyboard(queue);
    queue.querySelectorAll('[data-lex-row]').forEach(link => link.addEventListener('click', event => {
      if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
      event.preventDefault();
      navigate(navHash(route.caseId, link.dataset.lexTarget, link.dataset.lexRow));
    }));
    queue.querySelector('[data-lex-clear]')?.addEventListener('click', () => { state.type = '全部'; state.status = '全部'; state.search = ''; scheduleRender(); });
  }
  function rawTitle(matter, id) {
    const file = [...matter.docs, ...matter.files].find(item => item.id === id);
    if (!file) return '固定原件不可查看';
    if (isWithdrawn(id)) return '固定原件已撤回';
    return `${file.title} · V${file.version}`;
  }
  function inspectorMarkup(route, db) {
    const matter = db?.[route.caseId];
    if (!matter) return '';
    const { doc, pack, seal, file } = findSelected(db, route);
    const section = route.section;
    const unavailablePack = pack && scene() === 'withdrawDoc' && pack.doc === `${route.caseId}-D01`;
    const sectionBlock = (title, body) => `<section><small>${title}</small>${body}</section>`;
    if (doc) {
      const family = matter.docs.filter(item => item.family === doc.family && !(scene() === 'withdrawDoc' && item.id === `${route.caseId}-D01`)).sort((a, b) => b.version - a.version);
      const linked = matter.packs.filter(item => item.doc === doc.id);
      return `<div class="inspectorHead">检查信息</div>
        ${sectionBlock('文书版本', `<strong>${esc(doc.title)}</strong><p>${esc(doc.id)}</p>`)}
        ${sectionBlock('当前状态', `${badgeHtml(doc.status)}<p>${family[0]?.id === doc.id ? '当前版本' : '历史版本 · 不可覆盖'}</p>`)}
        ${sectionBlock('主体与程序', `<strong>${esc(doc.subject)}</strong><p>${esc(caseInfo[route.caseId].procedures[doc.proc] || '未指定程序')}</p>`)}
        ${sectionBlock('模板来源', `<p>${esc(doc.origin || '未记录')}</p>`)}
        ${sectionBlock('保存卷宗', `<p>${esc(doc.folder || '未指定')}</p>`)}
        ${sectionBlock('引用材料', (doc.contextInputs || []).length ? doc.contextInputs.map(name => `<p>${esc(name)}</p>`).join('') : '<p>未记录引用材料</p>')}
        ${sectionBlock('版本族', family.map(item => `<a href="${navHash(route.caseId, item.status === 'DRAFT' ? 'drafts' : 'review', item.id)}" data-lex-navlink="1">V${item.version} · ${esc(labels[item.status] || item.status)}</a>`).join(''))}
        ${sectionBlock('关联交付', linked.length ? linked.map(item => `<a href="${navHash(route.caseId, 'delivery', item.id)}" data-lex-navlink="1">${esc(item.title)}</a>`).join('') : '<p>暂无交付清单</p>')}`;
    }
    if (pack) {
      const frozen = matter.docs.find(item => item.id === pack.doc) || matter.files.find(item => item.id === pack.doc);
      const later = frozen && matter.docs.some(item => item.family === frozen.family && item.version > frozen.version);
      return `<div class="inspectorHead">检查信息</div>
        ${sectionBlock('交付清单', `<strong>${esc(unavailablePack ? '不可查看的清单' : pack.title)}</strong><p>${esc(pack.id)}</p>${badgeHtml(unavailablePack ? 'UNAVAILABLE' : statusOfPack(pack))}`)}
        ${sectionBlock('接收对象', unavailablePack ? '<p>固定原件已撤回，清单内容不可查看。</p>' : `<strong>${esc(pack.recipient)}</strong><p>${esc(pack.contact)}</p>`)}
        ${sectionBlock('固定版本', unavailablePack ? '<p>原件当前不可查看</p>' : `<p>${esc(frozen?.title || '原件不可查看')} · V${frozen?.version || '—'}</p>${later ? '<p>已有后继版本；历史清单仍固定原版。</p>' : ''}`)}
        ${sectionBlock('交付历史', `<p>${pack.events.length} 条事件</p>${pack.parent ? `<a href="${navHash(route.caseId, 'delivery', pack.parent)}" data-lex-navlink="1">补发原清单 ${esc(pack.parent)}</a>` : ''}`)}
        ${sectionBlock('客户决定', `<strong>${esc(matter.decision)}</strong><p>收悉不会自动确认客户决定。</p>`)}
        ${sectionBlock('归档引用', `<a href="${navHash(route.caseId, 'archive', pack.id)}" data-lex-navlink="1">查看凭据引用</a>`)}`;
    }
    if (seal) {
      return `<div class="inspectorHead">检查信息</div>
        ${sectionBlock('用印申请', `<strong>${esc(seal.title)}</strong><p>${esc(seal.id)}</p>${badgeHtml(seal.status)}`)}
        ${sectionBlock('申请信息', `<p>林律师 · ${seal.pages} 页 · ${seal.copies} 份</p><p>${esc(seal.note)}</p>`)}
        ${sectionBlock('待盖章原件', `<p>${esc(rawTitle(matter, seal.draft))}</p>`)}
        ${sectionBlock('实盖结果', seal.stamp ? `<p>${esc(rawTitle(matter, seal.stamp))}</p>` : '<p>尚未登记实际盖章</p>')}`;
    }
    if (file) return `<div class="inspectorHead">检查信息</div>${sectionBlock('固定材料', `<strong>${esc(file.title)}</strong><p>V${file.version} · ${esc(file.id)}</p>`)}${sectionBlock('案件', `<strong>${esc(caseInfo[route.caseId].name)}</strong><p>${esc(caseInfo[route.caseId].code)}</p>`)}`;
    return `<div class="inspectorHead">检查信息</div>${sectionBlock('当前案件', `<strong>${esc(caseInfo[route.caseId].name)}</strong><p>${esc(caseInfo[route.caseId].code)}</p>`)}${sectionBlock('当前程序', caseInfo[route.caseId].procedures.map(item => `<p>${esc(item)}</p>`).join(''))}${sectionBlock('近期期限', caseInfo[route.caseId].due.map(item => `<p>${esc(item)}</p>`).join(''))}`;
  }
  function loadPaneWidths() {
    if (state.paneWidths) return state.paneWidths;
    try { state.paneWidths = JSON.parse(localStorage.getItem('lex-docs-pane-widths-v1')) || {}; }
    catch { state.paneWidths = {}; }
    state.paneWidths.list = Math.max(230, Math.min(400, Number(state.paneWidths.list) || 300));
    state.paneWidths.inspector = Math.max(200, Math.min(340, Number(state.paneWidths.inspector) || 245));
    return state.paneWidths;
  }
  function ensureResizeHandles(board) {
    const queue = board.querySelector('.queue');
    const detail = board.querySelector('.detail');
    const inspector = board.querySelector('.inspector');
    if (!queue || !detail || !inspector) return;
    const widths = loadPaneWidths();
    board.style.setProperty('--lex-list-width', `${widths.list}px`);
    board.style.setProperty('--lex-inspector-width', `${widths.inspector}px`);
    let listHandle = board.querySelector('.lex-resize-list');
    if (!listHandle) {
      listHandle = document.createElement('div');
      listHandle.className = 'lex-resize-handle lex-resize-list';
      listHandle.setAttribute('role', 'separator'); listHandle.setAttribute('aria-orientation', 'vertical');
      listHandle.setAttribute('aria-label', '调整列表宽度'); listHandle.tabIndex = 0;
      queue.insertAdjacentElement('afterend', listHandle);
      attachResize(listHandle, board, 'list');
    }
    let inspectorHandle = board.querySelector('.lex-resize-inspector');
    if (!inspectorHandle) {
      inspectorHandle = document.createElement('div');
      inspectorHandle.className = 'lex-resize-handle lex-resize-inspector';
      inspectorHandle.setAttribute('role', 'separator'); inspectorHandle.setAttribute('aria-orientation', 'vertical');
      inspectorHandle.setAttribute('aria-label', '调整检查栏宽度'); inspectorHandle.tabIndex = 0;
      detail.insertAdjacentElement('afterend', inspectorHandle);
      attachResize(inspectorHandle, board, 'inspector');
    }
  }
  function attachResize(handle, board, kind) {
    handle.addEventListener('pointerdown', event => {
      if (event.button !== 0) return;
      event.preventDefault();
      const widths = loadPaneWidths();
      const startX = event.clientX;
      const startWidth = widths[kind];
      handle.setPointerCapture?.(event.pointerId);
      const move = moveEvent => {
        const delta = moveEvent.clientX - startX;
        const next = kind === 'list' ? Math.max(230, Math.min(400, startWidth + delta)) : Math.max(200, Math.min(340, startWidth - delta));
        widths[kind] = Math.round(next);
        board.style.setProperty(kind === 'list' ? '--lex-list-width' : '--lex-inspector-width', `${widths[kind]}px`);
      };
      const up = () => {
        window.removeEventListener('pointermove', move);
        window.removeEventListener('pointerup', up);
        try { localStorage.setItem('lex-docs-pane-widths-v1', JSON.stringify(widths)); } catch {}
      };
      window.addEventListener('pointermove', move);
      window.addEventListener('pointerup', up, { once: true });
    });
    handle.addEventListener('keydown', event => {
      if (!['ArrowLeft', 'ArrowRight'].includes(event.key)) return;
      event.preventDefault();
      const widths = loadPaneWidths();
      const direction = event.key === 'ArrowRight' ? 12 : -12;
      widths[kind] = kind === 'list' ? Math.max(230, Math.min(400, widths.list + direction)) : Math.max(200, Math.min(340, widths.inspector - direction));
      board.style.setProperty(kind === 'list' ? '--lex-list-width' : '--lex-inspector-width', `${widths[kind]}px`);
      try { localStorage.setItem('lex-docs-pane-widths-v1', JSON.stringify(widths)); } catch {}
    });
  }
  function bindListKeyboard(queue) {
    if (queue.dataset.lexKeyboard === '1') return;
    queue.dataset.lexKeyboard = '1';
    queue.addEventListener('keydown', event => {
      if (event.target.matches('input,select,textarea,button')) return;
      const rows = [...queue.querySelectorAll('a[data-lex-row]')];
      if (!rows.length) return;
      const current = rows.indexOf(document.activeElement);
      let next = current;
      if (event.key === 'ArrowDown') next = Math.min(rows.length - 1, current < 0 ? 0 : current + 1);
      else if (event.key === 'ArrowUp') next = Math.max(0, current < 0 ? 0 : current - 1);
      else if (event.key === 'Home') next = 0;
      else if (event.key === 'End') next = rows.length - 1;
      else return;
      event.preventDefault(); rows[next].focus();
    });
  }
  function renderInspector(route, db) {
    const board = document.querySelector('.board');
    if (!board) return;
    let inspector = board.querySelector('.inspector');
    if (!inspector) {
      inspector = document.createElement('aside');
      inspector.className = 'inspector';
      board.appendChild(inspector);
    }
    const html = inspectorMarkup(route, db);
    if (inspector.dataset.lexHtml !== html) {
      inspector.innerHTML = html;
      inspector.dataset.lexHtml = html;
      inspector.querySelectorAll('a[data-lex-navlink]').forEach(link => link.addEventListener('click', event => {
        event.preventDefault();
        navigate(link.getAttribute('href'));
      }));
    }
  }
  function renderPlaceholder(route) {
    const content = document.querySelector('.content');
    const board = content?.querySelector('.board');
    if (!content || !board) return;
    const label = sections.find(([key]) => key === route.section)?.[1] || (route.section === 'research' ? '事实与研究' : route.section);
    let placeholder = content.querySelector('.lex-section-placeholder');
    if (!placeholder) {
      placeholder = document.createElement('section');
      placeholder.className = 'lex-section-placeholder';
      board.insertAdjacentElement('afterend', placeholder);
    }
    if (board.style.display !== 'none') board.style.display = 'none';
    const signature = `${route.caseId}|${route.section}`;
    if (placeholder.dataset.lexSection === signature) return;
    placeholder.dataset.lexSection = signature;
    placeholder.innerHTML = `<div class="lex-placeholder-icon">${icon('grid')}</div><h2>${esc(label)}</h2><p>这是 Chronicle 案内的独立分区。为避免与其他工作组重复设计，本轮仅校准九分区导航与文书工作区；此分区保留原入口，不在本预览中重做。</p><button class="btn primary" data-lex-back>返回文书与交付</button>`;
    placeholder.querySelector('[data-lex-back]')?.addEventListener('click', () => navigateSection('delivery'));
  }
  function openTemplateWizard(restoring = false) {
    if (scene() === 'readonly' || scene() === 'error') return;
    if (document.getElementById('lex-template-overlay')) return;
    const route = parseRoute();
    const db = readDb();
    const matter = db?.[route.caseId];
    if (!matter) return;
    state.template = restoring && state.templateSnapshot ? structuredClone(state.templateSnapshot) : { caseId: route.caseId, step: 1, template: matter.templates[0] || '', proc: '0', opposing: caseInfo[route.caseId].opposing, third: caseInfo[route.caseId].third, folder: caseInfo[route.caseId].folders[0], sources: [...caseInfo[route.caseId].sources.slice(0, 2)], title: '案件法律意见书', body: '请结合本案事实、证据和委托目标，填写本次文书要点。', prepared: false, checked: false };
    state.templateDirty = false;
    state.templateHistory = true;
    if (!restoring) history.pushState({ ...(history.state || {}), lexTemplate: true }, '', `${location.pathname}?template=1${location.hash}`);
    renderTemplateWizard();
  }
  function templateOverlayHtml(t, matter) {
    const steps = ['选择模板', '主体与程序', '字段核对'];
    const stepper = steps.map((step, index) => `<li class="${t.step === index + 1 ? 'current' : t.step > index + 1 ? 'done' : ''}"><span>${t.step > index + 1 ? '✓' : index + 1}</span>${step}</li>`).join('');
    const templates = matter.templates.map((name, index) => `<button type="button" class="lex-template-choice ${t.template === name ? 'selected' : ''}" data-template-choice="${esc(name)}"><span class="lex-file-icon">${icon('file')}</span><span><strong>${esc(name)}</strong><small>${index === 0 ? '工作成果 · 适用于当前案件' : '工作成果 · 可生成独立版本'}</small></span>${t.template === name ? '<em>已选择</em>' : ''}</button>`).join('');
    let body = '';
    if (t.step === 1) body = `<h2>选择本案适用模板</h2><p class="muted">模板来自当前个人工作区。模板版本与本次生成记录分别保留。</p><div class="lex-template-choices">${templates || '<p>暂无适用模板，请先导入 DOCX 模板。</p>'}</div>`;
    if (t.step === 2) body = `<h2>核对文书主体、程序与引用材料</h2><div class="lex-form-grid"><label>委托主体<input readonly value="${esc(caseInfo[t.caseId].client)}"></label><label>对方当事人<select id="lex-template-opposing">${[caseInfo[t.caseId].opposing, '其他 / 待确认'].map(value => `<option ${value === t.opposing ? 'selected' : ''}>${esc(value)}</option>`).join('')}</select></label><label>第三人（可选）<select id="lex-template-third"><option value="">未指定</option>${[caseInfo[t.caseId].third, '其他 / 待确认'].map(value => `<option ${value === t.third ? 'selected' : ''}>${esc(value)}</option>`).join('')}</select></label><label>所属程序<select id="lex-template-proc">${caseInfo[t.caseId].procedures.map((name, index) => `<option value="${index}" ${String(index) === String(t.proc) ? 'selected' : ''}>${esc(name)}</option>`).join('')}</select></label><label>保存卷宗<select id="lex-template-folder">${caseInfo[t.caseId].folders.map(name => `<option ${name === t.folder ? 'selected' : ''}>${esc(name)}</option>`).join('')}</select></label><label class="wide">文书名称<input id="lex-template-title" maxlength="200" value="${esc(t.title)}"></label><div class="wide lex-source-picker"><strong>本次引用的案内材料</strong><p>只选择本次起草要使用的固定材料版本。</p><div>${caseInfo[t.caseId].sources.map(name => `<label><input type="checkbox" data-lex-source="${esc(name)}" ${t.sources.includes(name) ? 'checked' : ''}>${esc(name)}</label>`).join('')}</div></div><label class="wide">本次文书要点<textarea id="lex-template-body" rows="7">${esc(t.body)}</textarea></label></div><p class="fieldHint">主体、程序或引用材料改变后，必须重新核对动态字段。生成的工作稿交由 Editor 打开、保存和回传。</p>`;
    if (t.step === 3) body = `<h2>生成前核对</h2><div class="lex-review-summary"><div><small>模板</small><strong>${esc(t.template)}</strong></div><div><small>委托主体</small><strong>${esc(caseInfo[t.caseId].client)}</strong></div><div><small>对方当事人</small><strong>${esc(t.opposing)}</strong></div><div><small>第三人</small><strong>${esc(t.third || '未指定')}</strong></div><div><small>所属程序</small><strong>${esc(caseInfo[t.caseId].procedures[Number(t.proc) || 0])}</strong></div><div><small>保存卷宗</small><strong>${esc(t.folder)}</strong></div><div><small>引用材料</small><p>${t.sources.map(esc).join('、') || '未选择'}</p></div><div><small>文书名称</small><strong>${esc(t.title)}</strong></div><div><small>文书要点</small><p>${esc(t.body)}</p></div></div>${t.prepared ? '<div class="lex-confirmed">✓ 本次主体、程序、引用材料和实际字段已重新核对。</div>' : '<button class="btn" data-template-recheck>重新核对实际字段</button>'}<label class="lex-check"><input type="checkbox" id="lex-template-checked" ${t.checked ? 'checked' : ''} ${t.prepared ? '' : 'disabled'}>我已核对本次文书的主体、程序、引用材料与字段</label>`;
    return `<div class="lex-template-overlay" id="lex-template-overlay"><div class="lex-template-page"><header><div><p>${esc(caseInfo[t.caseId].code)} · ${esc(caseInfo[t.caseId].name)} · 文书与交付</p><h1>从模板起草</h1><span>选择适用模板，核对本案主体、程序与字段后生成新的工作稿版本。</span></div><button class="btn" data-template-close>返回文书与交付</button></header><ol class="lex-stepper">${stepper}</ol><div class="lex-template-layout"><section class="lex-template-main">${body}</section><aside class="lex-template-inspector"><div class="lex-inspector-head">模板信息</div><section><small>当前模板</small><strong>${esc(t.template || '尚未选择')}</strong><p>本案适用 · DOCX 工作稿</p></section><section><small>生成规则</small><p>缺少必填字段或未完成核对时，不允许生成。</p><p>每次生成创建新文书版本，不覆盖历史版本。</p></section><section><small>后续处理</small><p>生成后进入文书与交付列表，由 Editor 负责正文打开、保存和版本回传。</p></section></aside></div><footer><button class="btn" data-template-back>${t.step === 1 ? '取消' : '上一步'}</button><span>第 ${t.step} / 3 步</span>${t.step < 3 ? `<button class="btn primary" data-template-next ${t.step === 1 && !t.template || t.step === 2 && (!t.title.trim() || !t.body.trim()) ? 'disabled' : ''}>下一步</button>` : `<button class="btn primary" data-template-generate ${!t.prepared || !t.checked || !t.title.trim() || !t.body.trim() ? 'disabled' : ''}>生成 V1 工作稿</button>`}</footer></div></div>`;
  }
  function renderTemplateWizard() {
    const current = state.template;
    if (!current) return;
    const matter = readDb()?.[current.caseId];
    if (!matter) return;
    document.getElementById('lex-template-overlay')?.remove();
    document.body.insertAdjacentHTML('beforeend', templateOverlayHtml(current, matter));
    const overlay = document.getElementById('lex-template-overlay');
    overlay.querySelectorAll('[data-template-choice]').forEach(button => button.addEventListener('click', () => {
      current.template = button.dataset.templateChoice; current.prepared = false; current.checked = false; state.templateDirty = true; renderTemplateWizard();
    }));
    overlay.querySelector('#lex-template-proc')?.addEventListener('change', event => { current.proc = event.target.value; current.prepared = false; current.checked = false; state.templateDirty = true; });
    overlay.querySelector('#lex-template-opposing')?.addEventListener('change', event => { current.opposing = event.target.value; current.prepared = false; current.checked = false; state.templateDirty = true; });
    overlay.querySelector('#lex-template-third')?.addEventListener('change', event => { current.third = event.target.value; current.prepared = false; current.checked = false; state.templateDirty = true; });
    overlay.querySelector('#lex-template-folder')?.addEventListener('change', event => { current.folder = event.target.value; state.templateDirty = true; });
    overlay.querySelectorAll('[data-lex-source]').forEach(input => input.addEventListener('change', () => { current.sources = [...overlay.querySelectorAll('[data-lex-source]:checked')].map(item => item.dataset.lexSource); current.prepared = false; current.checked = false; state.templateDirty = true; }));
    overlay.querySelector('#lex-template-title')?.addEventListener('input', event => { current.title = event.target.value; current.prepared = false; current.checked = false; state.templateDirty = true; updateWizardFooter(overlay, current); });
    overlay.querySelector('#lex-template-body')?.addEventListener('input', event => { current.body = event.target.value; current.prepared = false; current.checked = false; state.templateDirty = true; updateWizardFooter(overlay, current); });
    overlay.querySelector('#lex-template-checked')?.addEventListener('change', event => { current.checked = event.target.checked; state.templateDirty = true; updateWizardFooter(overlay, current); });
    overlay.querySelector('[data-template-recheck]')?.addEventListener('click', () => { current.prepared = true; current.checked = false; state.templateDirty = true; renderTemplateWizard(); });
    overlay.querySelector('[data-template-next]')?.addEventListener('click', () => { current.step += 1; renderTemplateWizard(); });
    overlay.querySelector('[data-template-back]')?.addEventListener('click', () => { if (current.step === 1) requestCloseTemplate(); else { current.step -= 1; renderTemplateWizard(); } });
    overlay.querySelector('[data-template-close]')?.addEventListener('click', requestCloseTemplate);
    overlay.querySelector('[data-template-generate]')?.addEventListener('click', generateTemplate);
  }
  function updateWizardFooter(overlay, current) {
    const next = overlay.querySelector('[data-template-next]');
    const generate = overlay.querySelector('[data-template-generate]');
    if (next) next.disabled = current.step === 1 ? !current.template : !current.title.trim() || !current.body.trim();
    if (generate) generate.disabled = !current.prepared || !current.checked || !current.title.trim() || !current.body.trim();
  }
  function requestCloseTemplate() {
    if (!state.template) return;
    if (state.templateDirty) {
      const overlay = document.getElementById('lex-template-overlay');
      if (overlay?.querySelector('.lex-discard')) return;
      overlay?.insertAdjacentHTML('beforeend', `<div class="lex-discard-backdrop"><div class="lex-discard"><strong>放弃未保存的起草内容？</strong><p>继续填写会保留当前模板和字段。</p><div><button class="btn" data-lex-keep>继续填写</button><button class="btn primary" data-lex-discard>放弃修改</button></div></div></div>`);
      overlay?.querySelector('[data-lex-keep]')?.addEventListener('click', () => overlay.querySelector('.lex-discard-backdrop')?.remove());
      overlay?.querySelector('[data-lex-discard]')?.addEventListener('click', () => { state.templateDirty = false; state.templateSnapshot = null; state.template = null; history.back(); });
      return;
    }
    history.back();
  }
  function closeTemplateOverlay(preserve = true) {
    if (preserve && state.template) state.templateSnapshot = structuredClone(state.template);
    if (!preserve) state.templateSnapshot = null;
    document.getElementById('lex-template-overlay')?.remove();
    state.template = null;
    state.templateDirty = false;
  }
  function generateTemplate() {
    const current = state.template;
    if (!current || !current.prepared || !current.checked || !current.title.trim() || !current.body.trim()) return;
    const db = readDb();
    const matter = db?.[current.caseId];
    if (!matter || scene() === 'readonly') return;
    const id = unique(current.caseId, 'D');
    const family = unique(current.caseId, 'F');
    const title = current.title.trim().replace(/\.docx$/i, '') + '.docx';
    matter.docs.unshift({ id, family, title, version: 1, status: 'DRAFT', proc: Number(current.proc), subject: caseInfo[current.caseId].client, origin: current.template, body: current.body.trim(), selection: { client: caseInfo[current.caseId].client, opposing: current.opposing, third: current.third, procedure: current.proc }, folder: current.folder, contextInputs: [...current.sources], issues: [], history: [{ label: '生成工作稿', note: '本案主体、程序与实际字段已核对。', at: new Date().toISOString() }], rev: 1 });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
    state.templateDirty = false;
    state.templateSnapshot = null;
    closeTemplateOverlay(false);
    history.replaceState(history.state, '', `${location.pathname}${location.hash}`);
    location.hash = navHash(current.caseId, 'drafts', id);
    location.reload();
  }
  function handleTemplateHistory(event) {
    const overlay = document.getElementById('lex-template-overlay');
    if (!overlay) {
      if (new URLSearchParams(location.search).get('template') === '1') openTemplateWizard(true);
      return;
    }
    if (state.templateDirty) {
      history.pushState({ ...(history.state || {}), lexTemplate: true }, '', `${location.pathname}?template=1${location.hash}`);
      event.stopImmediatePropagation();
      requestCloseTemplate();
    } else {
      closeTemplateOverlay();
    }
  }
  function renderAll() {
    const app = document.querySelector('.app');
    if (!app) return;
    const route = parseRoute();
    const db = readDb();
    if (!db?.[route.caseId]) return;
    ensureSidebar(); ensureTopbar(); syncCaseMeta(); captureLegacyTriggers(); removeOldNavigation(); setActiveNav(route);
    const content = document.querySelector('.content');
    const board = content?.querySelector('.board');
    const work = ['drafts', 'review', 'delivery', 'seal'].includes(route.section);
    const group = work ? 'work' : route.section;
    if (state.lastGroup !== group) {
      state.type = '全部'; state.status = '全部'; state.search = '';
      state.lastGroup = group;
    }
    if (route.section === 'seal' && state.type === '全部') state.type = '用印申请';
    ensureActionBar(route);
    if (scene() === 'error') {
      if (board && board.dataset.lexError !== '1') {
        board.innerHTML = `<div class="lex-error-state"><div>${icon('file')}</div><h2>无法读取本案记录</h2><p>当前预览模拟读取失败。恢复后可继续查看原有记录。</p><button class="btn primary" data-lex-retry>重新读取</button></div>`;
        board.dataset.lexError = '1';
        board.style.gridTemplateColumns = '1fr';
        board.querySelector('[data-lex-retry]')?.addEventListener('click', () => { localStorage.setItem(SCENE_KEY, 'normal'); location.reload(); });
      }
      return;
    }
    if (board?.dataset.lexError === '1') { board.dataset.lexError = ''; location.reload(); return; }
    const supported = work || ['materials', 'archive'].includes(route.section);
    if (!supported) { renderPlaceholder(route); return; }
    content?.querySelector('.lex-section-placeholder')?.remove();
    if (board && board.style.display !== '') board.style.display = '';
    renderQueue(route, db);
    renderInspector(route, db);
    ensureResizeHandles(board);
    const header = content?.querySelector(':scope > div:first-child h1');
    const heading = work ? '文书与交付' : (route.section === 'materials' ? '材料与卷宗' : '结案与归档');
    if (header && header.textContent !== heading) header.textContent = heading;
  }
  function scheduleRender() {
    if (state.timer) clearTimeout(state.timer);
    state.timer = setTimeout(renderAll, 35);
  }
  function startObserver() {
    const app = document.querySelector('.app');
    if (!app || state.observer) return;
    state.observer = new MutationObserver(() => scheduleRender());
    state.observer.observe(app, { childList: true, subtree: true });
  }
  window.addEventListener('popstate', handleTemplateHistory, true);
  window.addEventListener('hashchange', scheduleRender);
  window.addEventListener('beforeunload', event => { if (state.template && state.templateDirty) { event.preventDefault(); event.returnValue = ''; } });
  const boot = () => { installStyle(); renderAll(); startObserver(); if (new URLSearchParams(location.search).get('template') === '1') openTemplateWizard(true); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => setTimeout(boot, 30), { once: true });
  else setTimeout(boot, 30);
  setTimeout(boot, 250);
})();

export const names={drafts:'文书起草',review:'逐版复核',seal:'用印',delivery:'实际交付',materials:'材料原件',archive:'归档引用'}
export const caseInfo={A:{code:'CH-2026-001',name:'澄禾设备采购争议',client:'澄禾设备有限公司',procedures:['一审 · 买卖合同纠纷','保全 · 财产保全'],due:['11月26日　提交证据目录','11月27日　保全续期']},B:{code:'QL-2026-002',name:'青岚仓储交付争议',client:'青岚仓储有限公司',procedures:['仲裁 · 仓储合同争议','保全执行 · 仓储物保全'],due:['11月30日　核对仓储清单','11月30日　保全核查']}}
export const S={DRAFT:'草稿',PENDING_REVIEW:'待复核',APPROVED:'已批准',PREPARED:'已冻结',EXPORTED:'已导出，未登记发送',SENT:'已登记送出',RECEIVED:'收悉',REPLIED:'客户回复',CONTENT_CONFIRMED:'客户确认内容',SEND_CORRECTION:'发送更正',PENDING:'待决定',STAMPED:'已登记实盖',CANCELLED:'已撤销',REJECTED:'已驳回',UNAVAILABLE:'记录不可查看'}
export const stamp=s=>new Date(s??Date.now()).toISOString()
export const display=s=>new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date(s))
export const nowInput=()=>new Date(Date.now()+28800e3).toISOString().slice(0,16)
export const unique=(c,t)=>c+'-'+t+'-'+crypto.randomUUID().slice(0,8)
export const statuses=(pkg)=>pkg.events.some(e=>e.kind==='SENT')?'SENT':pkg.events.some(e=>e.kind==='EXPORTED')?'EXPORTED':'PREPARED'
export const history=(label, note='')=>({label,note,at:stamp()})
const t=(h)=>'2026-11-17T'+h+':00.000Z'
function seed(c){
 const letter=c==='A'?'采购设备交接条件及付款期限':'仓储货物交接与验收责任';
 const doc=(id,family,title,version,status,body)=>({id:c+'-'+id,family:c+'-'+family,title,version,status,body,proc:0,rev:1,origin:'案件意见书模板',subject:caseInfo[c].client,history:[{at:t('01:00'),label:'生成工作稿',note:'已核对模板字段与程序。'}],issues:[]})
 const d1=doc('D01','F01','法律意见书.docx',1,'APPROVED',letter+'。第一版约定于 11 月 24 日提交书面答复。')
 d1.issues=[{id:c+'-I00',title:'说明验收日期的依据',location:'第一段',basis:'交接清单',status:'OPEN',events:['已记录；批准时逐项核对该问题，留待后续核实。']}]
 d1.history.push({at:t('02:00'),label:'送审'},{at:t('03:00'),label:'批准本版',note:'逐项核对完成。'})
 const d2=doc('D02','F01','法律意见书.docx',2,'PENDING_REVIEW',letter+'。第二版补充了验收清单与送达地点。')
 d2.history=[{at:t('04:00'),label:'Editor 登记后继版本',note:'基线为 V1。'},{at:t('05:00'),label:'送审'}]
 d2.issues=[{id:c+'-I01',title:'核实新列的交接地点',location:'第二段',basis:'本案委托人核对记录',status:'WAITING_CHECK',events:['提出问题','作者回应 · 采纳，已对照交接记录']}]
 const d3=doc('D03','F03','代理词.docx',1,'DRAFT',letter+'。待补充事实与理由。')
 const proof={id:c+'-M01',title:'签收回单.pdf',version:1,body:caseInfo[c].name+' · 现场签收回单，仅确认收到。'}
 const pdf={id:c+'-M02',title:'待章定稿.pdf',version:1,body:caseInfo[c].name+' · 待盖章定稿。'}
 const scan={id:c+'-M03',title:'实际盖章扫描件.pdf',version:1,body:caseInfo[c].name+' · 盖章扫描件。'}
 const orig={id:c+'-P01',title:'阶段法律意见交付',doc:d1.id,recipient:caseInfo[c].client,contact:'法务收件室',scope:'委托人内部阅核',parent:null,events:[
 {id:c+'-E01',kind:'EXPORTED',at:t('03:10'),recorded:t('03:10')},{id:c+'-E02',kind:'SENT',at:t('03:20'),recorded:t('03:30'),channel:'现场交接',note:'原稿已交法务收件室。'},
 {id:c+'-E03',kind:'RECEIVED',at:t('03:45'),recorded:t('03:55'),channel:'书面回单',note:'客户已签收，方案待决定。',proof:proof.id}]}
 return {docs:c==='A'?[d2,d3,d1]:[d3,{...d1,status:'APPROVED'}],files:[proof,pdf,scan],packs:c==='A'?[orig]:[],seals:c==='A'?[{id:'A-S01',title:'阶段意见书用印',status:'PENDING',draft:pdf.id,stamp:null,note:'阶段性法律意见',pages:2,copies:1,history:[{at:t('02:10'),label:'提交用印申请'}]}]:[],decision:'待客户确认',templates:['案件意见书模板','代理词模板']}
}
export const initial=()=>({A:seed('A'),B:seed('B')})
export const stateOf=(r,tab)=>tab==='delivery'?statuses(r):r.status
export const rawFile=(c,id)=>[...c.docs,...c.files].find(x=>x.id===id)
export const latest=(c,d)=>Math.max(...c.docs.filter(x=>x.family===d.family).map(x=>x.version))===d.version

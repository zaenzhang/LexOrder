from pathlib import Path
import re
p=Path('/mnt/data/lexorder_review_source/source/src/postprocess.js')
s=p.read_text()

# 1) The current-case primary menu uses the coordinator's exact short names.
s=s.replace("""  const sections = [
    ['overview', '概览', 'grid'],
    ['tasks', '程序与任务', 'calendar'],
    ['materials', '材料与卷宗', 'folder'],
    ['evidence', '事实与研究', 'list'],
    ['delivery', '文书与交付', 'file'],
    ['records', '办理记录', 'clock'],
    ['finance', '案件财务', 'wallet'],
    ['archive', '结案与归档', 'archive'],
  ];""", """  // Sidebar labels are deliberately short; full page titles remain in the content area.
  const sections = [
    ['overview', '概览', 'grid'], ['tasks', '程序', 'calendar'], ['materials', '材料', 'folder'],
    ['evidence', '事实', 'book'], ['delivery', '文书', 'file'], ['records', '记录', 'clock'],
    ['finance', '财务', 'wallet'], ['archive', '归档', 'archive'],
  ];
  const pageTitles = {
    overview: '案件概览', tasks: '程序与任务', materials: '材料与卷宗', evidence: '争点证据对照',
    research: '研究工作区', delivery: '文书与交付', seal: '用印管理', records: '办理记录',
    finance: '案件财务', archive: '案件归档',
  };
  const currentMenu = [
    { key: 'overview', label: '概览', glyph: 'grid', route: 'overview' },
    { key: 'tasks', label: '程序', glyph: 'calendar', route: 'tasks' },
    { key: 'materials', label: '材料', glyph: 'folder', route: 'materials' },
    { key: 'facts', label: '事实', glyph: 'book', children: [
      { key: 'evidence', label: '争点', route: 'evidence' },
      { key: 'research', label: '研究', route: 'research' },
    ] },
    { key: 'documents', label: '文书', glyph: 'file', children: [
      { key: 'delivery', label: '文书台', route: 'delivery' },
      { key: 'seal', label: '用印', route: 'seal' },
    ] },
    { key: 'records', label: '记录', glyph: 'clock', route: 'records' },
    { key: 'finance', label: '财务', glyph: 'wallet', route: 'finance' },
    { key: 'archive', label: '归档', glyph: 'archive', route: 'archive' },
  ];
  const globalMenu = [
    { key: 'today', label: '今日', glyph: 'grid', path: '/practice/today' },
    { key: 'clients', label: '客户', glyph: 'users', children: [
      { key: 'client-roster', label: '名册', path: '/practice/clients' },
      { key: 'intakes', label: '收案', path: '/practice/intakes' },
      { key: 'contacts', label: '联系人', path: '/practice/contacts' },
      { key: 'conflicts', label: '冲突预检', path: '/practice/conflicts' },
    ] },
    { key: 'schedule', label: '日程', glyph: 'calendar', path: '/practice/schedule' },
    { key: 'affairs', label: '事务', glyph: 'briefcase', children: [
      { key: 'casework', label: '按案办理', path: '/practice/operations' },
      { key: 'court-inbox', label: '法院来件', path: '/practice/operations/court-inbox' },
    ] },
    { key: 'global-finance', label: '财务', glyph: 'wallet', path: '/practice/finance' },
    { key: 'resources', label: '资料', glyph: 'book', children: [
      { key: 'library', label: '资料库', path: '/practice/resources' },
      { key: 'templates', label: '模板', path: '/practice/templates' },
      { key: 'reports', label: '报表', path: '/practice/reports' },
      { key: 'profile', label: '执业资料', path: '/practice/profile' },
      { key: 'audit', label: '操作记录', path: '/practice/audit' },
    ] },
  ];
  const globalPageTitles = {
    '/practice/today': '今日', '/practice/clients': '客户名册', '/practice/intakes': '收案',
    '/practice/contacts': '联系人', '/practice/conflicts': '利益冲突预检', '/practice/schedule': '日程',
    '/practice/operations': '按案办理', '/practice/operations/court-inbox': '法院来件',
    '/practice/finance': '全局财务', '/practice/resources': '资料库', '/practice/templates': '文书模板',
    '/practice/reports': '业务报表', '/practice/profile': '执业资料', '/practice/audit': '操作记录',
    '/matters/list': '案件总览', '/notifications': '通知', '/settings': '设置',
  };
  const LAST_CASE_ROUTES = 'lex-docs-last-case-route-v1';
  const SIDEBAR_COLLAPSED = 'lex-docs-sidebar-collapsed-v1';""")

# 2) Add sidebar styles without replacing the original Chronicle theme.
css = r"""
  const unifiedSidebarCss = `
    .sidebar{overflow:hidden;overscroll-behavior:contain;padding:12px 10px;gap:0;min-width:0}
    .sidebar .context,.sidebar>.navgroup,.sidebar>.spacer{display:none!important}
    #lex-sidebar-header{display:flex;align-items:center;gap:7px;padding:3px 5px 12px;border-bottom:1px solid var(--border)}
    #lex-sidebar-header .brand{margin:0;flex:1;min-width:0;font-size:19px;letter-spacing:-.6px}
    #lex-sidebar-collapse{width:30px;height:30px;display:grid;place-items:center;border:1px solid var(--border);border-radius:7px;color:var(--muted-foreground)}
    #lex-sidebar-collapse:hover{background:var(--sidebar-accent);color:var(--foreground)}
    #lex-sidebar-collapse svg{width:16px;height:16px}
    #lex-workspace-switcher{position:relative;margin:11px 0 2px}
    #lex-workspace-switcher-trigger{width:100%;min-height:54px;display:flex;align-items:center;gap:9px;padding:7px 9px;border:1px solid var(--border);border-radius:9px;background:var(--card);text-align:left}
    #lex-workspace-switcher-trigger:hover,[aria-expanded=true]#lex-workspace-switcher-trigger{background:var(--sidebar-accent)}
    .lx-switcher-mark{width:31px;height:31px;display:grid;place-items:center;flex:none;border-radius:8px;background:var(--sidebar-primary);color:var(--sidebar-primary-foreground)}
    .lx-switcher-mark svg{width:16px;height:16px}
    .lx-switcher-copy{display:grid;min-width:0;flex:1;gap:2px;line-height:1.3}
    .lx-switcher-copy strong{font-size:12px;font-weight:650;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .lx-switcher-copy small{font-size:10px;color:var(--muted-foreground);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .lx-switcher-chevron{width:15px;height:15px;color:var(--muted-foreground);flex:none}
    #lex-workspace-menu{position:absolute;z-index:120;top:calc(100% + 5px);left:0;right:0;padding:6px;border:1px solid var(--border);border-radius:9px;background:var(--popover);box-shadow:var(--surface-shadow-raised);display:grid;gap:3px}
    #lex-workspace-menu[hidden]{display:none}
    .lx-menu-caption{padding:7px 8px 4px;color:var(--muted-foreground);font-size:10px;font-weight:650}
    .lx-switch-option{display:flex;align-items:center;gap:8px;width:100%;padding:8px;border-radius:7px;text-align:left;font-size:12px}
    .lx-switch-option:hover,.lx-switch-option[aria-current=true]{background:var(--sidebar-accent);color:var(--sidebar-accent-foreground)}
    .lx-switch-option svg{width:16px;height:16px;flex:none}
    #lex-sidebar-scroll{flex:1;min-height:0;overflow-y:auto;overscroll-behavior:contain;padding:10px 1px 12px}
    .lx-nav-group{display:grid;gap:2px;margin-bottom:14px}
    .lx-nav-caption{padding:8px 10px 5px;color:var(--muted-foreground);font-size:10px;font-weight:650;letter-spacing:.025em}
    .lx-nav-item{width:100%;min-height:34px;display:flex;align-items:center;gap:9px;padding:7px 10px;border-radius:7px;text-align:left;color:var(--sidebar-foreground);font-size:13px;line-height:1.35}
    .lx-nav-item>svg{width:16px;height:16px;flex:none}
    .lx-nav-item>span{min-width:0;flex:1}
    .lx-nav-item:hover{background:var(--sidebar-accent);color:var(--sidebar-accent-foreground)}
    .lx-nav-item.active{background:var(--sidebar-accent);color:var(--sidebar-accent-foreground);font-weight:650}
    .lx-nav-item:focus-visible,#lex-workspace-switcher-trigger:focus-visible,#lex-sidebar-collapse:focus-visible{outline:2px solid var(--sidebar-ring);outline-offset:2px}
    .lx-nav-item:disabled{opacity:.42;cursor:not-allowed}
    .lx-nav-item:disabled:hover{background:transparent;color:var(--sidebar-foreground)}
    .lx-nav-parent .lx-nav-chevron{width:14px;height:14px;flex:none;color:var(--muted-foreground);transition:transform .2s ease}
    .lx-nav-parent.expanded .lx-nav-chevron{transform:rotate(90deg)}
    .lx-subnav{display:none;gap:1px;margin:2px 0 4px 18px;padding-left:9px;border-left:1px solid var(--sidebar-border)}
    .lx-nav-parent.expanded+.lx-subnav{display:grid}
    .lx-subnav .lx-nav-item{min-height:30px;padding:6px 9px;font-size:12px;color:var(--muted-foreground)}
    .lx-subnav .lx-nav-item.active{color:var(--sidebar-accent-foreground);background:var(--sidebar-accent);font-weight:650}
    #lex-current-case[aria-disabled=true]{opacity:.43;filter:grayscale(.65);pointer-events:none}
    #lex-current-case[aria-disabled=true] .lx-nav-caption{color:var(--muted-foreground)}
    #lex-sidebar-footer{flex:none;border-top:1px solid var(--sidebar-border);padding:9px 1px 0}
    #lex-global-footer{display:grid;gap:2px}
    #lex-user-area{margin-top:8px;padding:10px 7px 2px;border-top:1px solid var(--sidebar-border)}
    #lex-user-area .userbox{margin:0;padding:0;border:0}
    #lex-user-area .userbox>span{padding:6px 10px}
    #lex-user-area .userbox strong{font-size:12px}
    #lex-user-area .userbox small{font-size:10px}
    #lex-global-placeholder{max-width:760px;min-height:360px;margin:26px auto;padding:26px;border:1px solid var(--border);border-radius:12px;background:var(--card);display:grid;align-content:center;gap:12px;box-shadow:var(--surface-shadow)}
    #lex-global-placeholder h2{font-size:22px;color:var(--foreground)}
    #lex-global-placeholder p{font-size:13px;line-height:1.7;color:var(--muted-foreground)}
    #lex-global-placeholder code{font-size:11px;overflow-wrap:anywhere}
    #lex-global-placeholder .lx-case-choices{display:flex;flex-wrap:wrap;gap:8px;margin-top:8px}
    .lx-case-choice{border:1px solid var(--border);border-radius:7px;padding:8px 11px;background:var(--card);font-size:12px}
    .lx-case-choice:hover{background:var(--sidebar-accent)}
    .lx-current-case-empty{font-size:11px;color:var(--muted-foreground);padding:3px 10px 8px}
    .lx-preview-scenes{border:1px solid var(--border);border-radius:7px;padding:5px 9px;font-size:11px;color:var(--muted-foreground)}
    .lx-preview-scenes:hover{background:var(--muted);color:var(--foreground)}
    .lx-breadcrumb{display:inline-flex;align-items:center;gap:7px;min-width:0}
    .lx-breadcrumb svg{width:14px;height:14px}
    .app.lx-sidebar-collapsed{grid-template-columns:68px minmax(0,1fr)}
    .app.lx-sidebar-collapsed .sidebar{padding:11px 6px;align-items:center}
    .app.lx-sidebar-collapsed #lex-sidebar-header{width:100%;flex-direction:column;gap:7px;padding:0 0 9px}
    .app.lx-sidebar-collapsed #lex-sidebar-header .brand{margin:0;font-size:0}
    .app.lx-sidebar-collapsed #lex-sidebar-header .brandmark{margin:0}
    .app.lx-sidebar-collapsed #lex-sidebar-collapse{width:29px;height:27px}
    .app.lx-sidebar-collapsed #lex-workspace-switcher{width:100%}
    .app.lx-sidebar-collapsed #lex-workspace-switcher-trigger{justify-content:center;padding:7px 4px;min-height:42px}
    .app.lx-sidebar-collapsed .lx-switcher-copy,.app.lx-sidebar-collapsed .lx-switcher-chevron{display:none}
    .app.lx-sidebar-collapsed #lex-sidebar-scroll{width:100%;padding-top:8px}
    .app.lx-sidebar-collapsed .lx-nav-caption,.app.lx-sidebar-collapsed .lx-nav-item>span,.app.lx-sidebar-collapsed .lx-nav-chevron,.app.lx-sidebar-collapsed .lx-subnav{display:none!important}
    .app.lx-sidebar-collapsed .lx-nav-item{justify-content:center;padding:8px 4px}
    .app.lx-sidebar-collapsed .lx-nav-item>svg{width:18px;height:18px}
    .app.lx-sidebar-collapsed #lex-sidebar-footer{width:100%}
    .app.lx-sidebar-collapsed #lex-user-area{padding:9px 0 0}
    .app.lx-sidebar-collapsed #lex-user-area .userbox{justify-content:center}
    .app.lx-sidebar-collapsed #lex-user-area .userbox>div{display:none}
    @media(max-width:780px){.sidebar{height:100vh;position:sticky;display:flex;flex-direction:column;flex-wrap:nowrap;padding:12px 8px}.sidebar .lx-nav-item.active{display:flex}#lex-sidebar-scroll{display:block}#lex-global-footer{display:grid}}
    @media(prefers-reduced-motion:reduce){.lx-nav-parent .lx-nav-chevron{transition:none}}
  `;
"""
m=re.search(r"  const styleText = `([\s\S]*?)`;\n  function installStyle\(\)",s)
if not m: raise SystemExit('styleText insertion point not found')
s=s[:m.end()-len('  function installStyle()')]+css+'  function installStyle()'+s[m.end():]
s=s.replace('style.textContent = styleText;', 'style.textContent = styleText + unifiedSidebarCss;')

# 3) Global mode is encoded in the preview hash so the React fixture remains mounted on a valid case.
old="""  const parseRoute = () => {
    const hash = location.hash.slice(1);
    const [path, query = ''] = hash.split('?');
    const parts = path.split('/').filter(Boolean);
    const rawCase = parts[1] || 'A';
    const caseId = caseInfo[rawCase] ? rawCase : Object.keys(caseInfo).find(key => caseInfo[key].code === rawCase) || 'A';
    const section = parts[2] || 'review';
    const id = parts[3] || '';
    const event = parts[4] || '';
    const params = new URLSearchParams(query);
    if (params.get('delivery')) return { caseId, section: 'delivery', id: params.get('delivery'), event: params.get('deliveryEvent') || '' };
    if (params.get('document')) return { caseId, section: params.get('reviewIssue') ? 'review' : 'materials', id: params.get('document'), event: params.get('reviewIssue') || '' };
    if (params.get('deliveryDocument')) return { caseId, section: 'review', id: params.get('deliveryDocument'), event: '' };
    return { caseId, section, id, event };
  };"""
new="""  const parseRoute = () => {
    const hash = location.hash.slice(1);
    const [path, query = ''] = hash.split('?');
    const parts = path.split('/').filter(Boolean);
    const rawCase = parts[1] || 'A';
    const caseId = caseInfo[rawCase] ? rawCase : Object.keys(caseInfo).find(key => caseInfo[key].code === rawCase) || 'A';
    const section = parts[2] || 'review';
    const id = parts[3] || '';
    const event = parts[4] || '';
    const params = new URLSearchParams(query);
    if (params.get('global') === '1') return { caseId, section: 'global', id: '', event: '', global: true, globalPath: params.get('route') || '/practice/today' };
    if (params.get('delivery')) return { caseId, section: 'delivery', id: params.get('delivery'), event: params.get('deliveryEvent') || '' };
    if (params.get('document')) return { caseId, section: params.get('reviewIssue') ? 'review' : 'materials', id: params.get('document'), event: params.get('reviewIssue') || '' };
    if (params.get('deliveryDocument')) return { caseId, section: 'review', id: params.get('deliveryDocument'), event: '' };
    return { caseId, section, id, event, global: false };
  };"""
assert old in s
s=s.replace(old,new)

# 4) Replace old sidebar construction and navigation state.
start=s.index('  function sectionFor(route) {')
end=s.index('  function captureLegacyTriggers() {',start)
block=r'''  function sectionFor(route) {
    if (['drafts', 'review', 'delivery', 'seal'].includes(route.section)) return 'documents';
    if (['evidence', 'research'].includes(route.section)) return 'facts';
    return sections.some(([key]) => key === route.section) ? route.section : 'documents';
  }
  function readLastCaseRoutes() {
    try { return JSON.parse(localStorage.getItem(LAST_CASE_ROUTES)) || {}; } catch { return {}; }
  }
  function recordCaseRoute(route) {
    if (!route || route.global || !caseInfo[route.caseId]) return;
    const saved = readLastCaseRoutes();
    const next = { section: route.section, id: route.id || '', event: route.event || '' };
    if (JSON.stringify(saved[route.caseId]) !== JSON.stringify(next)) {
      saved[route.caseId] = next;
      try { localStorage.setItem(LAST_CASE_ROUTES, JSON.stringify(saved)); } catch {}
    }
  }
  function caseRouteFor(caseId) {
    const saved = readLastCaseRoutes()[caseId];
    if (saved && saved.section) return navHash(caseId, saved.section, saved.id || '', saved.event || '');
    return caseId === 'A' ? navHash('A', 'review', 'A-D02') : navHash('B', 'review', 'B-D03');
  }
  function globalHash(caseId, path) {
    const base = navHash(caseId || 'A', 'review', caseId === 'B' ? 'B-D03' : 'A-D02');
    return base + '?global=1&route=' + encodeURIComponent(path);
  }
  function navigateGlobal(path) {
    const route = parseRoute();
    recordCaseRoute(route);
    navigate(globalHash(route.caseId || 'A', path));
  }
  function navigateCase(caseId) { navigate(caseRouteFor(caseId)); }
  function switchWorkspace(target) {
    if (target === 'global') { navigateGlobal('/practice/today'); return; }
    if (caseInfo[target]) navigateCase(target);
  }
  function ensureSidebar() {
    const sidebar = document.querySelector('.sidebar');
    if (!sidebar) return;
    if (!sidebar.querySelector('#lex-sidebar-header')) {
      const brand = sidebar.querySelector('.brand');
      const legacyContext = sidebar.querySelector('.context');
      const legacyImport = [...sidebar.children].find(node => node.classList?.contains('navitem') && node.textContent.includes('工作区模板'));
      const scenesButton = [...sidebar.children].find(node => node.classList?.contains('navitem') && node.textContent.includes('验收场景'));
      const userbox = sidebar.querySelector('.userbox');
      [...sidebar.children].forEach(node => {
        if ([brand, legacyContext, userbox, legacyImport, scenesButton].includes(node)) return;
        node.remove();
      });
      if (legacyContext) legacyContext.style.display = 'none';
      if (legacyImport) { legacyImport.classList.add('lex-legacy-import'); legacyImport.style.display = 'none'; }
      if (scenesButton) { scenesButton.id = 'lex-legacy-scenes'; scenesButton.style.display = 'none'; }

      const header = document.createElement('div');
      header.id = 'lex-sidebar-header';
      if (brand) header.appendChild(brand);
      const collapse = document.createElement('button');
      collapse.type = 'button'; collapse.id = 'lex-sidebar-collapse';
      collapse.setAttribute('aria-label', '折叠侧栏'); collapse.setAttribute('aria-pressed', 'false');
      collapse.innerHTML = icon('grip');
      collapse.addEventListener('click', () => {
        const app = document.querySelector('.app');
        const collapsed = app.classList.toggle('lx-sidebar-collapsed');
        collapse.setAttribute('aria-label', collapsed ? '展开侧栏' : '折叠侧栏');
        collapse.setAttribute('aria-pressed', String(collapsed));
        try { localStorage.setItem(SIDEBAR_COLLAPSED, collapsed ? '1' : '0'); } catch {}
      });
      header.appendChild(collapse);
      sidebar.appendChild(header);

      const switcher = document.createElement('div');
      switcher.id = 'lex-workspace-switcher';
      switcher.innerHTML = `<button type="button" id="lex-workspace-switcher-trigger" aria-haspopup="menu" aria-expanded="false">
        <span class="lx-switcher-mark">${icon('briefcase')}</span>
        <span class="lx-switcher-copy"><strong id="lx-switcher-title">当前案件</strong><small id="lx-switcher-detail">选择案件</small></span>
        ${icon('chevron')}
      </button>
      <div id="lex-workspace-menu" role="menu" aria-label="切换工作区或案件" hidden>
        <div class="lx-menu-caption">工作区</div>
        <button type="button" class="lx-switch-option" role="menuitem" data-switch-global>${icon('grid')}<span>全局工作区（未选案件）</span></button>
        <div class="lx-menu-caption">当前案件</div>
        <button type="button" class="lx-switch-option" role="menuitem" data-switch-case="A">${icon('briefcase')}<span>澄禾设备采购争议</span></button>
        <button type="button" class="lx-switch-option" role="menuitem" data-switch-case="B">${icon('briefcase')}<span>青岚仓储交付争议</span></button>
        <div class="lx-menu-caption">其他入口</div>
        <button type="button" class="lx-switch-option" role="menuitem" data-switch-cases>${icon('folder')}<span>案件总览</span></button>
      </div>`;
      sidebar.appendChild(switcher);

      const scroll = document.createElement('div');
      scroll.id = 'lex-sidebar-scroll';
      const current = document.createElement('section');
      current.id = 'lex-current-case';
      current.className = 'lx-nav-group';
      current.setAttribute('aria-label', '当前案件');
      const currentButtons = currentMenu.map(item => {
        if (item.children) {
          const submenuId = 'lx-sub-' + item.key;
          return `<button type="button" class="lx-nav-item lx-nav-parent" data-parent="${item.key}" aria-expanded="false" aria-controls="${submenuId}" title="${item.label}">${icon(item.glyph)}<span>${item.label}</span>${icon('chevron')}</button>
            <div class="lx-subnav" id="${submenuId}">${item.children.map(child => `<button type="button" class="lx-nav-item" data-case-route="${child.route}" data-nav-child="${child.key}" title="${child.label}">${icon('chevron')}<span>${child.label}</span></button>`).join('')}</div>`;
        }
        return `<button type="button" class="lx-nav-item" data-case-route="${item.route}" data-nav-key="${item.key}" title="${item.label}">${icon(item.glyph)}<span>${item.label}</span></button>`;
      }).join('');
      current.innerHTML = `<div class="lx-nav-caption">当前案件</div><div id="lex-case-meta"><strong class="lx-case-name"></strong><small class="lx-case-code"></small></div><nav id="lex-matter-nav" aria-label="当前案件">${currentButtons}</nav>`;
      scroll.appendChild(current);

      const workspace = document.createElement('section');
      workspace.id = 'lex-workspace-nav';
      workspace.className = 'lx-nav-group';
      workspace.setAttribute('aria-label', '工作区');
      const globalButtons = globalMenu.map(item => {
        if (item.children) {
          const submenuId = 'lx-global-sub-' + item.key;
          return `<button type="button" class="lx-nav-item lx-nav-parent" data-global-parent="${item.key}" aria-expanded="false" aria-controls="${submenuId}" title="${item.label}">${icon(item.glyph)}<span>${item.label}</span>${icon('chevron')}</button>
            <div class="lx-subnav" id="${submenuId}">${item.children.map(child => `<button type="button" class="lx-nav-item" data-global-route="${child.path}" data-nav-child="${child.key}" title="${child.label}">${icon('chevron')}<span>${child.label}</span></button>`).join('')}</div>`;
        }
        return `<button type="button" class="lx-nav-item" data-global-route="${item.path}" data-nav-key="${item.key}" title="${item.label}">${icon(item.glyph)}<span>${item.label}</span></button>`;
      }).join('');
      workspace.innerHTML = `<div class="lx-nav-caption">工作区</div><nav id="lex-global-nav" aria-label="全局工作区">${globalButtons}</nav>`;
      scroll.appendChild(workspace);
      sidebar.appendChild(scroll);

      const footer = document.createElement('div');
      footer.id = 'lex-sidebar-footer';
      footer.innerHTML = `<nav id="lex-global-footer" aria-label="固定入口">
        <button type="button" class="lx-nav-item" data-global-route="/matters/list" title="案件">${icon('folder')}<span>案件</span></button>
        <button type="button" class="lx-nav-item" data-global-route="/notifications" title="通知">${icon('bell')}<span>通知</span></button>
        <button type="button" class="lx-nav-item" data-global-route="/settings" title="设置">${icon('settings')}<span>设置</span></button>
      </nav>`;
      if (userbox) { const user = document.createElement('div'); user.id = 'lex-user-area'; user.appendChild(userbox); footer.appendChild(user); }
      sidebar.appendChild(footer);

      const trigger = document.getElementById('lex-workspace-switcher-trigger');
      const menu = document.getElementById('lex-workspace-menu');
      const closeMenu = (restore = false) => { menu.hidden = true; trigger.setAttribute('aria-expanded', 'false'); if (restore) trigger.focus(); };
      trigger.addEventListener('click', () => {
        menu.hidden = !menu.hidden; trigger.setAttribute('aria-expanded', String(!menu.hidden));
        if (!menu.hidden) menu.querySelector('[role="menuitem"]')?.focus();
      });
      menu.addEventListener('click', event => {
        const option = event.target.closest('[data-switch-global],[data-switch-case],[data-switch-cases]');
        if (!option) return;
        closeMenu(true);
        if (option.hasAttribute('data-switch-global')) switchWorkspace('global');
        else if (option.dataset.switchCase) switchWorkspace(option.dataset.switchCase);
        else navigateGlobal('/matters/list');
      });
      menu.addEventListener('keydown', event => {
        const items = [...menu.querySelectorAll('[role="menuitem"]')];
        const index = items.indexOf(document.activeElement);
        if (event.key === 'Escape') { event.preventDefault(); closeMenu(true); }
        else if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
          event.preventDefault(); const delta = event.key === 'ArrowDown' ? 1 : -1;
          items[(index + delta + items.length) % items.length]?.focus();
        } else if (event.key === 'Home') { event.preventDefault(); items[0]?.focus(); }
        else if (event.key === 'End') { event.preventDefault(); items.at(-1)?.focus(); }
      });
      document.addEventListener('pointerdown', event => { if (!switcher.contains(event.target) && !menu.hidden) closeMenu(false); });

      const bindParentToggle = nav => nav.querySelectorAll('.lx-nav-parent').forEach(button => {
        button.addEventListener('click', () => {
          const expanded = button.getAttribute('aria-expanded') !== 'true';
          button.setAttribute('aria-expanded', String(expanded)); button.classList.toggle('expanded', expanded);
        });
      });
      const bindNavigationKeys = nav => nav.addEventListener('keydown', event => {
        if (event.key === 'ArrowRight') {
          const parent = event.target.closest('.lx-nav-parent');
          if (parent && parent.getAttribute('aria-expanded') !== 'true') {
            event.preventDefault(); parent.click(); document.getElementById(parent.getAttribute('aria-controls'))?.querySelector('button:not(:disabled)')?.focus();
          }
        } else if (event.key === 'ArrowLeft') {
          const child = event.target.closest('.lx-subnav .lx-nav-item');
          if (child) { event.preventDefault(); const parent = document.querySelector(`[aria-controls="${child.closest('.lx-subnav').id}"]`); parent?.click(); parent?.focus(); }
        }
      });
      bindParentToggle(current.querySelector('nav')); bindParentToggle(workspace.querySelector('nav'));
      bindNavigationKeys(current.querySelector('nav')); bindNavigationKeys(workspace.querySelector('nav'));
      current.querySelectorAll('[data-case-route]').forEach(button => button.addEventListener('click', () => navigateSection(button.dataset.caseRoute)));
      workspace.querySelectorAll('[data-global-route]').forEach(button => button.addEventListener('click', () => navigateGlobal(button.dataset.globalRoute)));
      footer.querySelectorAll('[data-global-route]').forEach(button => button.addEventListener('click', () => navigateGlobal(button.dataset.globalRoute)));

      try {
        const collapsed = localStorage.getItem(SIDEBAR_COLLAPSED) === '1';
        document.querySelector('.app').classList.toggle('lx-sidebar-collapsed', collapsed);
        collapse.setAttribute('aria-label', collapsed ? '展开侧栏' : '折叠侧栏');
        collapse.setAttribute('aria-pressed', String(collapsed));
      } catch {}
    }
    syncCaseMeta();
    ensureTopbar();
  }
  function syncCaseMeta() {
    const route = parseRoute();
    const info = caseInfo[route.caseId];
    const meta = document.getElementById('lex-case-meta');
    const title = document.getElementById('lx-switcher-title');
    const detail = document.getElementById('lx-switcher-detail');
    const menu = document.getElementById('lex-workspace-menu');
    const current = document.getElementById('lex-current-case');
    const hasCase = !!info && !route.global;
    if (current) {
      current.inert = !hasCase;
      current.setAttribute('aria-disabled', String(!hasCase));
      current.querySelectorAll('button').forEach(button => { button.disabled = !hasCase; });
    }
    if (meta) meta.innerHTML = hasCase ? `<strong>${esc(info.name)}</strong><small>${esc(info.code)}</small>` : '<div class="lx-current-case-empty">未选择案件 · 当前为全局工作区</div>';
    if (title) title.textContent = hasCase ? info.name : '全局工作区';
    if (detail) detail.textContent = hasCase ? info.code : '未选择案件';
    menu?.querySelectorAll('[data-switch-case]').forEach(button => button.setAttribute('aria-current', String(hasCase && button.dataset.switchCase === route.caseId)));
    menu?.querySelector('[data-switch-global]')?.setAttribute('aria-current', String(!hasCase));
  }
  function ensureTopbar() {
    const top = document.querySelector('.top');
    if (!top) return;
    top.querySelector('#lex-case-switcher')?.remove();
    const route = parseRoute();
    const first = top.querySelector('span:first-child');
    const label = route.global ? (globalPageTitles[route.globalPath] || '工作区') : (pageTitles[route.section] || '案件工作区');
    const caseName = route.global ? '工作区' : caseInfo[route.caseId]?.name || '当前案件';
    if (first && first.dataset.lexBreadcrumb !== caseName + '|' + label) {
      first.dataset.lexBreadcrumb = caseName + '|' + label;
      first.classList.add('lx-breadcrumb');
      first.innerHTML = icon('briefcase') + `<span>${esc(caseName)}</span>` + icon('chevron') + `<b>${esc(label)}</b>`;
    }
    if (!top.querySelector('.lx-preview-scenes')) {
      const button = document.createElement('button'); button.type = 'button'; button.className = 'lx-preview-scenes'; button.textContent = '验收场景';
      button.addEventListener('click', () => document.getElementById('lex-legacy-scenes')?.click());
      const review = top.querySelector('.reviewlink'); top.insertBefore(button, review || null);
    }
  }
  function navigateSection(section) {
    const route = parseRoute();
    const db = readDb();
    const matter = db?.[route.caseId];
    if (!matter) return;
    if (section === 'documents' || section === 'delivery') {
      state.type = '全部'; state.status = '全部'; state.search = '';
      const selected = ['delivery', 'review', 'drafts', 'seal'].includes(route.section) ? route.id : '';
      const doc = matter.docs.find(item => item.id === selected);
      const pack = matter.packs.find(item => item.id === selected);
      const seal = matter.seals.find(item => item.id === selected);
      if (seal) { navigate(navHash(route.caseId, 'seal', seal.id)); return; }
      const target = doc ? (doc.status === 'DRAFT' ? 'drafts' : 'review') : pack ? 'delivery' : matter.docs[0] ? (matter.docs[0].status === 'DRAFT' ? 'drafts' : 'review') : 'delivery';
      const id = doc?.id || pack?.id || matter.docs[0]?.id || matter.packs[0]?.id || '';
      navigate(navHash(route.caseId, target, id)); return;
    }
    if (section === 'materials') {
      const file = matter.files[0] || matter.docs[0]; navigate(navHash(route.caseId, 'materials', file?.id || '')); return;
    }
    if (section === 'seal') { navigate(navHash(route.caseId, 'seal', matter.seals[0]?.id || '')); return; }
    if (section === 'archive') { navigate(navHash(route.caseId, 'archive', matter.packs[0]?.id || '')); return; }
    navigate(navHash(route.caseId, section));
  }
  function setActiveNav(route) {
    const current = document.getElementById('lex-current-case');
    const hasCase = !route.global;
    if (current) {
      current.inert = !hasCase;
      current.setAttribute('aria-disabled', String(!hasCase));
      current.querySelectorAll('button').forEach(button => { button.disabled = !hasCase; });
    }
    const activeChild = route.section === 'research' ? 'research'
      : route.section === 'evidence' ? 'evidence'
      : route.section === 'seal' ? 'seal'
      : ['drafts', 'review', 'delivery'].includes(route.section) ? 'delivery'
      : route.section;
    const activeParent = sectionFor(route);
    const currentNav = document.getElementById('lex-matter-nav');
    currentNav?.querySelectorAll('[data-nav-key],[data-parent],[data-nav-child]').forEach(button => {
      const isChild = button.dataset.navChild === activeChild;
      const isParent = button.dataset.navKey === activeParent || button.dataset.parent === activeParent;
      const selected = isChild || (isParent && !['facts', 'documents'].includes(activeParent));
      button.classList.toggle('active', selected);
      if (selected && !button.dataset.parent) button.setAttribute('aria-current', 'page'); else button.removeAttribute('aria-current');
    });
    currentNav?.querySelectorAll('[data-parent]').forEach(button => {
      const expanded = button.dataset.parent === activeParent;
      if (expanded) { button.classList.add('expanded'); button.setAttribute('aria-expanded', 'true'); }
    });
    const path = route.global ? route.globalPath : '';
    const globalNav = document.getElementById('lex-global-nav');
    globalNav?.querySelectorAll('[data-global-route],[data-global-parent]').forEach(button => {
      const selected = button.dataset.globalRoute === path;
      button.classList.toggle('active', selected);
      if (selected) button.setAttribute('aria-current', 'page'); else button.removeAttribute('aria-current');
    });
    globalNav?.querySelectorAll('[data-global-parent]').forEach(button => {
      const submenu = document.getElementById(button.getAttribute('aria-controls'));
      const child = [...(submenu?.querySelectorAll('[data-global-route]') || [])].some(item => item.dataset.globalRoute === path);
      if (child) { button.classList.add('expanded'); button.setAttribute('aria-expanded', 'true'); }
    });
    document.querySelectorAll('#lex-global-footer [data-global-route]').forEach(button => {
      const selected = route.global && button.dataset.globalRoute === path;
      button.classList.toggle('active', selected);
      if (selected) button.setAttribute('aria-current', 'page'); else button.removeAttribute('aria-current');
    });
  }
'''
s=s[:start]+block+s[end:]

# 5) Extend the icon helper with Chronicle shell icons.
s=s.replace("""      stamp: '<rect x=\"4\" y=\"14\" width=\"16\" height=\"7\" rx=\"1\"/><path d=\"M8 14V9a4 4 0 0 1 8 0v5M7 18h10\"/>',""", """      stamp: '<rect x=\"4\" y=\"14\" width=\"16\" height=\"7\" rx=\"1\"/><path d=\"M8 14V9a4 4 0 0 1 8 0v5M7 18h10\"/>',
      users: '<path d=\"M16 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2\"/><circle cx=\"10\" cy=\"7\" r=\"4\"/><path d=\"M20 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75\"/>',
      briefcase: '<rect x=\"3\" y=\"7\" width=\"18\" height=\"14\" rx=\"2\"/><path d=\"M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M3 12h18M10 12v2h4v-2\"/>',
      bell: '<path d=\"M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4\"/>',
      settings: '<circle cx=\"12\" cy=\"12\" r=\"3\"/><path d=\"m19.4 15 .1.1 1.4 1.1-1.4 2.4-1.7-.6a7 7 0 0 1-1.4.8l-.3 1.8h-2.8l-.3-1.8a7 7 0 0 1-1.4-.8l-1.7.6-1.4-2.4 1.4-1.1a7 7 0 0 1 0-1.6L6.5 12.4l1.4-2.4 1.7.6a7 7 0 0 1 1.4-.8l.3-1.8h2.8l.3 1.8a7 7 0 0 1 1.4.8l1.7-.6 1.4 2.4-1.4 1.1a7 7 0 0 1-.1 1.5Z\"/>',
      chevron: '<path d=\"m9 18 6-6-6-6\"/>',
      grip: '<rect x=\"3\" y=\"3\" width=\"7\" height=\"7\" rx=\"1\"/><rect x=\"14\" y=\"3\" width=\"7\" height=\"7\" rx=\"1\"/><rect x=\"3\" y=\"14\" width=\"7\" height=\"7\" rx=\"1\"/><rect x=\"14\" y=\"14\" width=\"7\" height=\"7\" rx=\"1\"/>',""")

# 6) Replace placeholder rendering and add global-workspace preview state.
old="""  function renderPlaceholder(route) {
    const content = document.querySelector('.content');
    const board = content?.querySelector('.board');
    if (!content || !board) return;
    const label = sections.find(([key]) => key === route.section)?.[1] || (route.section === 'research' ? '事实与研究' : route.section);
    let placeholder = content.querySelector('.lex-section-placeholder');
    if (!placeholder) {
      placeholder = document.createElement('section');
      placeholder.className = 'lex-section-placeholder';
      board.insertAdjacentElement('afterend', placeholder);
    }
    if (board.style.display !== 'none') board.style.display = 'none';
    const signature = `${route.caseId}|${route.section}`;
    if (placeholder.dataset.lexSection === signature) return;
    placeholder.dataset.lexSection = signature;
    placeholder.innerHTML = `<div class=\"lex-placeholder-icon\">${icon('grid')}</div><h2>${esc(label)}</h2><p>这是 Chronicle 案内的独立分区。为避免与其他工作组重复设计，本轮仅校准九分区导航与文书工作区；此分区保留原入口，不在本预览中重做。</p><button class=\"btn primary\" data-lex-back>返回文书与交付</button>`;
    placeholder.querySelector('[data-lex-back]')?.addEventListener('click', () => navigateSection('delivery'));
  }"""
new="""  function renderPlaceholder(route) {
    const content = document.querySelector('.content');
    const board = content?.querySelector('.board');
    if (!content || !board) return;
    content.querySelector('#lex-global-placeholder')?.remove();
    const label = pageTitles[route.section] || route.section;
    let placeholder = content.querySelector('.lex-section-placeholder');
    if (!placeholder) {
      placeholder = document.createElement('section');
      placeholder.className = 'lex-section-placeholder';
      board.insertAdjacentElement('afterend', placeholder);
    }
    if (board.style.display !== 'none') board.style.display = 'none';
    const signature = `${route.caseId}|${route.section}`;
    if (placeholder.dataset.lexSection === signature) return;
    placeholder.dataset.lexSection = signature;
    const realPath = route.section === 'archive' ? `/practice/archive?matter=${route.caseId}` : `/matters/${route.caseId}/${route.section}`;
    placeholder.innerHTML = `<div class=\"lex-placeholder-icon\">${icon('grid')}</div><h2>${esc(label)}</h2><p>本页保留 Chronicle 已核实的案内入口。当前仅演示统一侧栏、路由激活和案件上下文；该业务内容由对应工作组接入。</p><code>${esc(realPath)}</code><button class=\"btn primary\" data-lex-back>返回文书台</button>`;
    placeholder.querySelector('[data-lex-back]')?.addEventListener('click', () => navigateSection('documents'));
  }
  function renderGlobalPlaceholder(route) {
    const content = document.querySelector('.content');
    const board = content?.querySelector('.board');
    if (!content || !board) return;
    content.querySelector('.lex-section-placeholder')?.remove();
    if (board.style.display !== 'none') board.style.display = 'none';
    const actions = content.querySelector('.lex-doc-actions');
    if (actions) actions.style.display = 'none';
    const path = route.globalPath || '/practice/today';
    const title = globalPageTitles[path] || '工作区';
    const header = content.querySelector(':scope > div:first-child h1');
    if (header) header.textContent = title;
    const description = content.querySelector(':scope > div:first-child p');
    if (description) description.textContent = `全局工作区 · 目标路由 ${path}`;
    let placeholder = content.querySelector('#lex-global-placeholder');
    if (!placeholder) {
      placeholder = document.createElement('section');
      placeholder.id = 'lex-global-placeholder';
      board.insertAdjacentElement('afterend', placeholder);
    }
    if (placeholder.dataset.lexPath === path) return;
    placeholder.dataset.lexPath = path;
    const cases = path === '/matters/list' ? `<div class=\"lx-case-choices\"><button class=\"lx-case-choice\" data-global-case=\"A\">澄禾设备采购争议 · CH-2026-001</button><button class=\"lx-case-choice\" data-global-case=\"B\">青岚仓储交付争议 · QL-2026-002</button></div>` : '';
    placeholder.innerHTML = `<div class=\"lex-placeholder-icon\">${icon('grid')}</div><h2>${esc(title)}</h2><p>这是统一侧栏的全局入口预览。当前不模拟该业务组的内容；正式页面沿用 Chronicle 已核实的路由与业务实现。</p><code>${esc(path)}</code>${cases}<p>当前案件分区已按规则置灰。可从左上工作区切换器选择案件并恢复该案上次打开的分区。</p>`;
    placeholder.querySelectorAll('[data-global-case]').forEach(button => button.addEventListener('click', () => switchWorkspace(button.dataset.globalCase)));
  }"""
assert old in s
s=s.replace(old,new)

# 7) Page title and global/case route rendering.
s=s.replace("const heading = work ? '文书与交付' : (route.section === 'materials' ? '材料与卷宗' : '结案与归档');", "const heading = route.section === 'seal' ? pageTitles.seal : work ? '文书与交付' : (pageTitles[route.section] || '案件工作区');")
start_all=s.index('  function renderAll() {')
end_all=s.index('  function scheduleRender() {', start_all)
new_all = r'''  function renderAll() {
    const app = document.querySelector('.app');
    if (!app) return;
    const route = parseRoute();
    ensureSidebar(); ensureTopbar(); captureLegacyTriggers(); removeOldNavigation(); setActiveNav(route);
    if (route.global) { renderGlobalPlaceholder(route); syncCaseMeta(); return; }
    const db = readDb();
    if (!db?.[route.caseId]) return;
    recordCaseRoute(route);
    syncCaseMeta();
    const content = document.querySelector('.content');
    const board = content?.querySelector('.board');
    const work = ['drafts', 'review', 'delivery', 'seal'].includes(route.section);
    const group = work ? 'documents' : route.section;
    if (state.lastGroup !== group) {
      state.type = '全部'; state.status = '全部'; state.search = '';
      state.lastGroup = group;
    }
    if (route.section === 'seal' && state.type === '全部') state.type = '用印申请';
    ensureActionBar(route);
    if (scene() === 'error') {
      if (board && board.dataset.lexError !== '1') {
        board.innerHTML = `<div class="lex-error-state"><div>${icon('file')}</div><h2>无法读取本案记录</h2><p>当前预览模拟读取失败。恢复后可继续查看原有记录。</p><button class="btn primary" data-lex-retry>重新读取</button></div>`;
        board.dataset.lexError = '1';
        board.style.gridTemplateColumns = '1fr';
        board.querySelector('[data-lex-retry]')?.addEventListener('click', () => { localStorage.setItem(SCENE_KEY, 'normal'); location.reload(); });
      }
      return;
    }
    if (board?.dataset.lexError === '1') { board.dataset.lexError = ''; location.reload(); return; }
    const supported = work || ['materials', 'archive'].includes(route.section);
    if (!supported) { renderPlaceholder(route); return; }
    content?.querySelector('.lex-section-placeholder')?.remove();
    content?.querySelector('#lex-global-placeholder')?.remove();
    const actions = content?.querySelector('.lex-doc-actions');
    if (actions) actions.style.display = '';
    if (board && board.style.display !== '') board.style.display = '';
    renderQueue(route, db);
    renderInspector(route, db);
    ensureResizeHandles(board);
    const header = content?.querySelector(':scope > div:first-child h1');
    const heading = route.section === 'seal' ? pageTitles.seal : work ? '文书与交付' : (pageTitles[route.section] || '案件工作区');
    if (header && header.textContent !== heading) header.textContent = heading;
  }
  '''
s=s[:start_all] + new_all + s[end_all:]

# 8) Keep full page titles and route-aware action bar labels.
s=s.replace("if (h1) h1.textContent = work ? '文书与交付' : (sections.find(([key]) => key === route.section)?.[1] || (route.section === 'archive' ? '归档引用' : route.section === 'seal' ? '用印' : '案内工作区'));", "if (h1) h1.textContent = route.section === 'seal' ? pageTitles.seal : work ? '文书与交付' : (pageTitles[route.section] || '案内工作区');")

# 9) Icon paths used by the Chronicle switcher and fixed footer.
s=s.replace("""      stamp: '<rect x=\"4\" y=\"14\" width=\"16\" height=\"7\" rx=\"1\"/><path d=\"M8 14V9a4 4 0 0 1 8 0v5M7 18h10\"/>',""", """      stamp: '<rect x=\"4\" y=\"14\" width=\"16\" height=\"7\" rx=\"1\"/><path d=\"M8 14V9a4 4 0 0 1 8 0v5M7 18h10\"/>',
      users: '<path d=\"M16 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2\"/><circle cx=\"10\" cy=\"7\" r=\"4\"/><path d=\"M20 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75\"/>',
      briefcase: '<rect x=\"3\" y=\"7\" width=\"18\" height=\"14\" rx=\"2\"/><path d=\"M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M3 12h18M10 12v2h4v-2\"/>',
      bell: '<path d=\"M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4\"/>',
      settings: '<circle cx=\"12\" cy=\"12\" r=\"3\"/><path d=\"M19.4 15.1 21 16.4l-1.4 2.4-1.8-.6a7 7 0 0 1-1.4.8l-.3 1.8h-2.8l-.3-1.8a7 7 0 0 1-1.4-.8l-1.7.6-1.4-2.4 1.4-1.3a7 7 0 0 1 0-1.6l-1.4-1.1 1.4-2.4 1.7.6a7 7 0 0 1 1.4-.8l.3-1.8h2.8l.3 1.8a7 7 0 0 1 1.4.8l1.8-.6 1.4 2.4-1.6 1.1a7 7 0 0 1 0 1.7Z\"/>',
      chevron: '<path d=\"m9 18 6-6-6-6\"/>',
      grip: '<rect x=\"3\" y=\"3\" width=\"7\" height=\"7\" rx=\"1\"/><rect x=\"14\" y=\"3\" width=\"7\" height=\"7\" rx=\"1\"/><rect x=\"3\" y=\"14\" width=\"7\" height=\"7\" rx=\"1\"/><rect x=\"14\" y=\"14\" width=\"7\" height=\"7\" rx=\"1\"/>',""")

p.write_text(s)
print('updated', p, 'bytes', len(s))

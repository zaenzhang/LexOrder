/*
 * In-place refinement for the original LexOrder document lifecycle preview.
 * The React app remains the source of truth for business actions and detail
 * rendering. This layer applies the coordinator's unified Chronicle shell, list/inspector and adds
 * a full-page template wizard that writes the same synthetic document shape.
 */
(() => {
  const STORAGE_KEY = 'lex-docs-95-v3';
  const SCENE_KEY = 'lex-docs-scene-v3';
  // Coordinator-owned shell contract: eight current-case entries, nested facts/documents,
  // global workspace navigation and fixed footer. The seal route remains independently addressable under 文书.
  // Sidebar labels are deliberately short; full page titles remain in the content area.
  const sections = [
    ['overview', '概览', 'grid'], ['tasks', '程序', 'calendar'], ['materials', '材料', 'folder'],
    ['evidence', '事实', 'book'], ['delivery', '文书', 'file'], ['records', '记录', 'clock'],
    ['finance', '财务', 'wallet'], ['archive', '归档', 'archive'],
  ];
  const pageTitles = {
    overview: '案件概览', tasks: '程序与任务', materials: '材料与卷宗', evidence: '争点证据对照',
    research: '研究工作区', delivery: '文书与交付', seal: '用印管理', records: '办理记录',
    finance: '案件财务', archive: '案件归档',
  };
  const currentMenu = [
    { key: 'overview', label: '概览', glyph: 'grid', route: 'overview' },
    { key: 'tasks', label: '程序', glyph: 'calendar', route: 'tasks' },
    { key: 'materials', label: '材料', glyph: 'folder', route: 'materials' },
    { key: 'facts', label: '事实', glyph: 'book', children: [
      { key: 'evidence', label: '争点', route: 'evidence' },
      { key: 'research', label: '研究', route: 'research' },
    ] },
    { key: 'documents', label: '文书', glyph: 'file', children: [
      { key: 'delivery', label: '文书台', route: 'delivery' },
      { key: 'seal', label: '用印', route: 'seal' },
    ] },
    { key: 'records', label: '记录', glyph: 'clock', route: 'records' },
    { key: 'finance', label: '财务', glyph: 'wallet', route: 'finance' },
    { key: 'archive', label: '归档', glyph: 'archive', route: 'archive' },
  ];
  const globalMenu = [
    { key: 'today', label: '今日', glyph: 'grid', path: '/practice/today' },
    { key: 'clients', label: '客户', glyph: 'users', children: [
      { key: 'client-roster', label: '名册', path: '/practice/clients' },
      { key: 'intakes', label: '收案', path: '/practice/intakes' },
      { key: 'contacts', label: '联系人', path: '/practice/contacts' },
      { key: 'conflicts', label: '冲突预检', path: '/practice/conflicts' },
    ] },
    { key: 'schedule', label: '日程', glyph: 'calendar', path: '/practice/schedule' },
    { key: 'affairs', label: '事务', glyph: 'briefcase', children: [
      { key: 'casework', label: '按案办理', path: '/practice/operations' },
      { key: 'court-inbox', label: '法院来件', path: '/practice/operations/court-inbox' },
    ] },
    { key: 'global-finance', label: '财务', glyph: 'wallet', path: '/practice/finance' },
    { key: 'resources', label: '资料', glyph: 'book', children: [
      { key: 'library', label: '资料库', path: '/practice/resources' },
      { key: 'templates', label: '模板', path: '/practice/templates' },
      { key: 'reports', label: '报表', path: '/practice/reports' },
      { key: 'profile', label: '执业资料', path: '/practice/profile' },
      { key: 'audit', label: '操作记录', path: '/practice/audit' },
    ] },
  ];
  const globalPageTitles = {
    '/practice/today': '今日', '/practice/clients': '客户名册', '/practice/intakes': '收案',
    '/practice/contacts': '联系人', '/practice/conflicts': '利益冲突预检', '/practice/schedule': '日程',
    '/practice/operations': '按案办理', '/practice/operations/court-inbox': '法院来件',
    '/practice/finance': '全局财务', '/practice/resources': '资料库', '/practice/templates': '文书模板',
    '/practice/reports': '业务报表', '/practice/profile': '执业资料', '/practice/audit': '操作记录',
    '/matters/list': '案件总览', '/notifications': '通知', '/settings': '设置',
  };
  const LAST_CASE_ROUTES = 'lex-docs-last-case-route-v1';
  const SIDEBAR_COLLAPSED = 'lex-docs-sidebar-collapsed-v1';
  const labels = {
    DRAFT: '草稿', PENDING_REVIEW: '待复核', APPROVED: '已批准', FILED: '已入卷',
    PREPARED: '已冻结', EXPORTED: '已导出，未登记发送', SENT: '已登记送出',
    RECEIVED: '收悉', REPLIED: '客户回复', CONTENT_CONFIRMED: '客户确认内容',
    SEND_CORRECTION: '发送更正', PENDING: '待决定', STAMPED: '已登记实盖',
    CANCELLED: '已撤销', REJECTED: '已驳回', UNAVAILABLE: '记录不可查看',
  };
  const colors = {
    DRAFT: 'neutral', PENDING_REVIEW: 'amber', APPROVED: 'green', FILED: 'green',
    PREPARED: 'neutral', EXPORTED: 'blue', SENT: 'blue', RECEIVED: 'green',
    PENDING: 'amber', STAMPED: 'green', REJECTED: 'neutral', CANCELLED: 'neutral',
    UNAVAILABLE: 'neutral',
  };

  const styleText = `
    .sidebar{overflow-y:auto;overscroll-behavior:contain}
    .sidebar .context{display:none!important}
    .sidebar .navitem.active{background:var(--sidebar-accent);color:var(--sidebar-accent-foreground);font-weight:650}
    #lex-global-nav,#lex-matter-nav,#lex-global-footer{display:grid;gap:3px}
    #lex-global-nav{margin:2px 0 13px;padding-bottom:12px;border-bottom:1px solid var(--border)}
    .lex-nav-caption{padding:8px 10px 5px;color:var(--muted-foreground);font-size:11px;font-weight:650;letter-spacing:.04em}
    .lex-global-item{display:flex;align-items:center;gap:9px;width:100%;min-height:33px;padding:7px 10px;border-radius:7px;text-align:left;color:var(--muted-foreground);font-size:13px}
    .lex-global-item svg{width:16px;height:16px;flex:none}
    .lex-global-item.active{background:var(--sidebar-accent);color:var(--sidebar-accent-foreground);font-weight:650}
    .lex-global-item:disabled{opacity:.62;cursor:default}
    .lex-global-item:disabled:hover{background:transparent}
    #lex-matter-nav{display:grid;gap:3px}
    #lex-matter-nav .navitem{width:100%;font-size:13px;line-height:1.35}
    #lex-matter-nav .navitem svg{flex:none}
    #lex-case-meta{display:grid;gap:3px;padding:4px 10px 10px}
    #lex-case-meta strong{font-size:12px;font-weight:650;color:var(--foreground)}
    #lex-case-meta small{font-size:10px;color:var(--muted-foreground);font-family:ui-monospace,monospace}
    #lex-global-footer{padding-top:10px;margin-top:10px;border-top:1px solid var(--border)}
    #lex-case-switcher{display:flex;align-items:center;gap:7px;margin-left:auto;margin-right:12px;white-space:nowrap}
    #lex-case-switcher span{font-size:11px;color:var(--muted-foreground)}
    #lex-case-switcher select{height:31px;max-width:190px;border:1px solid var(--border);border-radius:7px;background:var(--card);padding:4px 24px 4px 8px;color:var(--foreground);font-size:12px}
    @media(max-width:780px){#lex-global-nav,#lex-matter-nav,#lex-global-footer,#lex-case-meta{display:none!important}#lex-case-switcher{margin-left:auto}#lex-case-switcher span{display:none}}
    .content .tabs,.content .sectionhead{display:none!important}
    .lex-doc-actions{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:14px 0 18px}
    .lex-doc-actions .btn{min-height:34px}
    .board{grid-template-columns:var(--lex-list-width,300px) 5px minmax(0,1fr) 5px var(--lex-inspector-width,245px);min-height:calc(100vh - 215px);box-shadow:var(--surface-shadow);align-items:stretch}
    .queue{border-right:1px solid var(--border);padding:14px 0;min-height:480px;overflow:auto}
    .queue .qhead{margin:0 14px 12px;display:flex;align-items:center;justify-content:space-between}
    .queue .tools{margin:0 12px 12px;display:flex;align-items:center;gap:7px}
    .queue .search{flex:1;min-width:0}
    .queue .search input{min-width:0}
    .lex-select{height:33px;min-width:72px;max-width:116px;padding:4px 22px 4px 8px;border:1px solid var(--border);border-radius:7px;background:var(--card);font-size:12px}
    .queue .row{padding:12px 11px;gap:9px;color:var(--foreground);text-decoration:none}
    .queue .row.sel{background:var(--accent);border-left-color:var(--primary)}
    .queue .row:hover{background:var(--muted)}
    .queue .rowmain{min-width:0;flex:1;display:grid;gap:2px}
    .queue .rowmain strong{font-size:13px;overflow-wrap:anywhere}
    .queue .rowmain small{font-size:11px;color:var(--muted-foreground);line-height:1.45}
    .queue .fileIcon{width:30px;height:32px;display:grid;place-items:center;flex:none}
    .lex-pill{display:inline-flex;align-items:center;white-space:nowrap;font-size:11px;line-height:1.4;padding:3px 7px;border-radius:999px;background:var(--muted);color:var(--muted-foreground)}
    .lex-pill.green{background:color-mix(in oklch,var(--success) 13%,var(--card));color:var(--success)}
    .lex-pill.amber{background:color-mix(in oklch,var(--warning) 16%,var(--card));color:var(--warning-foreground)}
    .lex-pill.blue{background:color-mix(in oklch,var(--info) 13%,var(--card));color:var(--info)}
    .detail{border-right:1px solid var(--border);padding:22px clamp(16px,2vw,30px);min-width:0;min-height:480px;overflow-wrap:anywhere}
    .lex-resize-handle{width:5px;cursor:col-resize;touch-action:none;position:relative;z-index:2;background:transparent;outline:none}
    .lex-resize-handle:after{content:"";position:absolute;top:0;bottom:0;left:2px;width:1px;background:var(--border)}
    .lex-resize-handle:hover:after,.lex-resize-handle:focus-visible:after{left:1px;width:3px;background:var(--primary)}
    .lex-resize-handle:focus-visible{outline:2px solid var(--ring);outline-offset:-1px}
    .queue .row[aria-current="page"]{background:var(--accent);border-left-color:var(--primary)}
    .queue .row:focus-visible{outline:2px solid var(--ring);outline-offset:-2px}
    .inspector{min-width:0;background:var(--card);overflow:auto;padding:0 15px 18px}
    .inspectorHead,.lex-inspector-head{position:sticky;top:0;z-index:1;background:var(--card);padding:15px 0 12px;border-bottom:1px solid var(--border);font-weight:650;font-size:14px}
    .inspector section,.lex-template-inspector section{display:grid;gap:5px;padding:13px 0;border-bottom:1px solid var(--border);font-size:13px;overflow-wrap:anywhere}
    .inspector section small,.lex-template-inspector section small{font-size:11px;color:var(--muted-foreground)}
    .inspector section strong,.lex-template-inspector section strong{font-weight:600}
    .inspector section p,.lex-template-inspector section p{font-size:12px;line-height:1.55;color:var(--muted-foreground)}
    .inspector section a{font-size:12px;line-height:1.5}
    .lex-error-state{grid-column:1/-1;min-height:430px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;text-align:center;color:var(--muted-foreground)}
    .lex-error-state h2{font-size:21px;color:var(--foreground)}
    .lex-error-state p{font-size:13px}
    .lex-section-placeholder{max-width:680px;min-height:390px;margin:20px auto;display:flex;flex-direction:column;align-items:flex-start;justify-content:center;gap:12px;color:var(--muted-foreground)}
    .lex-section-placeholder h2{font-size:22px;color:var(--foreground)}
    .lex-section-placeholder p{font-size:14px;line-height:1.7}
    .lex-placeholder-icon{width:40px;height:40px;display:grid;place-items:center;border:1px solid var(--border);border-radius:9px;background:var(--card)}
    .lex-template-overlay{position:fixed;z-index:80;inset:55px 0 0 230px;overflow:auto;background:var(--background);padding:28px clamp(20px,3vw,44px) 22px}
    .lex-template-page{max-width:1360px;margin:0 auto;display:grid;gap:22px;min-height:100%}
    .lex-template-page>header{display:flex;align-items:flex-start;justify-content:space-between;gap:20px}
    .lex-template-page>header>div{display:grid;gap:5px}
    .lex-template-page>header p{font-size:12px;color:var(--muted-foreground)}
    .lex-template-page>header h1{font-size:27px;letter-spacing:-.7px;line-height:1.3}
    .lex-template-page>header span{font-size:13px;color:var(--muted-foreground)}
    .lex-stepper{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:0;list-style:none;margin:0;padding:0;border-bottom:1px solid var(--border)}
    .lex-stepper li{display:flex;align-items:center;gap:9px;padding:0 0 13px;color:var(--muted-foreground);font-size:13px;position:relative}
    .lex-stepper li:after{content:"";position:absolute;bottom:-1px;left:0;right:12px;height:2px;background:transparent}
    .lex-stepper li.current{color:var(--foreground);font-weight:650}
    .lex-stepper li.current:after,.lex-stepper li.done:after{background:var(--primary)}
    .lex-stepper li span{width:24px;height:24px;border-radius:50%;display:grid;place-items:center;border:1px solid var(--border);background:var(--card);font-size:12px}
    .lex-stepper li.current span,.lex-stepper li.done span{background:var(--primary);border-color:var(--primary);color:var(--primary-foreground)}
    .lex-template-layout{display:grid;grid-template-columns:minmax(0,1fr) 265px;gap:24px;align-items:start}
    .lex-template-main{min-width:0;display:grid;gap:18px;padding:4px 0}
    .lex-template-main h2{font-size:19px;font-weight:650}
    .lex-template-choices{display:grid;gap:8px;max-width:820px}
    .lex-template-choice{display:flex;align-items:center;gap:12px;text-align:left;padding:14px;border:1px solid var(--border);border-radius:9px;background:var(--card);width:100%;min-width:0;color:var(--foreground)}
    .lex-template-choice:hover{background:var(--muted)}
    .lex-template-choice.selected{border-color:var(--primary);background:var(--accent);box-shadow:0 0 0 1px color-mix(in oklch,var(--primary) 15%,transparent)}
    .lex-template-choice>span:nth-child(2){display:grid;gap:3px;flex:1;min-width:0}
    .lex-template-choice strong{font-size:14px;font-weight:600}
    .lex-template-choice small{font-size:12px;color:var(--muted-foreground)}
    .lex-template-choice em{font-style:normal;font-size:11px;color:var(--primary)}
    .lex-file-icon{width:32px;height:34px;display:grid;place-items:center;border:1px solid var(--border);border-radius:7px;color:var(--muted-foreground)}
    .lex-form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:15px;max-width:860px}
    .lex-form-grid label{display:grid;gap:6px;font-size:13px;font-weight:550}
    .lex-form-grid .wide{grid-column:1/-1}
    .lex-form-grid input,.lex-form-grid select,.lex-form-grid textarea{width:100%;border:1px solid var(--border);border-radius:7px;background:var(--card);padding:8px 10px;font-size:14px;color:var(--foreground)}
    .lex-form-grid textarea{min-height:160px;resize:vertical;line-height:1.6}
    .lex-source-picker{display:grid;gap:8px;padding:12px;border:1px solid var(--border);border-radius:8px;background:var(--card)}
    .lex-source-picker>strong{font-size:13px}
    .lex-source-picker>p{font-size:12px;color:var(--muted-foreground)}
    .lex-source-picker>div{display:flex;gap:14px;flex-wrap:wrap}
    .lex-source-picker label{display:flex;align-items:center;gap:6px;font-size:12px;font-weight:450}
    .lex-source-picker input{width:auto;accent-color:var(--primary)}
    .lex-form-grid input:focus,.lex-form-grid select:focus,.lex-form-grid textarea:focus{outline:2px solid var(--ring);outline-offset:2px}
    .lex-template-main .fieldHint{font-size:12px;color:var(--muted-foreground)}
    .lex-template-inspector{border:1px solid var(--border);border-radius:9px;background:var(--card);padding:0 14px 8px}
    .lex-template-inspector section{padding:13px 0}
    .lex-review-summary{display:grid;gap:10px;border:1px solid var(--border);border-radius:9px;background:var(--card);padding:15px;max-width:860px}
    .lex-review-summary>div{display:grid;grid-template-columns:105px minmax(0,1fr);gap:8px;font-size:13px}
    .lex-review-summary small{color:var(--muted-foreground)}
    .lex-review-summary p{white-space:pre-wrap;line-height:1.6}
    .lex-confirmed{font-size:13px;color:var(--success);display:flex;align-items:center;gap:7px}
    .lex-check{display:flex;align-items:flex-start;gap:8px;font-size:13px}
    .lex-check input{margin-top:4px;accent-color:var(--primary)}
    .lex-template-page>footer{display:flex;align-items:center;justify-content:flex-end;gap:12px;border-top:1px solid var(--border);padding:14px 0 4px;margin-top:auto}
    .lex-template-page>footer span{margin-right:auto;font-size:12px;color:var(--muted-foreground)}
    .lex-template-page button:disabled{opacity:.45;cursor:not-allowed}
    .lex-discard-backdrop{position:fixed;inset:55px 0 0 230px;z-index:90;background:color-mix(in oklch,var(--foreground) 28%,transparent);display:grid;place-items:center;padding:20px}
    .lex-discard{width:min(420px,100%);border:1px solid var(--border);border-radius:12px;background:var(--card);padding:20px;box-shadow:var(--surface-shadow-raised);display:grid;gap:10px}
    .lex-discard p{font-size:13px;color:var(--muted-foreground)}
    .lex-discard>div{display:flex;justify-content:flex-end;gap:8px}
    @media(max-width:1250px){.board{grid-template-columns:var(--lex-list-width,250px) 5px minmax(0,1fr)}.lex-resize-inspector{display:none}.inspector{grid-column:1/-1;border-top:1px solid var(--border);display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:0 18px}.inspectorHead{grid-column:1/-1}.inspector section{padding:10px 0}.lex-template-layout{grid-template-columns:minmax(0,1fr) 235px}}
    @media(max-width:950px){.lex-template-layout{grid-template-columns:1fr}.lex-template-inspector{display:grid;grid-template-columns:1fr 1fr;gap:0 16px}.lex-template-inspector .lex-inspector-head{grid-column:1/-1}}
    @media(max-width:780px){.board{grid-template-columns:1fr}.lex-resize-handle{display:none}.queue{min-height:0;max-height:320px;border-right:0}.detail{min-height:0;border-right:0;border-top:1px solid var(--border)}.inspector{display:block;border-top:1px solid var(--border)}.lex-template-overlay{inset:80px 0 0 0;padding:18px}.lex-discard-backdrop{inset:80px 0 0 0}.lex-template-page>header{display:grid}.lex-stepper li{font-size:11px;gap:5px}.lex-stepper li span{width:22px;height:22px}.lex-form-grid{grid-template-columns:1fr}.lex-form-grid .wide{grid-column:auto}.lex-template-page>footer{position:sticky;bottom:0;background:var(--background)}}
  `;

  const unifiedSidebarCss = `
    .sidebar{overflow:hidden;overscroll-behavior:contain;padding:12px 10px;gap:0;min-width:0}
    .sidebar .context,.sidebar>.navgroup,.sidebar>.spacer{display:none!important}
    #lex-sidebar-header{display:flex;align-items:center;gap:7px;padding:3px 5px 12px;border-bottom:1px solid var(--border)}
    #lex-sidebar-header .brand{margin:0;flex:1;min-width:0;font-size:19px;letter-spacing:-.6px}
    #lex-sidebar-collapse{width:30px;height:30px;display:grid;place-items:center;border:1px solid var(--border);border-radius:7px;color:var(--muted-foreground)}
    #lex-sidebar-collapse:hover{background:var(--sidebar-accent);color:var(--foreground)}
    #lex-sidebar-collapse svg{width:16px;height:16px}
    #lex-workspace-switcher{position:relative;margin:11px 0 2px}
    #lex-workspace-switcher-trigger{width:100%;min-height:54px;display:flex;align-items:center;gap:9px;padding:7px 9px;border:1px solid var(--border);border-radius:9px;background:var(--card);text-align:left}
    #lex-workspace-switcher-trigger:hover,[aria-expanded=true]#lex-workspace-switcher-trigger{background:var(--sidebar-accent)}
    .lx-switcher-mark{width:31px;height:31px;display:grid;place-items:center;flex:none;border-radius:8px;background:var(--sidebar-primary);color:var(--sidebar-primary-foreground)}
    .lx-switcher-mark svg{width:16px;height:16px}
    .lx-switcher-copy{display:grid;min-width:0;flex:1;gap:2px;line-height:1.3}
    .lx-switcher-copy strong{font-size:12px;font-weight:650;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .lx-switcher-copy small{font-size:10px;color:var(--muted-foreground);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .lx-switcher-chevron{width:15px;height:15px;color:var(--muted-foreground);flex:none}
    #lex-workspace-menu{position:absolute;z-index:120;top:calc(100% + 5px);left:0;right:0;padding:6px;border:1px solid var(--border);border-radius:9px;background:var(--popover);box-shadow:var(--surface-shadow-raised);display:grid;gap:3px}
    #lex-workspace-menu[hidden]{display:none}
    .lx-menu-caption{padding:7px 8px 4px;color:var(--muted-foreground);font-size:10px;font-weight:650}
    .lx-switch-option{display:flex;align-items:center;gap:8px;width:100%;padding:8px;border-radius:7px;text-align:left;font-size:12px}
    .lx-switch-option:hover,.lx-switch-option[aria-current=true]{background:var(--sidebar-accent);color:var(--sidebar-accent-foreground)}
    .lx-switch-option svg{width:16px;height:16px;flex:none}
    #lex-sidebar-scroll{flex:1;min-height:0;overflow-y:auto;overscroll-behavior:contain;padding:10px 1px 12px}
    .lx-nav-group{display:grid;gap:2px;margin-bottom:9px}
    .lx-nav-caption{padding:8px 10px 5px;color:var(--muted-foreground);font-size:10px;font-weight:650;letter-spacing:.025em}
    .lx-nav-item{width:100%;min-height:32px;display:flex;align-items:center;gap:9px;padding:6px 10px;border-radius:7px;text-align:left;color:var(--sidebar-foreground);font-size:13px;line-height:1.35}
    .lx-nav-item>svg{width:16px;height:16px;flex:none}
    .lx-nav-item>span{min-width:0;flex:1}
    .lx-nav-item:hover{background:var(--sidebar-accent);color:var(--sidebar-accent-foreground)}
    .lx-nav-item.active{background:var(--sidebar-accent);color:var(--sidebar-accent-foreground);font-weight:650}
    .lx-nav-item:focus-visible,#lex-workspace-switcher-trigger:focus-visible,#lex-sidebar-collapse:focus-visible{outline:2px solid var(--sidebar-ring);outline-offset:2px}
    .lx-nav-item:disabled{opacity:.42;cursor:not-allowed}
    .lx-nav-item:disabled:hover{background:transparent;color:var(--sidebar-foreground)}
    .lx-nav-parent .lx-nav-chevron{width:14px;height:14px;flex:none;color:var(--muted-foreground);transition:transform .2s ease}
    .lx-nav-parent.expanded .lx-nav-chevron{transform:rotate(90deg)}
    .lx-subnav{display:none;gap:1px;margin:2px 0 4px 18px;padding-left:9px;border-left:1px solid var(--sidebar-border)}
    .lx-nav-parent.expanded+.lx-subnav{display:grid}
    .lx-subnav .lx-nav-item{min-height:28px;padding:5px 9px;font-size:12px;color:var(--muted-foreground)}
    .lx-subnav .lx-nav-item.active{color:var(--sidebar-accent-foreground);background:var(--sidebar-accent);font-weight:650}
    #lex-current-case[aria-disabled=true]{opacity:.43;filter:grayscale(.65);pointer-events:none}
    #lex-current-case[aria-disabled=true] .lx-nav-caption{color:var(--muted-foreground)}
    #lex-sidebar-footer{flex:none;border-top:1px solid var(--sidebar-border);padding:9px 1px 0}
    #lex-global-footer{display:grid;gap:2px}
    #lex-user-area{margin-top:8px;padding:10px 7px 2px;border-top:1px solid var(--sidebar-border)}
    #lex-user-area .userbox{margin:0;padding:0;border:0}
    #lex-user-area .userbox>span{padding:6px 10px}
    #lex-user-area .userbox strong{font-size:12px}
    #lex-user-area .userbox small{font-size:10px}
    #lex-global-placeholder{max-width:760px;min-height:360px;margin:26px auto;padding:26px;border:1px solid var(--border);border-radius:12px;background:var(--card);display:grid;align-content:center;gap:12px;box-shadow:var(--surface-shadow)}
    #lex-global-placeholder h2{font-size:22px;color:var(--foreground)}
    #lex-global-placeholder p{font-size:13px;line-height:1.7;color:var(--muted-foreground)}
    #lex-global-placeholder code{font-size:11px;overflow-wrap:anywhere}
    #lex-global-placeholder .lx-case-choices{display:flex;flex-wrap:wrap;gap:8px;margin-top:8px}
    .lx-case-choice{border:1px solid var(--border);border-radius:7px;padding:8px 11px;background:var(--card);font-size:12px}
    .lx-case-choice:hover{background:var(--sidebar-accent)}
    .lx-current-case-empty{font-size:11px;color:var(--muted-foreground);padding:3px 10px 8px}
    .lx-preview-scenes{border:1px solid var(--border);border-radius:7px;padding:5px 9px;font-size:11px;color:var(--muted-foreground)}
    .lx-preview-scenes:hover{background:var(--muted);color:var(--foreground)}
    .lx-breadcrumb{display:inline-flex;align-items:center;gap:7px;min-width:0}
    .lx-breadcrumb svg{width:14px;height:14px}
    .app.lx-sidebar-collapsed{grid-template-columns:68px minmax(0,1fr)}
    body.lx-sidebar-collapsed .lex-template-overlay,body.lx-sidebar-collapsed .lex-discard-backdrop{left:68px}
    .app.lx-sidebar-collapsed .sidebar{padding:11px 6px;align-items:center}
    .app.lx-sidebar-collapsed #lex-sidebar-header{width:100%;flex-direction:column;gap:7px;padding:0 0 9px}
    .app.lx-sidebar-collapsed #lex-sidebar-header .brand{margin:0;font-size:0}
    .app.lx-sidebar-collapsed #lex-sidebar-header .brandmark{margin:0}
    .app.lx-sidebar-collapsed #lex-sidebar-collapse{width:29px;height:27px}
    .app.lx-sidebar-collapsed #lex-workspace-switcher{width:100%}
    .app.lx-sidebar-collapsed #lex-workspace-switcher-trigger{justify-content:center;padding:7px 4px;min-height:42px}
    .app.lx-sidebar-collapsed #lex-workspace-menu{min-width:220px;left:calc(100% + 6px);right:auto;top:0}
    .app.lx-sidebar-collapsed .lx-switcher-copy,.app.lx-sidebar-collapsed .lx-switcher-chevron{display:none}
    .app.lx-sidebar-collapsed #lex-sidebar-scroll{width:100%;padding-top:8px}
    .app.lx-sidebar-collapsed .lx-nav-caption,.app.lx-sidebar-collapsed .lx-nav-item>span,.app.lx-sidebar-collapsed .lx-nav-chevron,.app.lx-sidebar-collapsed .lx-subnav{display:none!important}
    .app.lx-sidebar-collapsed .lx-nav-item{justify-content:center;padding:8px 4px}
    .app.lx-sidebar-collapsed .lx-nav-item>svg{width:18px;height:18px}
    .app.lx-sidebar-collapsed #lex-sidebar-footer{width:100%}
    .app.lx-sidebar-collapsed #lex-user-area{padding:9px 0 0}
    .app.lx-sidebar-collapsed #lex-user-area .userbox{justify-content:center}
    .app.lx-sidebar-collapsed #lex-user-area .userbox>div{display:none}
    @media(max-width:780px){.sidebar{height:100vh;position:sticky;display:flex;flex-direction:column;flex-wrap:nowrap;padding:12px 8px}.sidebar .lx-nav-item.active{display:flex}#lex-sidebar-scroll{display:block!important}#lex-matter-nav,#lex-global-nav,#lex-global-footer,#lex-case-meta{display:grid!important}#lex-global-footer{display:grid!important}}
    @media(prefers-reduced-motion:reduce){.lx-nav-parent .lx-nav-chevron{transition:none}}
  `;
  const productRefinementCss = `
    /* Emporium-style form rhythm, using Chronicle's existing semantic tokens. */
    .content{max-width:none;padding:22px clamp(20px,2.2vw,34px) 20px}
    .content h1{font-size:24px;letter-spacing:-.45px;font-weight:650;line-height:1.35}
    .content>div:first-child p{font-size:12px;line-height:1.45}
    .lex-doc-actions{margin:10px 0 14px;gap:7px}
    .lex-doc-actions .btn,.btn{min-height:32px;border-radius:6px;font-size:13px;font-weight:550;box-shadow:none}
    .btn.primary{box-shadow:none}
    .btn:focus-visible,.lex-nav-item:focus-visible{outline-offset:2px}
    .board{border-radius:8px;box-shadow:none;border:1px solid var(--border);background:var(--card);min-height:calc(100vh - 205px)}
    .queue{padding:0;min-height:520px;background:var(--card)}
    .queue .qhead{margin:0;padding:15px 14px 11px;border-bottom:1px solid var(--border)}
    .queue .qhead strong{font-size:13px;font-weight:650}
    .queue .tools{margin:0;padding:10px 12px 11px;border-bottom:1px solid var(--border);gap:6px}
    .queue .search{height:32px;border-radius:6px;background:var(--background);border-color:var(--input)}
    .lex-select{height:32px;border-radius:6px;background:var(--background);border-color:var(--input);font-size:12px}
    .queue .row{padding:10px 12px;gap:9px;border-bottom:1px solid color-mix(in oklch,var(--border) 75%,transparent);border-left:2px solid transparent}
    .queue .row:hover{background:var(--muted)}
    .queue .row.sel,.queue .row[aria-current="page"]{background:color-mix(in oklch,var(--accent) 65%,var(--card));border-left-color:var(--primary)}
    .queue .rowmain strong{font-size:12.5px;font-weight:600;line-height:1.35}
    .queue .rowmain small{font-size:11px;line-height:1.35}
    .queue .fileIcon{width:27px;height:29px;border:0;background:transparent;color:var(--muted-foreground)}
    .lex-pill{border-radius:5px;padding:2px 6px;font-size:10.5px;font-weight:550;background:var(--muted);color:var(--muted-foreground)}
    .lex-pill.green{background:color-mix(in oklch,var(--success) 10%,var(--card));color:var(--success)}
    .lex-pill.amber{background:color-mix(in oklch,var(--warning) 11%,var(--card));color:var(--warning-foreground)}
    .lex-pill.blue{background:color-mix(in oklch,var(--info) 10%,var(--card));color:var(--info)}
    .detail{padding:20px clamp(18px,2vw,28px);min-height:520px}
    .detail h2{font-size:20px;font-weight:650;letter-spacing:-.25px;margin-bottom:4px}
    .detail .eyeline{margin-bottom:7px}
    .detail .tags{font-size:12px;gap:7px}
    .detail .facts{background:transparent;border:0;border-top:1px solid var(--border);border-bottom:1px solid var(--border);border-radius:0;padding:10px 0;margin:15px 0}
    .detail .kv{grid-template-columns:112px minmax(0,1fr);padding:4px 0;font-size:12.5px}
    .detail h3{font-size:14px;font-weight:650;margin:17px 0 7px}
    .detail .original,.detail .issue,.detail .paper,.detail .decision{border:0;border-top:1px solid var(--border);border-radius:0;padding:11px 0;background:transparent}
    .detail .original p,.detail .issue p,.detail .paper p{font-size:12.5px;line-height:1.55}
    .detail .actions{gap:6px}
    .inspector{background:var(--card);padding:0 14px 16px}
    .inspectorHead,.lex-inspector-head{font-size:13px;padding:14px 0 10px}
    .inspector section{padding:11px 0;gap:4px}
    .inspector section small{font-size:10.5px}
    .inspector section strong{font-size:12px;font-weight:600}
    .inspector section p,.inspector section a{font-size:11.5px;line-height:1.5}
    .lex-resize-handle{width:7px}
    .lex-resize-handle:after{left:3px}
    .lex-resize-handle:hover:after,.lex-resize-handle:focus-visible:after{left:2px;width:3px}
    .sidebar{padding:10px 9px}
    #lex-sidebar-header{padding:2px 4px 9px}
    #lex-sidebar-header .brand{font-size:18px;letter-spacing:-.35px}
    #lex-workspace-switcher{margin:9px 0 0}
    #lex-workspace-switcher-trigger{min-height:49px;border-radius:7px;border-color:var(--sidebar-border);background:color-mix(in oklch,var(--sidebar) 40%,var(--card))}
    .lx-switcher-mark{width:28px;height:28px;border-radius:6px}
    .lx-nav-group{gap:1px;margin-bottom:7px}
    .lx-nav-caption{padding:7px 9px 4px;font-size:10px;letter-spacing:0;font-weight:600}
    .lx-nav-item{min-height:30px;padding:5px 9px;border-radius:6px;font-size:12.5px;gap:8px}
    .lx-subnav{margin-left:16px;padding-left:8px}
    .lx-subnav .lx-nav-item{min-height:27px;padding:4px 8px;font-size:11.5px}
    #lex-sidebar-scroll{padding-top:8px}
    #lex-sidebar-footer{padding-top:7px}
    #lex-user-area{margin-top:6px;padding-top:7px}
    #lex-global-placeholder{box-shadow:none;border-radius:8px}
    .lx-section-placeholder{max-width:780px}
    @media(max-width:1250px){.board{min-height:0}.inspector{background:var(--background);border-top:1px solid var(--border)}}
    @media(max-width:780px){.lex-template-overlay{inset:55px 0 0 0;padding:16px 16px 0}.lex-template-layout{grid-template-columns:1fr}.lex-template-inspector{display:block}.lex-template-page>header h1{font-size:21px}}
    @media(prefers-reduced-motion:reduce){.lx-nav-parent .lx-nav-chevron{transition:none}}
  `;
  const emporiumFormCss = `
    /* Full-page template workbench: product-detail form rhythm, not a modal or a second navigation. */
    .lex-template-overlay{inset:55px 0 0 230px;background:var(--background);padding:18px clamp(20px,2.2vw,34px) 0}
    .lex-template-page{max-width:1500px;min-height:100%;display:grid;grid-template-rows:auto auto minmax(0,1fr) auto;gap:0}
    .lex-template-page>header{padding:0 0 14px;margin:0;border-bottom:1px solid var(--border);align-items:center}
    .lex-template-page>header>div{gap:3px}
    .lex-template-page>header .lx-template-breadcrumb{font-size:11px;color:var(--muted-foreground);display:flex;align-items:center;gap:6px}
    .lex-template-page>header .lx-template-breadcrumb span{color:var(--border);font-size:11px}
    .lex-template-page>header h1{font-size:22px;line-height:1.35;letter-spacing:-.35px;font-weight:650}
    .lex-template-page>header>div>span{font-size:12px;line-height:1.45;color:var(--muted-foreground)}
    .lex-template-page>header>.btn{flex:none}
    .lex-stepper{display:flex;align-items:stretch;gap:28px;padding:12px 0 0;border-bottom:1px solid var(--border)}
    .lex-stepper li{min-width:125px;min-height:37px;display:flex;align-items:center;gap:8px;padding:0 0 10px;font-size:12px}
    .lex-stepper li span{width:21px;height:21px;border-radius:5px;background:var(--card);border:1px solid var(--border);font-size:11px;color:var(--muted-foreground)}
    .lex-stepper li.current{color:var(--foreground)}
    .lex-stepper li.current span,.lex-stepper li.done span{background:var(--accent);border-color:var(--border);color:var(--foreground)}
    .lex-stepper li b{font-weight:550}
    .lex-stepper li.current:after,.lex-stepper li.done:after{height:2px;background:var(--primary)}
    .lex-template-layout{grid-template-columns:minmax(0,1fr) 285px;gap:30px;align-items:start;padding:18px 0 24px;min-height:0}
    .lex-template-main{display:grid;gap:0;min-width:0;padding:0;max-width:1000px}
    .lx-template-section{padding:16px 0 18px;border-bottom:1px solid var(--border);display:grid;gap:13px}
    .lx-template-section:first-child{padding-top:2px}
    .lx-section-heading{display:flex;align-items:flex-start;justify-content:space-between;gap:16px}
    .lx-section-heading>div{display:grid;gap:3px}
    .lx-section-heading h2{font-size:15px;line-height:1.4;font-weight:650;letter-spacing:-.1px}
    .lx-section-heading p{font-size:11.5px;line-height:1.5;color:var(--muted-foreground)}
    .lx-count{font-size:11px;color:var(--muted-foreground);white-space:nowrap;padding-top:3px}
    .lex-template-list{display:grid;border-top:1px solid var(--border)}
    .lex-template-choice{display:grid;grid-template-columns:28px minmax(0,1fr) auto;gap:11px;align-items:center;width:100%;padding:11px 10px;border:0;border-bottom:1px solid var(--border);border-radius:0;background:transparent;box-shadow:none;min-height:58px}
    .lex-template-choice:hover{background:var(--muted)}
    .lex-template-choice.selected{background:color-mix(in oklch,var(--accent) 55%,var(--card));border-color:var(--border);border-left:2px solid var(--primary);padding-left:8px;box-shadow:none}
    .lex-template-choice>span:nth-child(2){display:grid;gap:2px}
    .lex-template-choice strong{font-size:12.5px;font-weight:600}
    .lex-template-choice small{font-size:11px;color:var(--muted-foreground)}
    .lex-template-choice-meta{font-size:10.5px;color:var(--muted-foreground);white-space:nowrap}
    .lex-file-icon{width:26px;height:28px;border:0;border-radius:0;color:var(--muted-foreground);background:transparent}
    .lex-form-grid{max-width:100%;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px 18px}
    .lex-form-grid label,.lx-body-field{display:grid;gap:5px;font-size:11.5px;font-weight:600;color:var(--foreground)}
    .lex-form-grid label small{font-size:10.5px;font-weight:400;color:var(--muted-foreground)}
    .lex-form-grid input,.lex-form-grid select,.lex-form-grid textarea,.lx-body-field textarea{width:100%;min-width:0;height:35px;padding:7px 9px;border:1px solid var(--input);border-radius:6px;background:var(--card);font-size:12.5px;font-weight:400;color:var(--foreground);box-shadow:none}
    .lex-form-grid input[readonly]{background:var(--muted);color:var(--muted-foreground)}
    .lex-form-grid textarea,.lx-body-field textarea{height:auto;min-height:175px;resize:vertical;line-height:1.65;padding:10px}
    .lex-form-grid input:focus,.lex-form-grid select:focus,.lex-form-grid textarea:focus,.lx-body-field textarea:focus{outline:2px solid var(--ring);outline-offset:1px}
    .lex-source-picker{border:0;border-top:1px solid var(--border);border-bottom:1px solid var(--border);border-radius:0;background:transparent;padding:0}
    .lex-source-picker>div{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:0 18px}
    .lex-source-picker label{display:grid;grid-template-columns:16px minmax(0,1fr) auto;align-items:center;gap:8px;padding:10px 2px;border-bottom:1px solid color-mix(in oklch,var(--border) 70%,transparent);font-size:11.5px;font-weight:500}
    .lex-source-picker label input{width:14px;height:14px;accent-color:var(--primary);margin:0}
    .lex-source-picker label small{font-size:10px;color:var(--muted-foreground);font-weight:400}
    .lex-source-picker label span{min-width:0}
    .lx-form-note{font-size:11px;line-height:1.5;color:var(--muted-foreground);padding:10px 0 0}
    .lex-template-inspector{border:0;border-left:1px solid var(--border);border-radius:0;background:transparent;padding:0 0 10px 18px;display:grid;gap:0}
    .lex-template-inspector .lex-inspector-head{position:static;background:transparent;padding:0 0 11px;border-bottom:1px solid var(--border);font-size:13px}
    .lex-template-inspector section{padding:11px 0;border-bottom:1px solid var(--border);gap:4px}
    .lex-template-inspector section small{font-size:10.5px}
    .lex-template-inspector section strong{font-size:12px;font-weight:600}
    .lex-template-inspector section p{font-size:11px;line-height:1.5}
    .lex-template-inspector dl{display:grid;gap:8px;margin:0}
    .lex-template-inspector dl div{display:grid;gap:2px}
    .lex-template-inspector dt{font-size:10.5px;color:var(--muted-foreground)}
    .lex-template-inspector dd{margin:0;font-size:11.5px;line-height:1.45}
    .lex-review-summary{max-width:none;border:0;border-radius:0;background:transparent;padding:0;gap:0}
    .lx-summary-group{padding:12px 0;border-bottom:1px solid var(--border);display:grid;gap:8px}
    .lx-summary-group h3{font-size:12.5px;font-weight:650;margin:0}
    .lx-summary-group dl{display:grid;gap:7px;margin:0}
    .lx-summary-group dl div{display:grid;grid-template-columns:118px minmax(0,1fr);gap:12px;font-size:11.5px}
    .lx-summary-group dt{color:var(--muted-foreground)}
    .lx-summary-group dd{margin:0;overflow-wrap:anywhere}
    .lx-summary-group ul{list-style:none;margin:0;padding:0;display:grid}
    .lx-summary-group li{display:flex;align-items:center;gap:8px;padding:8px 0;border-top:1px solid color-mix(in oklch,var(--border) 75%,transparent);font-size:11.5px}
    .lx-summary-group li:first-child{border-top:0}
    .lx-summary-group li svg{width:14px;height:14px;color:var(--muted-foreground)}
    .lx-summary-group li small{margin-left:auto;font-size:10px;color:var(--muted-foreground)}
    .lx-summary-group .lx-no-source{color:var(--muted-foreground)}
    .lx-summary-body{white-space:pre-wrap;font-size:12px;line-height:1.65;color:var(--foreground)}
    .lex-confirmed{font-size:11.5px;color:var(--success);padding:10px 0}
    .lex-check{display:flex;align-items:flex-start;gap:8px;padding:10px 0;font-size:11.5px;line-height:1.5}
    .lex-check input{margin:2px 0 0;accent-color:var(--primary)}
    .lex-template-page>footer{position:sticky;bottom:0;z-index:4;background:var(--background);border-top:1px solid var(--border);padding:11px 0 13px;margin-top:auto;justify-content:flex-end}
    .lex-template-page>footer span{margin-right:auto;font-size:11px}
    .lex-discard-backdrop{inset:55px 0 0 230px;background:color-mix(in oklch,var(--foreground) 18%,transparent)}
    body.lx-sidebar-collapsed .lex-template-overlay,body.lx-sidebar-collapsed .lex-discard-backdrop{left:68px}
    @media(max-width:1150px){.lex-template-layout{grid-template-columns:minmax(0,1fr) 245px;gap:22px}.lex-template-inspector{padding-left:14px}}
    @media(max-width:900px){.lex-template-layout{grid-template-columns:1fr}.lex-template-inspector{border-left:0;border-top:1px solid var(--border);padding:14px 0 0;grid-template-columns:repeat(2,minmax(0,1fr));gap:0 20px}.lex-template-inspector .lex-inspector-head{grid-column:1/-1}}
    @media(max-width:780px){.lex-template-overlay{inset:55px 0 0 0;padding:14px 16px 0}.lex-template-page>header{align-items:flex-start}.lex-template-page>header h1{font-size:20px}.lex-template-page>header>.btn{font-size:11px}.lex-stepper{gap:10px}.lex-stepper li{min-width:0;flex:1;font-size:10.5px}.lex-form-grid{grid-template-columns:1fr}.lex-form-grid .wide{grid-column:auto}.lex-source-picker>div{grid-template-columns:1fr}.lex-template-page>footer{position:sticky}.lex-discard-backdrop{inset:55px 0 0 0}}
    @media(prefers-reduced-motion:reduce){.lex-template-choice,.lx-nav-parent .lx-nav-chevron{transition:none}}
  `;
  const usabilityPolishCss = `
    /* Short actions are dialogs, not edge drawers. */
    [data-slot="sheet-overlay"]{z-index:100;background:color-mix(in oklch,var(--foreground) 28%,transparent);backdrop-filter:blur(1px)}
    [data-slot="sheet-content"]{position:fixed!important;inset:auto!important;top:50%!important;left:50%!important;right:auto!important;bottom:auto!important;width:min(560px,calc(100vw - 40px))!important;max-height:min(82dvh,760px)!important;overflow:auto!important;padding:24px!important;border:1px solid var(--border)!important;border-radius:10px!important;background:var(--card)!important;box-shadow:var(--surface-shadow-raised)!important;transform:translate(-50%,-50%)!important;transition:opacity .16s ease,transform .16s ease!important}
    [data-slot="sheet-content"][data-starting-style],[data-slot="sheet-content"][data-ending-style]{transform:translate(-50%,-47%)!important;opacity:0}
    .sheetHead{padding-right:36px;margin-bottom:18px}
    .sheetHead>span{font-size:13px!important}
    .sheetHead h2{font-size:21px!important}
    .sheetHead p{font-size:14px!important}
    .forms{gap:15px}
    .forms .field,.forms label{font-size:14px}
    .forms input,.forms textarea,.forms select,[data-slot="native-select"]{font-size:15px}
    .forms .btn{font-size:14px;min-height:36px}
    .forms p,.forms .muted{font-size:14px;line-height:1.6}
    .formFoot{padding-top:15px}

    /* Keep the Chronicle density, but stop rendering important metadata as footnotes. */
    .queue .qhead strong{font-size:16px}
    .queue .qhead span{font-size:13px}
    .queue .tools .search input,.queue .tools .lex-select{font-size:14px}
    .queue .row{padding:13px 12px}
    .queue .rowmain strong{font-size:15px;line-height:1.4}
    .queue .rowmain small{font-size:13px;line-height:1.45}
    .lex-pill{font-size:12px;padding:3px 8px}
    .inspectorHead,.lex-inspector-head{font-size:15px}
    .inspector section,.lex-template-inspector section{font-size:14px}
    .inspector section small,.lex-template-inspector section small{font-size:13px}
    .inspector section p,.lex-template-inspector section p{font-size:14px;line-height:1.55}
    .inspector section a{font-size:14px;line-height:1.5}
    .inspector section strong,.lex-template-inspector section strong{font-size:14px}
    .lx-nav-caption{font-size:12px}
    .lx-nav-item{font-size:14px;min-height:34px}
    .lx-subnav .lx-nav-item{font-size:13px;min-height:31px}
    .lx-switcher-copy strong{font-size:14px}
    .lx-switcher-copy small{font-size:12px}
    .lx-menu-caption{font-size:12px}
    .lx-switch-option{font-size:14px}
    #lex-case-meta strong{font-size:14px}
    #lex-case-meta small{font-size:12px}
    #lex-user-area .userbox strong{font-size:14px}
    #lex-user-area .userbox small{font-size:12px}

    /* Template work page: ordinary form typography, plain summary, no decorative AI-style cards. */
    .lex-template-page{gap:20px}
    .lex-template-page>header p{font-size:14px}
    .lex-template-page>header h1{font-size:28px}
    .lex-template-page>header span{font-size:14px}
    .lex-stepper li{font-size:14px;gap:10px}
    .lex-stepper li span{font-size:13px}
    .lex-template-main h2{font-size:20px}
    .lex-template-main p,.lex-template-main .fieldHint,.lx-form-note{font-size:14px;line-height:1.55}
    .lex-template-choice{padding:13px 14px;border-radius:6px;box-shadow:none!important}
    .lex-template-choice strong{font-size:15px}
    .lex-template-choice small{font-size:13px}
    .lex-template-choice-meta{font-size:13px}
    .lex-form-grid label,.lx-body-field{font-size:14px}
    .lex-form-grid label small{font-size:13px}
    .lex-form-grid input,.lex-form-grid select,.lex-form-grid textarea,.lx-body-field textarea{font-size:15px;min-height:40px}
    .lex-form-grid textarea,.lx-body-field textarea{min-height:180px}
    .lex-source-picker label{font-size:14px}
    .lex-source-picker label small{font-size:13px}
    .lex-template-inspector .lex-inspector-head{font-size:15px}
    .lex-template-inspector section small{font-size:13px}
    .lex-template-inspector section strong{font-size:14px}
    .lex-template-inspector section p,.lex-template-inspector dt{font-size:13px}
    .lex-template-inspector dd{font-size:14px;line-height:1.5}
    .lx-summary-group h3{font-size:15px}
    .lx-summary-group dl div,.lx-summary-group li,.lx-summary-body{font-size:14px;line-height:1.6}
    .lx-summary-group li small{font-size:13px}
    .lex-confirmed,.lex-check{font-size:14px}
    .lex-template-page>footer span{font-size:13px}
    .lex-template-page>footer .btn{font-size:14px;min-height:38px}
    .lex-discard{border-radius:8px}
    .lex-discard strong{font-size:16px}
    .lex-discard p{font-size:14px}

    /* Read-only file preview lives in the document pane and can switch files without changing the review target. */
    .detail.lex-preview-active{padding:0!important;overflow:hidden;display:flex;flex-direction:column}
    .detail.lex-preview-active>:not(#lex-file-preview){display:none!important}
    #lex-file-preview{display:flex;flex:1;min-height:480px;flex-direction:column;background:var(--background)}
    .lx-preview-toolbar{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 18px;border-bottom:1px solid var(--border);background:var(--card)}
    .lx-preview-file{display:grid;gap:3px;min-width:0}
    .lx-preview-file strong{font-size:16px;overflow-wrap:anywhere}
    .lx-preview-file span{font-size:13px;color:var(--muted-foreground)}
    .lx-preview-controls{display:flex;align-items:center;gap:7px;flex-wrap:wrap}
    .lx-preview-controls select{height:36px;min-width:220px;max-width:320px;border:1px solid var(--input);border-radius:6px;background:var(--card);padding:5px 30px 5px 9px;font-size:14px}
    .lx-preview-controls .btn{min-height:36px;font-size:14px}
    .lx-preview-context{display:flex;align-items:center;gap:8px;padding:10px 18px;border-bottom:1px solid var(--border);font-size:13px;color:var(--muted-foreground)}
    .lx-preview-context strong{font-size:14px;color:var(--foreground);font-weight:550}
    .lx-preview-canvas{flex:1;min-height:0;overflow:auto;padding:24px;background:var(--muted)}
    .lx-preview-paper{width:min(760px,100%);min-height:560px;margin:0 auto;padding:58px 64px;background:#fff;color:#20242b;border:1px solid #d9dde5;box-shadow:0 1px 3px #17243a0c}
    .lx-preview-paper .lx-paper-meta{font-size:13px;color:#687386;border-bottom:1px solid #e3e6ec;padding-bottom:13px;margin-bottom:30px}
    .lx-preview-paper h2{font-family:inherit;font-size:23px;font-weight:650;line-height:1.4;text-align:center;margin:0 0 32px;color:#20242b}
    .lx-preview-paper p{font-size:16px;line-height:2;white-space:pre-wrap;color:#303642;margin:0 0 16px}
    .lx-preview-footer{display:flex;justify-content:space-between;gap:12px;padding:10px 18px;border-top:1px solid var(--border);background:var(--card);font-size:13px;color:var(--muted-foreground)}
    .lx-preview-empty{width:min(760px,100%);margin:0 auto;padding:40px;background:var(--card);border:1px solid var(--border);font-size:15px}
    @media(max-width:1050px){.lx-preview-toolbar{align-items:flex-start;flex-direction:column}.lx-preview-controls{width:100%}.lx-preview-controls select{flex:1;min-width:0;max-width:none}}
    @media(max-width:780px){[data-slot="sheet-content"]{width:calc(100vw - 24px)!important;max-height:calc(100dvh - 24px)!important;padding:18px!important}.lx-preview-canvas{padding:12px}.lx-preview-paper{padding:32px 24px;min-height:420px}.lx-preview-paper h2{font-size:20px}.lx-preview-paper p{font-size:15px}}
    @media(prefers-reduced-motion:reduce){[data-slot="sheet-content"]{transition:none!important}}
  `;
  function installStyle() {
    if (document.getElementById('lexorder-ui-refinement')) return;
    const style = document.createElement('style');
    style.id = 'lexorder-ui-refinement';
    style.textContent = styleText + unifiedSidebarCss + productRefinementCss + emporiumFormCss + usabilityPolishCss;
    document.head.appendChild(style);
  }
  const caseInfo = {
    A: { code: 'CH-2026-001', name: '澄禾设备采购争议', client: '澄禾设备有限公司', opposing: '青岚供应链有限公司', third: '海川运输有限公司', procedures: ['一审 · 买卖合同纠纷', '保全 · 财产保全'], folders: ['工作成果', '诉讼文书', '客户交付'], sources: ['采购合同 V1', '交接清单 V1', '付款凭证 V1'], due: ['11月26日　提交证据目录', '11月27日　保全续期'] },
    B: { code: 'QL-2026-002', name: '青岚仓储交付争议', client: '青岚仓储有限公司', opposing: '澄禾设备有限公司', third: '北辰物流有限公司', procedures: ['仲裁 · 仓储合同争议', '保全执行 · 仓储物保全'], folders: ['工作成果', '仲裁文书', '客户交付'], sources: ['仓储合同 V1', '验收记录 V1', '签收回单 V1'], due: ['11月30日　核对仓储清单', '11月30日　保全核查'] },
  };
  const esc = value => String(value ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  const readDb = () => {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || window.__LEXORDER_PREVIEW_INITIAL__ || null; }
    catch { return window.__LEXORDER_PREVIEW_INITIAL__ || null; }
  };
  const scene = () => { try { return localStorage.getItem(SCENE_KEY) || 'normal'; } catch { return 'normal'; } };
  const parseRoute = () => {
    const hash = location.hash.slice(1);
    const [path, query = ''] = hash.split('?');
    const parts = path.split('/').filter(Boolean);
    const rawCase = parts[1] || 'A';
    const caseId = caseInfo[rawCase] ? rawCase : Object.keys(caseInfo).find(key => caseInfo[key].code === rawCase) || 'A';
    const section = parts[2] || 'review';
    const id = parts[3] || '';
    const event = parts[4] || '';
    const params = new URLSearchParams(query);
    if (params.get('global') === '1') return { caseId, section: 'global', id: '', event: '', global: true, globalPath: params.get('route') || '/practice/today' };
    if (params.get('delivery')) return { caseId, section: 'delivery', id: params.get('delivery'), event: params.get('deliveryEvent') || '' };
    if (params.get('document')) return { caseId, section: params.get('reviewIssue') ? 'review' : 'materials', id: params.get('document'), event: params.get('reviewIssue') || '' };
    if (params.get('deliveryDocument')) return { caseId, section: 'review', id: params.get('deliveryDocument'), event: '' };
    return { caseId, section, id, event, global: false };
  };
  const unique = (caseId, prefix) => `${caseId}-${prefix}-${crypto.randomUUID().slice(0, 8)}`;
  const statusOfPack = pack => pack.events.some(event => event.kind === 'SENT') ? 'SENT' : pack.events.some(event => event.kind === 'EXPORTED') ? 'EXPORTED' : 'PREPARED';
  const isWithdrawn = id => scene() === 'withdrawDoc' && id === `${parseRoute().caseId}-D01`;
  const isProofWithdrawn = id => scene() === 'withdrawProof' && id === `${parseRoute().caseId}-M01`;
  const navHash = (caseId, section, id = '', event = '') => `#/matters/${caseId}/${section}${id ? `/${id}` : ''}${event ? `/${event}` : ''}`;
  const navigate = (hash) => {
    const nextIndex = Number(history.state?.lexIndex ?? 0) + 1;
    history.pushState({ lexIndex: nextIndex }, '', hash);
    window.dispatchEvent(new PopStateEvent('popstate'));
  };
  const icon = type => {
    const paths = {
      grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
      folder: '<path d="M3 7.5A2.5 2.5 0 0 1 5.5 5H10l2 2h6.5A2.5 2.5 0 0 1 21 9.5v8a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 3 17.5z"/><path d="M3 10h18"/>',
      list: '<path d="M8 6h13M8 12h13M8 18h13"/><path d="M3 6h.01M3 12h.01M3 18h.01"/>',
      book: '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v17H6.5A2.5 2.5 0 0 0 4 22z"/><path d="M4 5.5v16.5M8 7h8M8 11h8"/>',
      calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4M17 3v4M3 10h18M7 14h3M7 17h3"/>',
      file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h8"/>',
      clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
      wallet: '<rect x="3" y="5" width="18" height="15" rx="2"/><path d="M3 9h18M16 14h2"/>',
      stamp: '<rect x="4" y="14" width="16" height="7" rx="1"/><path d="M8 14V9a4 4 0 0 1 8 0v5M7 18h10"/>',
      users: '<path d="M16 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="10" cy="7" r="4"/><path d="M20 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
      briefcase: '<rect x="3" y="7" width="18" height="14" rx="2"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M3 12h18M10 12v2h4v-2"/>',
      bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/>',
      settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15.1 21 16.4l-1.4 2.4-1.8-.6a7 7 0 0 1-1.4.8l-.3 1.8h-2.8l-.3-1.8a7 7 0 0 1-1.4-.8l-1.7.6-1.4-2.4 1.4-1.3a7 7 0 0 1 0-1.6l-1.4-1.1 1.4-2.4 1.7.6a7 7 0 0 1 1.4-.8l.3-1.8h2.8l.3 1.8a7 7 0 0 1 1.4.8l1.8-.6 1.4 2.4-1.6 1.1a7 7 0 0 1 0 1.7Z"/>',
      chevron: '<path d="m9 18 6-6-6-6"/>',
      grip: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
      users: '<path d="M16 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="10" cy="7" r="4"/><path d="M20 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
      briefcase: '<rect x="3" y="7" width="18" height="14" rx="2"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M3 12h18M10 12v2h4v-2"/>',
      bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/>',
      settings: '<circle cx="12" cy="12" r="3"/><path d="m19.4 15 .1.1 1.4 1.1-1.4 2.4-1.7-.6a7 7 0 0 1-1.4.8l-.3 1.8h-2.8l-.3-1.8a7 7 0 0 1-1.4-.8l-1.7.6-1.4-2.4 1.4-1.1a7 7 0 0 1 0-1.6L6.5 12.4l1.4-2.4 1.7.6a7 7 0 0 1 1.4-.8l.3-1.8h2.8l.3 1.8a7 7 0 0 1 1.4.8l1.7-.6 1.4 2.4-1.4 1.1a7 7 0 0 1-.1 1.5Z"/>',
      chevron: '<path d="m9 18 6-6-6-6"/>',
      grip: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    };
    return `<svg aria-hidden="true" viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${paths[type] || paths.file}</svg>`;
  };
  const pill = status => `<span class="lex-pill ${colors[status] || 'neutral'}">${esc(labels[status] || status || '—')}</span>`;
  const findSelected = (db, route) => {
    const matter = db?.[route.caseId];
    if (!matter || !route.id) return {};
    return {
      doc: matter.docs.find(item => item.id === route.id),
      pack: matter.packs.find(item => item.id === route.id),
      seal: matter.seals.find(item => item.id === route.id),
      file: [...matter.docs, ...matter.files].find(item => item.id === route.id),
    };
  };
  const getWorkItems = (matter, caseId) => {
    const docs = matter.docs.filter(doc => !(scene() === 'withdrawDoc' && doc.id === `${caseId}-D01`)).map(doc => ({ kind: 'document', id: doc.id, title: doc.title, status: doc.status, version: doc.version, procedure: matter.procedures?.[doc.proc] || caseInfo[caseId].procedures[doc.proc] || '未指定程序', item: doc }));
    const packs = matter.packs.map(pack => ({ kind: 'delivery', id: pack.id, title: scene() === 'withdrawDoc' && pack.doc === `${caseId}-D01` ? '不可查看的清单' : pack.title, status: scene() === 'withdrawDoc' && pack.doc === `${caseId}-D01` ? 'UNAVAILABLE' : statusOfPack(pack), version: null, procedure: pack.recipient, item: pack }));
    const seals = matter.seals.map(seal => ({ kind: 'seal', id: seal.id, title: seal.title, status: seal.status, version: null, procedure: seal.note, item: seal }));
    return [...docs, ...seals, ...packs];
  };
  const state = { type: '全部', status: '全部', search: '', lastGroup: '', template: null, templateSnapshot: null, templateDirty: false, templateHistory: false, observer: null, timer: null, paneWidths: null, lastActiveCaseParent: null, lastActiveGlobalParent: null, previewFileId: null, previewRoute: null, previewFocus: null, previewDismissedRoute: null };
  function sectionFor(route) {
    if (['drafts', 'review', 'delivery', 'seal'].includes(route.section)) return 'documents';
    if (['evidence', 'research'].includes(route.section)) return 'facts';
    return sections.some(([key]) => key === route.section) ? route.section : 'documents';
  }
  function readLastCaseRoutes() {
    try { return JSON.parse(localStorage.getItem(LAST_CASE_ROUTES)) || window.__LEXORDER_LAST_CASE_ROUTES__ || {}; }
    catch { return window.__LEXORDER_LAST_CASE_ROUTES__ || {}; }
  }
  function recordCaseRoute(route) {
    if (!route || route.global || !caseInfo[route.caseId]) return;
    const saved = readLastCaseRoutes();
    const next = { section: route.section, id: route.id || '', event: route.event || '' };
    if (JSON.stringify(saved[route.caseId]) !== JSON.stringify(next)) {
      saved[route.caseId] = next;
      window.__LEXORDER_LAST_CASE_ROUTES__ = saved;
      try { localStorage.setItem(LAST_CASE_ROUTES, JSON.stringify(saved)); } catch {}
    }
  }
  function caseRouteFor(caseId) {
    const saved = readLastCaseRoutes()[caseId];
    if (saved && saved.section) return navHash(caseId, saved.section, saved.id || '', saved.event || '');
    return caseId === 'A' ? navHash('A', 'review', 'A-D02') : navHash('B', 'review', 'B-D03');
  }
  function globalHash(caseId, path) {
    const base = navHash(caseId || 'A', 'review', caseId === 'B' ? 'B-D03' : 'A-D02');
    return base + '?global=1&route=' + encodeURIComponent(path);
  }
  function navigateGlobal(path) {
    const route = parseRoute();
    recordCaseRoute(route);
    navigate(globalHash(route.caseId || 'A', path));
  }
  function navigateCase(caseId) { navigate(caseRouteFor(caseId)); }
  function switchWorkspace(target) {
    if (target === 'global') { navigateGlobal('/practice/today'); return; }
    recordCaseRoute(parseRoute());
    if (caseInfo[target]) navigateCase(target);
  }
  function ensureSidebar() {
    const sidebar = document.querySelector('.sidebar');
    if (!sidebar) return;
    if (!sidebar.querySelector('#lex-sidebar-header')) {
      const brand = sidebar.querySelector('.brand');
      const legacyContext = sidebar.querySelector('.context');
      const legacyImport = [...sidebar.children].find(node => node.classList?.contains('navitem') && node.textContent.includes('工作区模板'));
      const scenesButton = [...sidebar.children].find(node => node.classList?.contains('navitem') && node.textContent.includes('验收场景'));
      const userbox = sidebar.querySelector('.userbox');
      [...sidebar.children].forEach(node => {
        if ([brand, legacyContext, userbox, legacyImport, scenesButton].includes(node)) return;
        node.remove();
      });
      if (legacyContext) legacyContext.style.display = 'none';
      if (legacyImport) { legacyImport.classList.add('lex-legacy-import'); legacyImport.style.display = 'none'; }
      if (scenesButton) { scenesButton.id = 'lex-legacy-scenes'; scenesButton.style.display = 'none'; }

      const header = document.createElement('div');
      header.id = 'lex-sidebar-header';
      if (brand) header.appendChild(brand);
      const collapse = document.createElement('button');
      collapse.type = 'button'; collapse.id = 'lex-sidebar-collapse';
      collapse.setAttribute('aria-label', '折叠侧栏'); collapse.setAttribute('aria-pressed', 'false');
      collapse.innerHTML = icon('grip');
      collapse.addEventListener('click', () => {
        const app = document.querySelector('.app');
        const collapsed = app.classList.toggle('lx-sidebar-collapsed');
        document.body.classList.toggle('lx-sidebar-collapsed', collapsed);
        collapse.setAttribute('aria-label', collapsed ? '展开侧栏' : '折叠侧栏');
        collapse.setAttribute('aria-pressed', String(collapsed));
        try { localStorage.setItem(SIDEBAR_COLLAPSED, collapsed ? '1' : '0'); } catch {}
      });
      header.appendChild(collapse);
      sidebar.appendChild(header);

      const switcher = document.createElement('div');
      switcher.id = 'lex-workspace-switcher';
      switcher.innerHTML = `<button type="button" id="lex-workspace-switcher-trigger" aria-haspopup="menu" aria-expanded="false">
        <span class="lx-switcher-mark">${icon('briefcase')}</span>
        <span class="lx-switcher-copy"><strong id="lx-switcher-title">当前案件</strong><small id="lx-switcher-detail">选择案件</small></span>
        <span class="lx-switcher-chevron">${icon('chevron')}</span>
      </button>
      <div id="lex-workspace-menu" role="menu" aria-label="切换工作区或案件" hidden>
        <div class="lx-menu-caption">工作区</div>
        <button type="button" class="lx-switch-option" role="menuitem" data-switch-global>${icon('grid')}<span>全局工作区（未选案件）</span></button>
        <div class="lx-menu-caption">当前案件</div>
        <button type="button" class="lx-switch-option" role="menuitem" data-switch-case="A">${icon('briefcase')}<span>澄禾设备采购争议</span></button>
        <button type="button" class="lx-switch-option" role="menuitem" data-switch-case="B">${icon('briefcase')}<span>青岚仓储交付争议</span></button>
        <div class="lx-menu-caption">其他入口</div>
        <button type="button" class="lx-switch-option" role="menuitem" data-switch-cases>${icon('folder')}<span>案件总览</span></button>
      </div>`;
      sidebar.appendChild(switcher);

      const scroll = document.createElement('div');
      scroll.id = 'lex-sidebar-scroll';
      const current = document.createElement('section');
      current.id = 'lex-current-case';
      current.className = 'lx-nav-group';
      current.setAttribute('aria-label', '当前案件');
      const currentButtons = currentMenu.map(item => {
        if (item.children) {
          const submenuId = 'lx-sub-' + item.key;
          return `<button type="button" class="lx-nav-item lx-nav-parent" data-parent="${item.key}" aria-expanded="false" aria-controls="${submenuId}" title="${item.label}">${icon(item.glyph)}<span>${item.label}</span><span class="lx-nav-chevron">${icon('chevron')}</span></button>
            <div class="lx-subnav" id="${submenuId}">${item.children.map(child => `<button type="button" class="lx-nav-item" data-case-route="${child.route}" data-nav-child="${child.key}" title="${child.label}">${icon('chevron')}<span>${child.label}</span></button>`).join('')}</div>`;
        }
        return `<button type="button" class="lx-nav-item" data-case-route="${item.route}" data-nav-key="${item.key}" title="${item.label}">${icon(item.glyph)}<span>${item.label}</span></button>`;
      }).join('');
      current.innerHTML = `<div class="lx-nav-caption">当前案件</div><nav id="lex-matter-nav" aria-label="当前案件">${currentButtons}</nav>`;
      scroll.appendChild(current);

      const workspace = document.createElement('section');
      workspace.id = 'lex-workspace-nav';
      workspace.className = 'lx-nav-group';
      workspace.setAttribute('aria-label', '工作区');
      const globalButtons = globalMenu.map(item => {
        if (item.children) {
          const submenuId = 'lx-global-sub-' + item.key;
          return `<button type="button" class="lx-nav-item lx-nav-parent" data-global-parent="${item.key}" aria-expanded="false" aria-controls="${submenuId}" title="${item.label}">${icon(item.glyph)}<span>${item.label}</span><span class="lx-nav-chevron">${icon('chevron')}</span></button>
            <div class="lx-subnav" id="${submenuId}">${item.children.map(child => `<button type="button" class="lx-nav-item" data-global-route="${child.path}" data-nav-child="${child.key}" title="${child.label}">${icon('chevron')}<span>${child.label}</span></button>`).join('')}</div>`;
        }
        return `<button type="button" class="lx-nav-item" data-global-route="${item.path}" data-nav-key="${item.key}" title="${item.label}">${icon(item.glyph)}<span>${item.label}</span></button>`;
      }).join('');
      workspace.innerHTML = `<div class="lx-nav-caption">工作区</div><nav id="lex-global-nav" aria-label="全局工作区">${globalButtons}</nav>`;
      scroll.appendChild(workspace);
      sidebar.appendChild(scroll);

      const footer = document.createElement('div');
      footer.id = 'lex-sidebar-footer';
      footer.innerHTML = `<nav id="lex-global-footer" aria-label="固定入口">
        <button type="button" class="lx-nav-item" data-global-route="/matters/list" title="案件">${icon('folder')}<span>案件</span></button>
        <button type="button" class="lx-nav-item" data-global-route="/notifications" title="通知">${icon('bell')}<span>通知</span></button>
        <button type="button" class="lx-nav-item" data-global-route="/settings" title="设置">${icon('settings')}<span>设置</span></button>
      </nav>`;
      if (userbox) { const user = document.createElement('div'); user.id = 'lex-user-area'; user.appendChild(userbox); footer.appendChild(user); }
      sidebar.appendChild(footer);

      const trigger = document.getElementById('lex-workspace-switcher-trigger');
      const menu = document.getElementById('lex-workspace-menu');
      const closeMenu = (restore = false) => { menu.hidden = true; trigger.setAttribute('aria-expanded', 'false'); if (restore) trigger.focus(); };
      trigger.addEventListener('click', () => {
        menu.hidden = !menu.hidden; trigger.setAttribute('aria-expanded', String(!menu.hidden));
        if (!menu.hidden) menu.querySelector('[role="menuitem"]')?.focus();
      });
      menu.addEventListener('click', event => {
        const option = event.target.closest('[data-switch-global],[data-switch-case],[data-switch-cases]');
        if (!option) return;
        closeMenu(true);
        if (option.hasAttribute('data-switch-global')) switchWorkspace('global');
        else if (option.dataset.switchCase) switchWorkspace(option.dataset.switchCase);
        else navigateGlobal('/matters/list');
      });
      menu.addEventListener('keydown', event => {
        const items = [...menu.querySelectorAll('[role="menuitem"]')];
        const index = items.indexOf(document.activeElement);
        if (event.key === 'Escape') { event.preventDefault(); closeMenu(true); }
        else if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
          event.preventDefault(); const delta = event.key === 'ArrowDown' ? 1 : -1;
          items[(index + delta + items.length) % items.length]?.focus();
        } else if (event.key === 'Home') { event.preventDefault(); items[0]?.focus(); }
        else if (event.key === 'End') { event.preventDefault(); items.at(-1)?.focus(); }
      });
      document.addEventListener('pointerdown', event => { if (!switcher.contains(event.target) && !menu.hidden) closeMenu(false); });

      const bindParentToggle = nav => nav.querySelectorAll('.lx-nav-parent').forEach(button => {
        button.addEventListener('click', () => {
          const expanded = button.getAttribute('aria-expanded') !== 'true';
          button.setAttribute('aria-expanded', String(expanded)); button.classList.toggle('expanded', expanded);
        });
      });
      const bindNavigationKeys = nav => nav.addEventListener('keydown', event => {
        if (event.key === 'ArrowRight') {
          const parent = event.target.closest('.lx-nav-parent');
          if (parent) {
            event.preventDefault();
            if (parent.getAttribute('aria-expanded') !== 'true') parent.click();
            document.getElementById(parent.getAttribute('aria-controls'))?.querySelector('button:not(:disabled)')?.focus();
          }
        } else if (event.key === 'ArrowLeft') {
          const child = event.target.closest('.lx-subnav .lx-nav-item');
          if (child) { event.preventDefault(); const parent = document.querySelector(`[aria-controls="${child.closest('.lx-subnav').id}"]`); parent?.click(); parent?.focus(); }
        }
      });
      bindParentToggle(current.querySelector('nav')); bindParentToggle(workspace.querySelector('nav'));
      bindNavigationKeys(current.querySelector('nav')); bindNavigationKeys(workspace.querySelector('nav'));
      current.querySelectorAll('[data-case-route]').forEach(button => button.addEventListener('click', () => navigateSection(button.dataset.caseRoute)));
      workspace.querySelectorAll('[data-global-route]').forEach(button => button.addEventListener('click', () => navigateGlobal(button.dataset.globalRoute)));
      footer.querySelectorAll('[data-global-route]').forEach(button => button.addEventListener('click', () => navigateGlobal(button.dataset.globalRoute)));

      try {
        const collapsed = localStorage.getItem(SIDEBAR_COLLAPSED) === '1';
        document.querySelector('.app').classList.toggle('lx-sidebar-collapsed', collapsed);
        document.body.classList.toggle('lx-sidebar-collapsed', collapsed);
        collapse.setAttribute('aria-label', collapsed ? '展开侧栏' : '折叠侧栏');
        collapse.setAttribute('aria-pressed', String(collapsed));
      } catch {}
    }
    syncCaseMeta();
    ensureTopbar();
  }
  function syncCaseMeta() {
    const route = parseRoute();
    const info = caseInfo[route.caseId];
    const meta = document.getElementById('lex-case-meta');
    const title = document.getElementById('lx-switcher-title');
    const detail = document.getElementById('lx-switcher-detail');
    const menu = document.getElementById('lex-workspace-menu');
    const current = document.getElementById('lex-current-case');
    const hasCase = !!info && !route.global;
    if (current) {
      current.inert = !hasCase;
      current.setAttribute('aria-disabled', String(!hasCase));
      current.querySelectorAll('button').forEach(button => { button.disabled = !hasCase; });
    }
    const metaHtml = hasCase ? `<strong>${esc(info.name)}</strong><small>${esc(info.code)}</small>` : '<div class="lx-current-case-empty">未选择案件 · 当前为全局工作区</div>';
    const switchTitle = hasCase ? info.name : '全局工作区';
    const switchDetail = hasCase ? info.code : '未选择案件';
    if (meta && meta.innerHTML !== metaHtml) meta.innerHTML = metaHtml;
    if (title && title.textContent !== switchTitle) title.textContent = switchTitle;
    if (detail && detail.textContent !== switchDetail) detail.textContent = switchDetail;
    menu?.querySelectorAll('[data-switch-case]').forEach(button => button.setAttribute('aria-current', String(hasCase && button.dataset.switchCase === route.caseId)));
    menu?.querySelector('[data-switch-global]')?.setAttribute('aria-current', String(!hasCase));
  }
  function ensureTopbar() {
    const top = document.querySelector('.top');
    if (!top) return;
    top.querySelector('#lex-case-switcher')?.remove();
    const route = parseRoute();
    const first = top.querySelector('span:first-child');
    const label = route.global ? (globalPageTitles[route.globalPath] || '工作区')
      : (['drafts', 'review', 'delivery'].includes(route.section) ? pageTitles.delivery : (pageTitles[route.section] || '案件工作区'));
    const caseName = route.global ? '工作区' : caseInfo[route.caseId]?.name || '当前案件';
    const shownLabel = document.getElementById('lex-template-overlay') ? '从模板起草' : label;
    if (first && first.dataset.lexBreadcrumb !== caseName + '|' + shownLabel) {
      first.dataset.lexBreadcrumb = caseName + '|' + shownLabel;
      first.classList.add('lx-breadcrumb');
      first.innerHTML = icon('briefcase') + `<span>${esc(caseName)}</span>` + icon('chevron') + `<b>${esc(shownLabel)}</b>`;
    }
    if (!top.querySelector('.lx-preview-scenes')) {
      const button = document.createElement('button'); button.type = 'button'; button.className = 'lx-preview-scenes'; button.textContent = '验收场景';
      button.addEventListener('click', () => document.getElementById('lex-legacy-scenes')?.click());
      const review = top.querySelector('.reviewlink'); top.insertBefore(button, review || null);
    }
  }
  function navigateSection(section) {
    const route = parseRoute();
    if (section === 'documents' || section === 'delivery') {
      state.type = '全部'; state.status = '全部'; state.search = '';
      navigate(navHash(route.caseId, 'delivery'));
      return;
    }
    if (section === 'seal') {
      state.type = '用印申请'; state.status = '全部'; state.search = '';
      navigate(navHash(route.caseId, 'seal'));
      return;
    }
    if (section === 'materials') {
      state.type = '全部'; state.status = '全部'; state.search = '';
      const db = readDb();
      const matter = db?.[route.caseId];
      const file = matter && (matter.files[0] || matter.docs[0]);
      navigate(navHash(route.caseId, 'materials', file?.id || ''));
      return;
    }
    if (section === 'archive') {
      state.type = '全部'; state.status = '全部'; state.search = '';
      navigate(navHash(route.caseId, 'archive'));
      return;
    }
    navigate(navHash(route.caseId, section));
  }
  function setActiveNav(route) {
    const current = document.getElementById('lex-current-case');
    const hasCase = !route.global;
    if (current) {
      current.inert = !hasCase;
      current.setAttribute('aria-disabled', String(!hasCase));
      current.querySelectorAll('button').forEach(button => { button.disabled = !hasCase; });
    }
    const activeChild = route.section === 'research' ? 'research'
      : route.section === 'evidence' ? 'evidence'
      : route.section === 'seal' ? 'seal'
      : ['drafts', 'review', 'delivery'].includes(route.section) ? 'delivery'
      : route.section;
    const activeParent = route.global ? '' : sectionFor(route);
    const currentNav = document.getElementById('lex-matter-nav');
    currentNav?.querySelectorAll('[data-nav-key],[data-parent],[data-nav-child]').forEach(button => {
      const isChild = button.dataset.navChild === activeChild;
      const isParent = button.dataset.navKey === activeParent || button.dataset.parent === activeParent;
      const selected = isChild || (isParent && !['facts', 'documents'].includes(activeParent));
      button.classList.toggle('active', selected);
      if (selected && !button.dataset.parent) button.setAttribute('aria-current', 'page'); else button.removeAttribute('aria-current');
    });
    if (state.lastActiveCaseParent !== activeParent) {
      currentNav?.querySelectorAll('[data-parent]').forEach(button => {
        const expanded = !!activeParent && button.dataset.parent === activeParent;
        button.classList.toggle('expanded', expanded);
        button.setAttribute('aria-expanded', String(expanded));
      });
      state.lastActiveCaseParent = activeParent;
    }
    const path = route.global ? route.globalPath : '';
    const globalNav = document.getElementById('lex-global-nav');
    globalNav?.querySelectorAll('[data-global-route],[data-global-parent]').forEach(button => {
      const selected = button.dataset.globalRoute === path;
      button.classList.toggle('active', selected);
      if (selected) button.setAttribute('aria-current', 'page'); else button.removeAttribute('aria-current');
    });
    let activeGlobalParent = '';
    globalNav?.querySelectorAll('[data-global-parent]').forEach(button => {
      const submenu = document.getElementById(button.getAttribute('aria-controls'));
      const child = [...(submenu?.querySelectorAll('[data-global-route]') || [])].some(item => item.dataset.globalRoute === path);
      if (child) activeGlobalParent = button.dataset.globalParent;
    });
    if (state.lastActiveGlobalParent !== activeGlobalParent) {
      globalNav?.querySelectorAll('[data-global-parent]').forEach(button => {
        const expanded = !!activeGlobalParent && button.dataset.globalParent === activeGlobalParent;
        button.classList.toggle('expanded', expanded);
        button.setAttribute('aria-expanded', String(expanded));
      });
      state.lastActiveGlobalParent = activeGlobalParent;
    }
    document.querySelectorAll('#lex-global-footer [data-global-route]').forEach(button => {
      const selected = route.global && button.dataset.globalRoute === path;
      button.classList.toggle('active', selected);
      if (selected) button.setAttribute('aria-current', 'page'); else button.removeAttribute('aria-current');
    });
  }
  function captureLegacyTriggers() {
    const sectionhead = document.querySelector('.sectionhead');
    if (sectionhead && (!window.__lexSealTrigger || !window.__lexSealTrigger.isConnected)) {
      window.__lexSealTrigger = [...sectionhead.querySelectorAll('button')].find(button => button.textContent.includes('申请用印')) || null;
    }
  }
  function removeOldNavigation() {
    const tabs = document.querySelector('.tabs');
    const sectionhead = document.querySelector('.sectionhead');
    if (tabs && tabs.style.display !== 'none') { tabs.style.display = 'none'; tabs.setAttribute('aria-hidden', 'true'); }
    if (sectionhead && sectionhead.style.display !== 'none') { sectionhead.style.display = 'none'; sectionhead.setAttribute('aria-hidden', 'true'); }
  }
  function ensureActionBar(route) {
    const content = document.querySelector('.content');
    const header = content?.querySelector(':scope > div:first-child');
    if (!content || !header) return;
    let actions = content.querySelector('.lex-doc-actions');
    if (!actions) {
      actions = document.createElement('div');
      actions.className = 'lex-doc-actions';
      header.insertAdjacentElement('afterend', actions);
    }
    const work = ['drafts', 'review', 'delivery'].includes(route.section);
    const showSealAction = route.section === 'seal' || (work && state.type === '用印申请');
    const readOnly = scene() === 'readonly' || scene() === 'error';
    const mode = `${work ? 'work' : 'none'}:${state.type}:${showSealAction}`;
    if (actions.dataset.lexMode === mode && actions.dataset.lexReadonly === String(readOnly)) return;
    actions.dataset.lexMode = mode; actions.dataset.lexReadonly = String(readOnly);
    actions.innerHTML = '';
    if (work && !readOnly) {
      actions.appendChild(makeButton('从模板起草', 'primary', openTemplateWizard));
      actions.appendChild(makeButton('导入文书模板', 'outline', () => document.querySelector('.lex-legacy-import')?.click()));
    }
    if (showSealAction && !readOnly) actions.appendChild(makeButton('申请用印', 'outline', () => window.__lexSealTrigger?.click()));
    const h1 = header.querySelector('h1');
    if (h1) h1.textContent = route.section === 'seal' ? pageTitles.seal : work ? '文书与交付' : (pageTitles[route.section] || '案内工作区');
    const description = header.querySelector('p');
    if (description && !description.dataset.lexOriginal) description.dataset.lexOriginal = description.textContent;
  }
  function makeButton(text, kind, handler) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = `btn ${kind === 'primary' ? 'primary' : ''}`;
    button.textContent = text;
    button.addEventListener('click', handler);
    return button;
  }
  function badgeHtml(status) { return pill(status); }
  function renderQueue(route, db) {
    const board = document.querySelector('.board');
    const queue = board?.querySelector('.queue');
    if (!queue) return;
    const matter = db?.[route.caseId];
    if (!matter) return;
    let items = [];
    const work = ['drafts', 'review', 'delivery', 'seal'].includes(route.section);
    if (work) items = getWorkItems(matter, route.caseId);
    else if (route.section === 'seal') items = matter.seals.map(item => ({ kind: 'seal', id: item.id, title: item.title, status: item.status, procedure: item.note, item }));
    else if (route.section === 'materials') items = [...matter.docs, ...matter.files].filter(item => !(scene() === 'withdrawDoc' && item.id === `${route.caseId}-D01`) && !(scene() === 'withdrawProof' && item.id === `${route.caseId}-M01`)).map(item => ({ kind: 'material', id: item.id, title: item.title, status: item.status || '原件', version: item.version, procedure: '固定原件', item }));
    else if (route.section === 'archive') items = matter.packs.map(item => ({ kind: 'archive', id: item.id, title: item.title, status: statusOfPack(item), procedure: item.recipient, item }));
    const type = state.type;
    const search = state.search.trim().toLowerCase();
    items = items.filter(entry => (type === '全部' || (type === '文书版本' && entry.kind === 'document') || (type === '用印申请' && entry.kind === 'seal') || (type === '交付清单' && entry.kind === 'delivery'))
      && (state.status === '全部' || entry.status === state.status)
      && (!search || `${entry.title} ${entry.id} ${entry.procedure || ''}`.toLowerCase().includes(search)));
    const signature = `${route.caseId}|${route.section}|${route.id}|${scene()}|${type}|${state.status}|${search}|${items.map(x => x.id + ':' + x.status).join(',')}`;
    const last = queue.dataset.lexSignature;
    if (last === signature && queue.dataset.lexEnhanced === '1') return;
    const title = route.section === 'seal' ? '用印申请列表' : work ? '文书与交付列表' : route.section === 'materials' ? '材料列表' : '归档引用列表';
    const statusOptions = [...new Set(items.map(item => item.status))];
    const searchWasFocused = document.activeElement === queue.querySelector('input[aria-label="搜索当前列表"]');
    const searchSelection = searchWasFocused ? queue.querySelector('input[aria-label="搜索当前列表"]').selectionStart : null;
    queue.innerHTML = `<div class="qhead"><strong>${title}</strong><span>${items.length} 项</span></div>
      <div class="tools"><label class="search">${icon('list')}<input aria-label="搜索当前列表" placeholder="搜索名称、编号或接收人" value="${esc(state.search)}"></label>
      ${work && route.section !== 'seal' ? `<select class="lex-select" aria-label="对象类型筛选"><option>全部</option><option>文书版本</option><option>交付清单</option></select>` : ''}
      <select class="lex-select" aria-label="状态筛选"><option>全部</option>${statusOptions.map(status => `<option value="${esc(status)}">${esc(labels[status] || status)}</option>`).join('')}</select></div>
      <div class="rows">${items.map(entry => {
        const selected = route.id === entry.id;
        const unavailable = entry.status === 'UNAVAILABLE' || (entry.kind === 'archive' && scene() === 'withdrawDoc' && entry.item.doc === `${route.caseId}-D01`);
        const iconName = entry.kind === 'delivery' || entry.kind === 'archive' ? 'package' : entry.kind === 'seal' ? 'stamp' : entry.kind === 'material' ? 'folder' : 'file';
        const meta = entry.kind === 'document' ? `V${entry.version} · ${entry.procedure || '未指定程序'}` : entry.kind === 'delivery' || entry.kind === 'archive' ? `${unavailable ? '原记录仍保留' : entry.item.recipient} · ${rawTitle(matter, entry.item.doc)}` : entry.kind === 'seal' ? `${entry.item.pages} 页 · ${entry.item.copies} 份` : `V${entry.version || 1} · 固定原件`;
        const target = entry.kind === 'document' ? (entry.status === 'DRAFT' ? 'drafts' : 'review') : entry.kind === 'seal' ? 'seal' : entry.kind === 'material' ? 'materials' : entry.kind === 'archive' ? 'archive' : 'delivery';
        return `<a class="row ${selected ? 'sel' : ''}" ${selected ? 'aria-current="page"' : ''} data-lex-row="${esc(entry.id)}" data-lex-target="${target}" href="${navHash(route.caseId, target, entry.id)}"><span class="fileIcon">${icon(iconName)}</span><span class="rowmain"><strong>${esc(unavailable ? '不可查看的清单' : entry.title)}</strong><small>${esc(meta)}</small></span>${badgeHtml(unavailable ? 'UNAVAILABLE' : entry.status)}</a>`;
      }).join('')}</div>${items.length ? '' : `<div class="empty"><span>${icon('file')}</span><p>${search || type !== '全部' || state.status !== '全部' ? '没有匹配的记录' : `本案暂无${work ? (type === '用印申请' ? '用印申请' : '文书或交付记录') : title.replace('列表', '')}`}</p><button class="btn" data-lex-clear>清除筛选</button></div>`}`;
    queue.dataset.lexSignature = signature;
    queue.dataset.lexEnhanced = '1';
    const searchInput = queue.querySelector('input[aria-label="搜索当前列表"]');
    searchInput?.addEventListener('input', event => { state.search = event.target.value; scheduleRender(); });
    if (searchWasFocused && searchInput) { searchInput.focus(); if (searchSelection != null) searchInput.setSelectionRange(searchSelection, searchSelection); }
    const selects = queue.querySelectorAll('select.lex-select');
    if (work && route.section !== 'seal' && selects.length === 2) {
      selects[0].value = state.type;
      selects[0].addEventListener('change', event => { state.type = event.target.value; scheduleRender(); });
      selects[1].value = state.status;
      selects[1].addEventListener('change', event => { state.status = event.target.value; scheduleRender(); });
    } else if (selects.length) {
      selects[0].value = state.status;
      selects[0].addEventListener('change', event => { state.status = event.target.value; scheduleRender(); });
    }
    bindListKeyboard(queue);
    queue.querySelectorAll('[data-lex-row]').forEach(link => link.addEventListener('click', event => {
      if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
      event.preventDefault();
      navigate(navHash(route.caseId, link.dataset.lexTarget, link.dataset.lexRow));
    }));
    queue.querySelector('[data-lex-clear]')?.addEventListener('click', () => { state.type = '全部'; state.status = '全部'; state.search = ''; scheduleRender(); });
  }
  function rawTitle(matter, id) {
    const file = [...matter.docs, ...matter.files].find(item => item.id === id);
    if (!file) return '固定原件不可查看';
    if (isWithdrawn(id)) return '固定原件已撤回';
    return `${file.title} · V${file.version}`;
  }
  function inspectorMarkup(route, db) {
    const matter = db?.[route.caseId];
    if (!matter) return '';
    const { doc, pack, seal, file } = findSelected(db, route);
    const section = route.section;
    const unavailablePack = pack && scene() === 'withdrawDoc' && pack.doc === `${route.caseId}-D01`;
    const sectionBlock = (title, body) => `<section><small>${title}</small>${body}</section>`;
    if (doc) {
      const family = matter.docs.filter(item => item.family === doc.family && !(scene() === 'withdrawDoc' && item.id === `${route.caseId}-D01`)).sort((a, b) => b.version - a.version);
      const linked = matter.packs.filter(item => item.doc === doc.id);
      return `<div class="inspectorHead">检查信息</div>
        ${sectionBlock('文书版本', `<strong>${esc(doc.title)}</strong><p>${esc(doc.id)}</p>`)}
        ${sectionBlock('当前状态', `${badgeHtml(doc.status)}<p>${family[0]?.id === doc.id ? '当前版本' : '历史版本 · 不可覆盖'}</p>`)}
        ${sectionBlock('主体与程序', `<strong>${esc(doc.subject)}</strong><p>${esc(caseInfo[route.caseId].procedures[doc.proc] || '未指定程序')}</p>`)}
        ${sectionBlock('模板来源', `<p>${esc(doc.origin || '未记录')}</p>`)}
        ${sectionBlock('保存卷宗', `<p>${esc(doc.folder || '未指定')}</p>`)}
        ${sectionBlock('引用材料', (doc.contextInputs || []).length ? doc.contextInputs.map(name => `<p>${esc(name)}</p>`).join('') : '<p>未记录引用材料</p>')}
        ${sectionBlock('版本族', family.map(item => `<a href="${navHash(route.caseId, item.status === 'DRAFT' ? 'drafts' : 'review', item.id)}" data-lex-navlink="1">V${item.version} · ${esc(labels[item.status] || item.status)}</a>`).join(''))}
        ${sectionBlock('关联交付', linked.length ? linked.map(item => `<a href="${navHash(route.caseId, 'delivery', item.id)}" data-lex-navlink="1">${esc(item.title)}</a>`).join('') : '<p>暂无交付清单</p>')}`;
    }
    if (pack) {
      const frozen = matter.docs.find(item => item.id === pack.doc) || matter.files.find(item => item.id === pack.doc);
      const later = frozen && matter.docs.some(item => item.family === frozen.family && item.version > frozen.version);
      return `<div class="inspectorHead">检查信息</div>
        ${sectionBlock('交付清单', `<strong>${esc(unavailablePack ? '不可查看的清单' : pack.title)}</strong><p>${esc(pack.id)}</p>${badgeHtml(unavailablePack ? 'UNAVAILABLE' : statusOfPack(pack))}`)}
        ${sectionBlock('接收对象', unavailablePack ? '<p>固定原件已撤回，清单内容不可查看。</p>' : `<strong>${esc(pack.recipient)}</strong><p>${esc(pack.contact)}</p>`)}
        ${sectionBlock('固定版本', unavailablePack ? '<p>原件当前不可查看</p>' : `<p>${esc(frozen?.title || '原件不可查看')} · V${frozen?.version || '—'}</p>${later ? '<p>已有后继版本；历史清单仍固定原版。</p>' : ''}`)}
        ${sectionBlock('交付历史', `<p>${pack.events.length} 条事件</p>${pack.parent ? `<a href="${navHash(route.caseId, 'delivery', pack.parent)}" data-lex-navlink="1">补发原清单 ${esc(pack.parent)}</a>` : ''}`)}
        ${sectionBlock('客户决定', `<strong>${esc(matter.decision)}</strong><p>收悉不会自动确认客户决定。</p>`)}
        ${sectionBlock('归档引用', `<a href="${navHash(route.caseId, 'archive', pack.id)}" data-lex-navlink="1">查看凭据引用</a>`)}`;
    }
    if (seal) {
      return `<div class="inspectorHead">检查信息</div>
        ${sectionBlock('用印申请', `<strong>${esc(seal.title)}</strong><p>${esc(seal.id)}</p>${badgeHtml(seal.status)}`)}
        ${sectionBlock('申请信息', `<p>林律师 · ${seal.pages} 页 · ${seal.copies} 份</p><p>${esc(seal.note)}</p>`)}
        ${sectionBlock('待盖章原件', `<p>${esc(rawTitle(matter, seal.draft))}</p>`)}
        ${sectionBlock('实盖结果', seal.stamp ? `<p>${esc(rawTitle(matter, seal.stamp))}</p>` : '<p>尚未登记实际盖章</p>')}`;
    }
    if (file) return `<div class="inspectorHead">检查信息</div>${sectionBlock('固定材料', `<strong>${esc(file.title)}</strong><p>V${file.version} · ${esc(file.id)}</p>`)}${sectionBlock('案件', `<strong>${esc(caseInfo[route.caseId].name)}</strong><p>${esc(caseInfo[route.caseId].code)}</p>`)}`;
    return `<div class="inspectorHead">检查信息</div>${sectionBlock('当前案件', `<strong>${esc(caseInfo[route.caseId].name)}</strong><p>${esc(caseInfo[route.caseId].code)}</p>`)}${sectionBlock('当前程序', caseInfo[route.caseId].procedures.map(item => `<p>${esc(item)}</p>`).join(''))}${sectionBlock('近期期限', caseInfo[route.caseId].due.map(item => `<p>${esc(item)}</p>`).join(''))}`;
  }
  function loadPaneWidths() {
    if (state.paneWidths) return state.paneWidths;
    try { state.paneWidths = JSON.parse(localStorage.getItem('lex-docs-pane-widths-v1')) || {}; }
    catch { state.paneWidths = {}; }
    state.paneWidths.list = Math.max(230, Math.min(400, Number(state.paneWidths.list) || 300));
    state.paneWidths.inspector = Math.max(200, Math.min(340, Number(state.paneWidths.inspector) || 245));
    return state.paneWidths;
  }
  function ensureResizeHandles(board) {
    const queue = board.querySelector('.queue');
    const detail = board.querySelector('.detail');
    const inspector = board.querySelector('.inspector');
    if (!queue || !detail || !inspector) return;
    const widths = loadPaneWidths();
    board.style.setProperty('--lex-list-width', `${widths.list}px`);
    board.style.setProperty('--lex-inspector-width', `${widths.inspector}px`);
    let listHandle = board.querySelector('.lex-resize-list');
    if (!listHandle) {
      listHandle = document.createElement('div');
      listHandle.className = 'lex-resize-handle lex-resize-list';
      listHandle.setAttribute('role', 'separator'); listHandle.setAttribute('aria-orientation', 'vertical');
      listHandle.setAttribute('aria-label', '调整列表宽度'); listHandle.tabIndex = 0;
      queue.insertAdjacentElement('afterend', listHandle);
      attachResize(listHandle, board, 'list');
    }
    let inspectorHandle = board.querySelector('.lex-resize-inspector');
    if (!inspectorHandle) {
      inspectorHandle = document.createElement('div');
      inspectorHandle.className = 'lex-resize-handle lex-resize-inspector';
      inspectorHandle.setAttribute('role', 'separator'); inspectorHandle.setAttribute('aria-orientation', 'vertical');
      inspectorHandle.setAttribute('aria-label', '调整检查栏宽度'); inspectorHandle.tabIndex = 0;
      detail.insertAdjacentElement('afterend', inspectorHandle);
      attachResize(inspectorHandle, board, 'inspector');
    }
  }
  function attachResize(handle, board, kind) {
    handle.addEventListener('pointerdown', event => {
      if (event.button !== 0) return;
      event.preventDefault();
      const widths = loadPaneWidths();
      const startX = event.clientX;
      const startWidth = widths[kind];
      handle.setPointerCapture?.(event.pointerId);
      const move = moveEvent => {
        const delta = moveEvent.clientX - startX;
        const next = kind === 'list' ? Math.max(230, Math.min(400, startWidth + delta)) : Math.max(200, Math.min(340, startWidth - delta));
        widths[kind] = Math.round(next);
        board.style.setProperty(kind === 'list' ? '--lex-list-width' : '--lex-inspector-width', `${widths[kind]}px`);
      };
      const up = () => {
        window.removeEventListener('pointermove', move);
        window.removeEventListener('pointerup', up);
        try { localStorage.setItem('lex-docs-pane-widths-v1', JSON.stringify(widths)); } catch {}
      };
      window.addEventListener('pointermove', move);
      window.addEventListener('pointerup', up, { once: true });
    });
    handle.addEventListener('keydown', event => {
      if (!['ArrowLeft', 'ArrowRight'].includes(event.key)) return;
      event.preventDefault();
      const widths = loadPaneWidths();
      const direction = event.key === 'ArrowRight' ? 12 : -12;
      widths[kind] = kind === 'list' ? Math.max(230, Math.min(400, widths.list + direction)) : Math.max(200, Math.min(340, widths.inspector - direction));
      board.style.setProperty(kind === 'list' ? '--lex-list-width' : '--lex-inspector-width', `${widths[kind]}px`);
      try { localStorage.setItem('lex-docs-pane-widths-v1', JSON.stringify(widths)); } catch {}
    });
  }
  function bindListKeyboard(queue) {
    if (queue.dataset.lexKeyboard === '1') return;
    queue.dataset.lexKeyboard = '1';
    queue.addEventListener('keydown', event => {
      if (event.target.matches('input,select,textarea,button')) return;
      const rows = [...queue.querySelectorAll('a[data-lex-row]')];
      if (!rows.length) return;
      const current = rows.indexOf(document.activeElement);
      let next = current;
      if (event.key === 'ArrowDown') next = Math.min(rows.length - 1, current < 0 ? 0 : current + 1);
      else if (event.key === 'ArrowUp') next = Math.max(0, current < 0 ? 0 : current - 1);
      else if (event.key === 'Home') next = 0;
      else if (event.key === 'End') next = rows.length - 1;
      else return;
      event.preventDefault(); rows[next].focus();
    });
  }
  function renderInspector(route, db) {
    const board = document.querySelector('.board');
    if (!board) return;
    let inspector = board.querySelector('.inspector');
    if (!inspector) {
      inspector = document.createElement('aside');
      inspector.className = 'inspector';
      board.appendChild(inspector);
    }
    const html = inspectorMarkup(route, db);
    if (inspector.dataset.lexHtml !== html) {
      inspector.innerHTML = html;
      inspector.dataset.lexHtml = html;
      inspector.querySelectorAll('a[data-lex-navlink]').forEach(link => link.addEventListener('click', event => {
        event.preventDefault();
        navigate(link.getAttribute('href'));
      }));
    }
  }
  function previewRouteKey(route) {
    return `${route.caseId}|${route.section}|${route.id}|${route.event || ''}`;
  }
  function clearFilePreview(restoreFocus = false) {
    const detail = document.querySelector('.board .detail');
    detail?.classList.remove('lex-preview-active');
    detail?.querySelector('#lex-file-preview')?.remove();
    const focus = state.previewFocus;
    state.previewDismissedRoute = restoreFocus ? state.previewRoute : null;
    state.previewFileId = null;
    state.previewRoute = null;
    state.previewFocus = null;
    if (restoreFocus && focus?.isConnected) focus.focus();
  }
  function openFilePreview(fileId, trigger, route = parseRoute()) {
    const db = readDb();
    const matter = db?.[route.caseId];
    const file = matter && [...matter.docs, ...matter.files].find(item => item.id === fileId);
    if (!file || isWithdrawn(fileId) || isProofWithdrawn(fileId)) return;
    state.previewFileId = fileId;
    state.previewRoute = previewRouteKey(route);
    state.previewDismissedRoute = null;
    state.previewFocus = trigger || document.activeElement;
    renderFilePreview(route, db);
  }
  function renderFilePreview(route, db) {
    if (!state.previewFileId || state.previewRoute !== previewRouteKey(route)) return;
    const board = document.querySelector('.board');
    const detail = board?.querySelector('.detail');
    const matter = db?.[route.caseId];
    if (!detail || !matter) return;
    const files = [...matter.docs, ...matter.files].filter(item => !isWithdrawn(item.id) && !isProofWithdrawn(item.id));
    const file = files.find(item => item.id === state.previewFileId);
    if (!file) {
      state.previewFileId = files[0]?.id || null;
      if (!state.previewFileId) { clearFilePreview(false); return; }
    }
    const selected = files.find(item => item.id === state.previewFileId);
    if (!selected) return;
    const index = files.findIndex(item => item.id === selected.id);
    const current = findSelected(db, route);
    const businessObject = current.doc ? `${current.doc.title} · V${current.doc.version}`
      : current.pack ? `交付清单 · ${current.pack.title}`
      : current.seal ? `用印申请 · ${current.seal.title}`
      : `${caseInfo[route.caseId].name} · ${caseInfo[route.caseId].code}`;
    let preview = detail.querySelector('#lex-file-preview');
    if (!preview) {
      preview = document.createElement('section');
      preview.id = 'lex-file-preview';
      preview.setAttribute('aria-label', '文件预览');
      detail.appendChild(preview);
    }
    detail.classList.add('lex-preview-active');
    const signature = `${route.caseId}|${route.section}|${route.id}|${selected.id}|${files.map(item => item.id).join(',')}`;
    if (preview.dataset.lexSignature === signature) return;
    preview.dataset.lexSignature = signature;
    const kind = (selected.title.split('.').pop() || '文件').toUpperCase();
    const options = files.map(item => `<option value="${esc(item.id)}" ${item.id === selected.id ? 'selected' : ''}>${esc(item.title)} · V${item.version || 1} · ${esc(item.id)}</option>`).join('');
    preview.innerHTML = `
      <header class="lx-preview-toolbar">
        <div class="lx-preview-file"><strong>${esc(selected.title)}</strong><span>${kind} · V${selected.version || 1} · ${esc(selected.id)}</span></div>
        <div class="lx-preview-controls">
          <button type="button" class="btn" data-preview-prev ${index <= 0 ? 'disabled' : ''}>上一份</button>
          <label class="sr-only" for="lx-preview-select">切换预览文件</label>
          <select id="lx-preview-select" aria-label="切换预览文件">${options}</select>
          <button type="button" class="btn" data-preview-next ${index >= files.length - 1 ? 'disabled' : ''}>下一份</button>
          <button type="button" class="btn" data-preview-close>返回详情</button>
        </div>
      </header>
      <div class="lx-preview-context"><span>当前业务对象</span><strong>${esc(businessObject)}</strong><span>·</span><span>切换预览不会更改当前复核或交付对象</span></div>
      <div class="lx-preview-canvas"><article class="lx-preview-paper">
        <div class="lx-paper-meta">${esc(caseInfo[route.caseId].code)}　/　${esc(caseInfo[route.caseId].name)}</div>
        <h2>${esc(selected.title.replace(/\.[^.]+$/, ''))}</h2>
        <p>${esc(selected.body || '此文件没有可显示的文本内容。')}</p>
      </article></div>
      <footer class="lx-preview-footer"><span>只读预览 · 合成文件内容</span><span>${index + 1} / ${files.length}</span></footer>`;
    preview.querySelector('#lx-preview-select')?.addEventListener('change', event => {
      state.previewFileId = event.target.value;
      renderFilePreview(route, db);
      preview.querySelector('#lx-preview-select')?.focus();
    });
    preview.querySelector('[data-preview-prev]')?.addEventListener('click', () => {
      if (index > 0) { state.previewFileId = files[index - 1].id; renderFilePreview(route, db); }
    });
    preview.querySelector('[data-preview-next]')?.addEventListener('click', () => {
      if (index < files.length - 1) { state.previewFileId = files[index + 1].id; renderFilePreview(route, db); }
    });
    preview.querySelector('[data-preview-close]')?.addEventListener('click', () => clearFilePreview(true));
  }
  function installFilePreviewDelegation() {
    if (window.__lexFilePreviewDelegation) return;
    window.__lexFilePreviewDelegation = true;
    document.addEventListener('click', event => {
      const link = event.target.closest('.detail a[href]');
      if (!link) return;
      const href = link.getAttribute('href') || '';
      const hash = href.includes('#') ? href.slice(href.indexOf('#') + 1) : href;
      const [path] = hash.split('?');
      const parts = path.split('/').filter(Boolean);
      const route = parseRoute();
      if (parts[0] !== 'matters' || parts[1] !== route.caseId || parts[2] !== 'materials' || !parts[3]) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      openFilePreview(parts[3], link, route);
    }, true);
  }
  function renderPlaceholder(route) {
    const content = document.querySelector('.content');
    const board = content?.querySelector('.board');
    if (!content || !board) return;
    content.querySelector('#lex-global-placeholder')?.remove();
    const label = pageTitles[route.section] || route.section;
    let placeholder = content.querySelector('.lex-section-placeholder');
    if (!placeholder) {
      placeholder = document.createElement('section');
      placeholder.className = 'lex-section-placeholder';
      board.insertAdjacentElement('afterend', placeholder);
    }
    if (board.style.display !== 'none') board.style.display = 'none';
    const signature = `${route.caseId}|${route.section}`;
    if (placeholder.dataset.lexSection === signature) return;
    placeholder.dataset.lexSection = signature;
    const realPath = route.section === 'archive' ? '/practice/archive?matter={matterId}' : `/matters/{matterId}/${route.section}`;
    placeholder.innerHTML = `<div class="lex-placeholder-icon">${icon('grid')}</div><h2>${esc(label)}</h2><p>本页保留 Chronicle 已核实的案内入口。当前仅演示统一侧栏、路由激活和案件上下文；该业务内容由对应工作组接入。</p><code>${esc(realPath)}</code><button class="btn primary" data-lex-back>返回文书台</button>`;
    placeholder.querySelector('[data-lex-back]')?.addEventListener('click', () => navigateSection('documents'));
  }
  function renderGlobalPlaceholder(route) {
    const content = document.querySelector('.content');
    const board = content?.querySelector('.board');
    if (!content || !board) return;
    content.querySelector('.lex-section-placeholder')?.remove();
    if (board.style.display !== 'none') board.style.display = 'none';
    const actions = content.querySelector('.lex-doc-actions');
    if (actions) actions.style.display = 'none';
    const path = route.globalPath || '/practice/today';
    const title = globalPageTitles[path] || '工作区';
    const header = content.querySelector(':scope > div:first-child h1');
    if (header) header.textContent = title;
    const description = content.querySelector(':scope > div:first-child p');
    if (description) description.textContent = `全局工作区 · 目标路由 ${path}`;
    let placeholder = content.querySelector('#lex-global-placeholder');
    if (!placeholder) {
      placeholder = document.createElement('section');
      placeholder.id = 'lex-global-placeholder';
      board.insertAdjacentElement('afterend', placeholder);
    }
    if (placeholder.dataset.lexPath === path) return;
    placeholder.dataset.lexPath = path;
    const cases = path === '/matters/list' ? `<div class="lx-case-choices"><button class="lx-case-choice" data-global-case="A">澄禾设备采购争议 · CH-2026-001</button><button class="lx-case-choice" data-global-case="B">青岚仓储交付争议 · QL-2026-002</button></div>` : '';
    placeholder.innerHTML = `<div class="lex-placeholder-icon">${icon('grid')}</div><h2>${esc(title)}</h2><p>这是统一侧栏的全局入口预览。当前不模拟该业务组的内容；正式页面沿用 Chronicle 已核实的路由与业务实现。</p><code>${esc(path)}</code>${cases}<p>当前案件分区已按规则置灰。可从左上工作区切换器选择案件并恢复该案上次打开的分区。</p>`;
    placeholder.querySelectorAll('[data-global-case]').forEach(button => button.addEventListener('click', () => switchWorkspace(button.dataset.globalCase)));
  }
  function openTemplateWizard(restoring = false) {
    if (scene() === 'readonly' || scene() === 'error') return;
    if (document.getElementById('lex-template-overlay')) return;
    const route = parseRoute();
    const db = readDb();
    const matter = db?.[route.caseId];
    if (!matter) return;
    state.template = restoring && state.templateSnapshot ? structuredClone(state.templateSnapshot) : { caseId: route.caseId, step: 1, template: matter.templates[0] || '', proc: '0', opposing: caseInfo[route.caseId].opposing, third: caseInfo[route.caseId].third, folder: caseInfo[route.caseId].folders[0], sources: [...caseInfo[route.caseId].sources.slice(0, 2)], title: '案件法律意见书', body: '请结合本案事实、证据和委托目标，填写本次文书要点。', prepared: false, checked: false };
    state.templateDirty = false;
    state.templateHistory = true;
    if (!restoring) history.pushState({ ...(history.state || {}), lexTemplate: true }, '', `${location.pathname}?template=1${location.hash}`);
    renderTemplateWizard();
  }
  function templateOverlayHtml(t, matter) {
    const steps = ['选择模板', '填写文书', '核对并生成'];
    const stepper = steps.map((step, index) => `<li class="${t.step === index + 1 ? 'current' : t.step > index + 1 ? 'done' : ''}" aria-current="${t.step === index + 1 ? 'step' : 'false'}"><span>${t.step > index + 1 ? '✓' : index + 1}</span><b>${step}</b></li>`).join('');
    const templates = matter.templates.map((name, index) => `<button type="button" class="lex-template-choice ${t.template === name ? 'selected' : ''}" data-template-choice="${esc(name)}" aria-pressed="${t.template === name}"><span class="lex-file-icon">${icon('file')}</span><span><strong>${esc(name)}</strong><small>${index === 0 ? '工作成果 · 当前案件可用' : '工作成果 · 可生成独立版本'}</small></span><span class="lex-template-choice-meta">${t.template === name ? '已选择' : '选择模板'}</span></button>`).join('');
    const selectedTemplate = t.template || '尚未选择';
    const selectedSources = t.sources.length ? t.sources.map(name => `<li>${icon('file')}<span>${esc(name)}</span><small>固定版本</small></li>`).join('') : '<li class="lx-no-source">尚未选择引用材料</li>';
    let body = '';
    if (t.step === 1) body = `
      <section class="lx-template-section">
        <div class="lx-section-heading"><div><h2>选择本案适用模板</h2></div><span class="lx-count">${matter.templates.length} 个模板</span></div>
        <div class="lex-template-list" role="group" aria-label="本案适用模板">${templates || '<div class="lx-empty-row">暂无适用模板，请先导入 DOCX 模板。</div>'}</div>
      </section>`;
    if (t.step === 2) body = `
      <section class="lx-template-section">
        <div class="lx-section-heading"><div><h2>文书基本信息</h2></div></div>
        <div class="lex-form-grid">
          <label class="wide">文书名称<input id="lex-template-title" maxlength="200" value="${esc(t.title)}"></label>
          <label>适用模板<input readonly value="${esc(selectedTemplate)}"></label>
          <label>保存卷宗<select id="lex-template-folder">${caseInfo[t.caseId].folders.map(name => `<option ${name === t.folder ? 'selected' : ''}>${esc(name)}</option>`).join('')}</select></label>
        </div>
      </section>
      <section class="lx-template-section">
        <div class="lx-section-heading"><div><h2>主体与程序</h2></div></div>
        <div class="lex-form-grid">
          <label>委托主体<input readonly value="${esc(caseInfo[t.caseId].client)}"><small>来自当前案件，不在此处修改</small></label>
          <label>对方当事人<select id="lex-template-opposing">${[caseInfo[t.caseId].opposing, '其他 / 待确认'].map(value => `<option ${value === t.opposing ? 'selected' : ''}>${esc(value)}</option>`).join('')}</select></label>
          <label>第三人（可选）<select id="lex-template-third"><option value="">未指定</option>${[caseInfo[t.caseId].third, '其他 / 待确认'].map(value => `<option ${value === t.third ? 'selected' : ''}>${esc(value)}</option>`).join('')}</select></label>
          <label>所属程序<select id="lex-template-proc">${caseInfo[t.caseId].procedures.map((name, index) => `<option value="${index}" ${String(index) === String(t.proc) ? 'selected' : ''}>${esc(name)}</option>`).join('')}</select></label>
        </div>
      </section>
      <section class="lx-template-section">
        <div class="lx-section-heading"><div><h2>引用材料</h2></div><span class="lx-count">${t.sources.length} 项已选</span></div>
        <div class="lex-source-picker"><div>${caseInfo[t.caseId].sources.map(name => `<label><input type="checkbox" data-lex-source="${esc(name)}" ${t.sources.includes(name) ? 'checked' : ''}><span>${esc(name)}</span><small>固定版本</small></label>`).join('')}</div></div>
      </section>
      <section class="lx-template-section lx-template-content-section">
        <div class="lx-section-heading"><div><h2>本次文书要点</h2></div></div>
        <label class="lx-body-field"><span>文书内容与起草要点</span><textarea id="lex-template-body" rows="8">${esc(t.body)}</textarea></label>
      </section>
      <p class="lx-form-note">主体、程序或引用材料发生变化后，先重新核对实际字段；核对状态失效时不能生成。</p>`;
    if (t.step === 3) body = `
      <section class="lx-template-section">
        <div class="lx-section-heading"><div><h2>核对内容</h2></div></div>
        <div class="lex-review-summary">
          <div class="lx-summary-group"><h3>文书信息</h3><dl><div><dt>文书名称</dt><dd>${esc(t.title)}</dd></div><div><dt>适用模板</dt><dd>${esc(t.template)}</dd></div><div><dt>保存卷宗</dt><dd>${esc(t.folder)}</dd></div></dl></div>
          <div class="lx-summary-group"><h3>主体与程序</h3><dl><div><dt>委托主体</dt><dd>${esc(caseInfo[t.caseId].client)}</dd></div><div><dt>对方当事人</dt><dd>${esc(t.opposing)}</dd></div><div><dt>第三人</dt><dd>${esc(t.third || '未指定')}</dd></div><div><dt>所属程序</dt><dd>${esc(caseInfo[t.caseId].procedures[Number(t.proc) || 0])}</dd></div></dl></div>
          <div class="lx-summary-group"><h3>引用材料</h3><ul>${selectedSources}</ul></div>
          <div class="lx-summary-group"><h3>本次文书要点</h3><p class="lx-summary-body">${esc(t.body)}</p></div>
        </div>
        ${t.prepared ? '<div class="lex-confirmed">本次主体、程序、引用材料和实际字段已重新核对。</div>' : '<button class="btn" data-template-recheck>重新核对实际字段</button>'}
        <label class="lex-check"><input type="checkbox" id="lex-template-checked" ${t.checked ? 'checked' : ''} ${t.prepared ? '' : 'disabled'}><span>我已核对本次文书的主体、程序、引用材料与字段</span></label>
      </section>`;
    const inspector = `
      <aside class="lex-template-inspector" aria-label="本次起草信息">
        <div class="lex-inspector-head">本次起草</div>
        <section><small>案件</small><strong>${esc(caseInfo[t.caseId].name)}</strong><p>${esc(caseInfo[t.caseId].code)}</p></section>
        <section><small>模板</small><strong>${esc(selectedTemplate)}</strong></section>
        <section><small>委托主体</small><strong>${esc(caseInfo[t.caseId].client)}</strong></section>
        <section><small>程序</small><strong>${esc(caseInfo[t.caseId].procedures[Number(t.proc) || 0])}</strong></section>
        <section><small>引用材料</small><strong>${t.sources.length} 项</strong></section>
        <section><small>保存卷宗</small><strong>${esc(t.folder || '未指定')}</strong></section>
      </aside>`;
    return `<div class="lex-template-overlay" id="lex-template-overlay"><div class="lex-template-page">
      <header><div><p class="lx-template-breadcrumb">${esc(caseInfo[t.caseId].code)} <span>/</span> ${esc(caseInfo[t.caseId].name)} <span>/</span> 文书台</p><h1>从模板起草</h1><span>案件文书 · 新建工作稿</span></div><button class="btn" data-template-close>返回文书台</button></header>
      <ol class="lex-stepper" aria-label="起草步骤">${stepper}</ol>
      <div class="lex-template-layout"><main class="lex-template-main">${body}</main>${inspector}</div>
      <footer><button class="btn" data-template-back>${t.step === 1 ? '取消起草' : '上一步'}</button><span>第 ${t.step} / 3 步</span>${t.step < 3 ? `<button class="btn primary" data-template-next ${t.step === 1 && !t.template || t.step === 2 && (!t.title.trim() || !t.body.trim()) ? 'disabled' : ''}>${t.step === 1 ? '使用此模板' : '继续核对'}</button>` : `<button class="btn primary" data-template-generate ${!t.prepared || !t.checked || !t.title.trim() || !t.body.trim() ? 'disabled' : ''}>生成工作稿</button>`}</footer>
    </div></div>`;
  }
  function renderTemplateWizard() {
    const current = state.template;
    if (!current) return;
    const matter = readDb()?.[current.caseId];
    if (!matter) return;
    document.getElementById('lex-template-overlay')?.remove();
    document.body.insertAdjacentHTML('beforeend', templateOverlayHtml(current, matter));
    const overlay = document.getElementById('lex-template-overlay');
    const breadcrumb = document.querySelector('.top .lx-breadcrumb b');
    if (breadcrumb) breadcrumb.textContent = '从模板起草';
    overlay.querySelectorAll('[data-template-choice]').forEach(button => button.addEventListener('click', () => {
      current.template = button.dataset.templateChoice; current.prepared = false; current.checked = false; state.templateDirty = true; renderTemplateWizard();
    }));
    overlay.querySelector('#lex-template-proc')?.addEventListener('change', event => { current.proc = event.target.value; current.prepared = false; current.checked = false; state.templateDirty = true; });
    overlay.querySelector('#lex-template-opposing')?.addEventListener('change', event => { current.opposing = event.target.value; current.prepared = false; current.checked = false; state.templateDirty = true; });
    overlay.querySelector('#lex-template-third')?.addEventListener('change', event => { current.third = event.target.value; current.prepared = false; current.checked = false; state.templateDirty = true; });
    overlay.querySelector('#lex-template-folder')?.addEventListener('change', event => { current.folder = event.target.value; state.templateDirty = true; });
    overlay.querySelectorAll('[data-lex-source]').forEach(input => input.addEventListener('change', () => { current.sources = [...overlay.querySelectorAll('[data-lex-source]:checked')].map(item => item.dataset.lexSource); current.prepared = false; current.checked = false; state.templateDirty = true; }));
    overlay.querySelector('#lex-template-title')?.addEventListener('input', event => { current.title = event.target.value; current.prepared = false; current.checked = false; state.templateDirty = true; updateWizardFooter(overlay, current); });
    overlay.querySelector('#lex-template-body')?.addEventListener('input', event => { current.body = event.target.value; current.prepared = false; current.checked = false; state.templateDirty = true; updateWizardFooter(overlay, current); });
    overlay.querySelector('#lex-template-checked')?.addEventListener('change', event => { current.checked = event.target.checked; state.templateDirty = true; updateWizardFooter(overlay, current); });
    overlay.querySelector('[data-template-recheck]')?.addEventListener('click', () => { current.prepared = true; current.checked = false; state.templateDirty = true; renderTemplateWizard(); });
    overlay.querySelector('[data-template-next]')?.addEventListener('click', () => { current.step += 1; renderTemplateWizard(); });
    overlay.querySelector('[data-template-back]')?.addEventListener('click', () => { if (current.step === 1) requestCloseTemplate(); else { current.step -= 1; renderTemplateWizard(); } });
    overlay.querySelector('[data-template-close]')?.addEventListener('click', requestCloseTemplate);
    overlay.querySelector('[data-template-generate]')?.addEventListener('click', generateTemplate);
  }
  function updateWizardFooter(overlay, current) {
    const next = overlay.querySelector('[data-template-next]');
    const generate = overlay.querySelector('[data-template-generate]');
    if (next) next.disabled = current.step === 1 ? !current.template : !current.title.trim() || !current.body.trim();
    if (generate) generate.disabled = !current.prepared || !current.checked || !current.title.trim() || !current.body.trim();
  }
  function requestCloseTemplate() {
    if (!state.template) return;
    if (state.templateDirty) {
      const overlay = document.getElementById('lex-template-overlay');
      if (overlay?.querySelector('.lex-discard')) return;
      overlay?.insertAdjacentHTML('beforeend', `<div class="lex-discard-backdrop"><div class="lex-discard"><strong>放弃未保存的起草内容？</strong><p>继续填写会保留当前模板和字段。</p><div><button class="btn" data-lex-keep>继续填写</button><button class="btn primary" data-lex-discard>放弃修改</button></div></div></div>`);
      overlay?.querySelector('[data-lex-keep]')?.addEventListener('click', () => overlay.querySelector('.lex-discard-backdrop')?.remove());
      overlay?.querySelector('[data-lex-discard]')?.addEventListener('click', () => { state.templateDirty = false; state.templateSnapshot = null; state.template = null; history.back(); });
      return;
    }
    history.back();
  }
  function closeTemplateOverlay(preserve = true) {
    if (preserve && state.template) state.templateSnapshot = structuredClone(state.template);
    if (!preserve) state.templateSnapshot = null;
    document.getElementById('lex-template-overlay')?.remove();
    state.template = null;
    state.templateDirty = false;
    ensureTopbar();
  }
  function generateTemplate() {
    const current = state.template;
    if (!current || !current.prepared || !current.checked || !current.title.trim() || !current.body.trim()) return;
    const db = readDb();
    const matter = db?.[current.caseId];
    if (!matter || scene() === 'readonly') return;
    const id = unique(current.caseId, 'D');
    const family = unique(current.caseId, 'F');
    const title = current.title.trim().replace(/\.docx$/i, '') + '.docx';
    matter.docs.unshift({ id, family, title, version: 1, status: 'DRAFT', proc: Number(current.proc), subject: caseInfo[current.caseId].client, origin: current.template, body: current.body.trim(), selection: { client: caseInfo[current.caseId].client, opposing: current.opposing, third: current.third, procedure: current.proc }, folder: current.folder, contextInputs: [...current.sources], issues: [], history: [{ label: '生成工作稿', note: '本案主体、程序与实际字段已核对。', at: new Date().toISOString() }], rev: 1 });
    window.__LEXORDER_PREVIEW_INITIAL__ = db;
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(db)); } catch {}
    state.templateDirty = false;
    state.templateSnapshot = null;
    closeTemplateOverlay(false);
    history.replaceState(history.state, '', `${location.pathname}${location.hash}`);
    location.hash = navHash(current.caseId, 'drafts', id);
    location.reload();
  }
  function handleTemplateHistory(event) {
    const overlay = document.getElementById('lex-template-overlay');
    if (!overlay) {
      if (new URLSearchParams(location.search).get('template') === '1') openTemplateWizard(true);
      return;
    }
    if (state.templateDirty) {
      history.pushState({ ...(history.state || {}), lexTemplate: true }, '', `${location.pathname}?template=1${location.hash}`);
      event.stopImmediatePropagation();
      requestCloseTemplate();
    } else {
      closeTemplateOverlay();
    }
  }
  function renderAll() {
    const app = document.querySelector('.app');
    if (!app) return;
    const route = parseRoute();
    const routeKey = previewRouteKey(route);
    if (state.previewRoute && state.previewRoute !== routeKey) clearFilePreview(false);
    if (route.section === 'materials' && route.id && !state.previewFileId && state.previewDismissedRoute !== routeKey) {
      state.previewFileId = route.id;
      state.previewRoute = routeKey;
    }
    ensureSidebar(); ensureTopbar(); captureLegacyTriggers(); removeOldNavigation(); setActiveNav(route);
    if (route.global) { renderGlobalPlaceholder(route); syncCaseMeta(); return; }
    const db = readDb();
    if (!db?.[route.caseId]) return;
    if (route.section === 'materials' && !route.id) {
      const matter = db[route.caseId];
      const file = matter.files[0] || matter.docs[0];
      if (file) { navigate(navHash(route.caseId, 'materials', file.id)); return; }
    }
    recordCaseRoute(route);
    syncCaseMeta();
    const content = document.querySelector('.content');
    const board = content?.querySelector('.board');
    const work = ['drafts', 'review', 'delivery', 'seal'].includes(route.section);
    const group = work ? 'documents' : route.section;
    if (state.lastGroup !== group) {
      state.type = '全部'; state.status = '全部'; state.search = '';
      state.lastGroup = group;
    }
    if (route.section === 'seal') state.type = '用印申请';
    else if (state.type === '用印申请') state.type = '全部';
    ensureActionBar(route);
    const pageHeader = content?.querySelector(':scope > div:first-child');
    const pageHeading = pageHeader?.querySelector('h1');
    const pageDescription = pageHeader?.querySelector('p');
    const fullTitle = route.section === 'seal' ? pageTitles.seal : (['drafts', 'review', 'delivery'].includes(route.section) ? pageTitles.delivery : (pageTitles[route.section] || '案内工作区'));
    if (pageHeading && pageHeading.textContent !== fullTitle) pageHeading.textContent = fullTitle;
    if (pageDescription?.dataset.lexOriginal) pageDescription.textContent = pageDescription.dataset.lexOriginal;
    if (scene() === 'error') {
      if (board && board.dataset.lexError !== '1') {
        board.innerHTML = `<div class="lex-error-state"><div>${icon('file')}</div><h2>无法读取本案记录</h2><p>当前预览模拟读取失败。恢复后可继续查看原有记录。</p><button class="btn primary" data-lex-retry>重新读取</button></div>`;
        board.dataset.lexError = '1';
        board.style.gridTemplateColumns = '1fr';
        board.querySelector('[data-lex-retry]')?.addEventListener('click', () => { localStorage.setItem(SCENE_KEY, 'normal'); location.reload(); });
      }
      return;
    }
    if (board?.dataset.lexError === '1') { board.dataset.lexError = ''; location.reload(); return; }
    const supported = work || ['materials', 'archive'].includes(route.section);
    if (!supported) { renderPlaceholder(route); return; }
    content?.querySelector('.lex-section-placeholder')?.remove();
    content?.querySelector('#lex-global-placeholder')?.remove();
    const actions = content?.querySelector('.lex-doc-actions');
    if (actions) actions.style.display = '';
    if (board && board.style.display !== '') board.style.display = '';
    renderQueue(route, db);
    renderInspector(route, db);
    renderFilePreview(route, db);
    ensureResizeHandles(board);
    const header = content?.querySelector(':scope > div:first-child h1');
    const heading = route.section === 'seal' ? pageTitles.seal : work ? '文书与交付' : (pageTitles[route.section] || '案件工作区');
    if (header && header.textContent !== heading) header.textContent = heading;
  }
    function scheduleRender() {
    if (state.timer) clearTimeout(state.timer);
    state.timer = setTimeout(renderAll, 35);
  }
  function startObserver() {
    const app = document.querySelector('.app');
    if (!app || state.observer) return;
    state.observer = new MutationObserver(() => scheduleRender());
    state.observer.observe(app, { childList: true, subtree: true });
  }
  window.addEventListener('popstate', handleTemplateHistory, true);
  window.addEventListener('hashchange', scheduleRender);
  window.addEventListener('beforeunload', event => { if (state.template && state.templateDirty) { event.preventDefault(); event.returnValue = ''; } });
  const boot = () => { installStyle(); installFilePreviewDelegation(); renderAll(); startObserver(); if (new URLSearchParams(location.search).get('template') === '1') openTemplateWizard(true); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => setTimeout(boot, 30), { once: true });
  else setTimeout(boot, 30);
  setTimeout(boot, 250);
})();

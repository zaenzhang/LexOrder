/*
 * LexOrder first interactive preview refresh.
 * Keeps the original React/Base UI workflow and routes, but replaces the
 * duplicate document tabs/sidebar with the shared Chronicle shell and a
 * three-pane list/detail/inspector workspace.
 */
(() => {
  if (window.__LEXORDER_SHELL_REFRESH__) return;
  window.__LEXORDER_SHELL_REFRESH__ = true;

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const svg = (body) => `<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${body}</svg>`;
  const icons = {
    home: '<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
    briefcase: '<rect x="3" y="7" width="18" height="14" rx="2"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M3 12h18M10 12v2h4v-2"/>',
    users: '<path d="M16 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M10 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8ZM20 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
    calendar: '<rect x="3" y="4" width="18" height="17" rx="2"/><path d="M16 2v4M8 2v4M3 9h18M8 13h3M8 17h3"/>',
    scale: '<path d="m12 3 8 4-8 4-8-4 8-4ZM5 9v8m14-8v8M3 17h4m10 0h4M12 11v10m-4 0h8"/>',
    wallet: '<rect x="3" y="5" width="18" height="15" rx="2"/><path d="M3 8h18M16 14h2"/>',
    grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
    folder: '<path d="M3 6a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
    file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6M8 13h8M8 17h8"/>',
    activity: '<path d="M3 12h4l3-8 4 16 3-8h4"/>',
    archive: '<rect x="3" y="4" width="18" height="5" rx="1"/><path d="M5 9v11h14V9M10 13h4"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="m19.4 15 .1.1 1.4 1.1-1.4 2.4-1.7-.7a8 8 0 0 1-1.8 1l-.3 1.8h-2.8l-.3-1.8a8 8 0 0 1-1.8-1l-1.7.7-1.4-2.4 1.4-1.1a8 8 0 0 1 0-2l-1.4-1.1 1.4-2.4 1.7.7a8 8 0 0 1 1.8-1l.3-1.8h2.8l.3 1.8a8 8 0 0 1 1.8 1l1.7-.7 1.4 2.4-1.4 1.1a8 8 0 0 1 0 2Z"/>',
    book: '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v17H6.5A2.5 2.5 0 0 0 4 22zM4 5.5v14A2.5 2.5 0 0 1 6.5 17H20"/>',
    chevron: '<path d="m9 18 6-6-6-6"/>',
    grip: '<path d="M9 5h.01M9 12h.01M9 19h.01M15 5h.01M15 12h.01M15 19h.01"/>'
  };
  const icon = (name) => svg(icons[name] || icons.file);
  const labelForTab = { drafts: '文书起草', review: '逐版复核', seal: '用印', delivery: '实际交付' };
  let observerQueued = false;
  let templateEnhanced = null;
  let lastInspectorSignature = '';
  let panePointer = null;

  function toast(message) {
    let node = $('#lx-shell-toast');
    if (!node) {
      node = document.createElement('div'); node.id = 'lx-shell-toast'; node.className = 'lx-shell-toast';
      document.body.append(node);
    }
    node.textContent = message; node.classList.add('show');
    clearTimeout(node._timer); node._timer = setTimeout(() => node.classList.remove('show'), 2600);
  }

  function hiddenOriginalButton(match) {
    return $$('.sidebar .navitem').find(button => button.textContent.includes(match));
  }

  function enhanceSidebar() {
    const sidebar = $('.sidebar');
    if (!sidebar) return;
    const brand = $('.brand', sidebar);
    const legacyContext = $('.context', sidebar);
    if (!sidebar.querySelector('.lx-global-nav')) {
      if (legacyContext) legacyContext.classList.add('lx-legacy-context');
      const oldGroup = $('.navgroup', sidebar); if (oldGroup) oldGroup.classList.add('lx-legacy-nav');
      $$('.navitem', sidebar).forEach(button => {
        if (!button.textContent.includes('验收场景')) button.classList.add('lx-legacy-nav');
        else button.classList.add('lx-scene-trigger');
      });
      const global = document.createElement('nav'); global.className = 'lx-global-nav'; global.setAttribute('aria-label', '全局导航');
      global.innerHTML = `<div class="lx-nav-caption">工作空间</div>
        <button type="button" class="lx-nav-item">${icon('home')}<span>今日工作台</span></button>
        <button type="button" class="lx-nav-item">${icon('briefcase')}<span>案件总览</span></button>
        <button type="button" class="lx-nav-item">${icon('users')}<span>客户与收案</span></button>
        <button type="button" class="lx-nav-item">${icon('calendar')}<span>日程</span></button>
        <button type="button" class="lx-nav-item active" aria-current="page">${icon('scale')}<span>办案事务</span></button>
        <button type="button" class="lx-nav-item">${icon('wallet')}<span>全局财务</span></button>`;
      $$('.lx-nav-item', global).forEach(button => {
        button.addEventListener('click', () => {
          if (!button.classList.contains('active')) toast('本轮只评审案件内文书与交付；其他全局入口由统一应用壳承接。');
        });
      });
      const current = document.createElement('nav'); current.className = 'lx-case-nav'; current.setAttribute('aria-label', '当前案件导航');
      current.innerHTML = `<div class="lx-case-heading"><span>当前案件</span><b>办理中</b></div>
        <div class="lx-case-identity"><strong class="lx-case-name"></strong><small class="lx-case-code"></small></div>
        <button type="button" class="lx-case-item">${icon('grid')}<span>概览</span></button>
        <button type="button" class="lx-case-item" data-go="procedures">${icon('list')}<span>程序与任务</span></button>
        <button type="button" class="lx-case-item" data-go="materials">${icon('folder')}<span>材料与卷宗</span></button>
        <button type="button" class="lx-case-item">${icon('book')}<span>事实与研究</span></button>
        <button type="button" class="lx-case-item active" data-go="documents" aria-current="page">${icon('file')}<span>文书与交付</span></button>
        <button type="button" class="lx-case-item">${icon('activity')}<span>办理记录</span></button>
        <button type="button" class="lx-case-item">${icon('wallet')}<span>案件财务</span></button>
        <button type="button" class="lx-case-item" data-go="archive">${icon('archive')}<span>结案与归档</span></button>
        <div class="lx-case-foot"><button type="button" class="lx-case-item">${icon('book')}<span>资料</span></button><button type="button" class="lx-case-item">${icon('settings')}<span>设置</span></button></div>`;
      brand?.after(global, current);
      $$('.lx-case-item', current).forEach(button => button.addEventListener('click', () => {
        const target = button.dataset.go;
        if (target === 'documents') return;
        if (target === 'materials') hiddenOriginalButton('材料原件')?.click();
        else if (target === 'archive') hiddenOriginalButton('归档引用')?.click();
        else if (target === 'procedures') hiddenOriginalButton('程序与期限')?.click();
        else toast('该分区由对应工作流负责；本轮保持原对象和路由，不在文书预览中模拟其功能。');
      }));
    }
    const select = $('.context select', sidebar);
    const name = $('.context strong', sidebar)?.textContent?.trim() || '当前案件';
    const code = $('.context > span', sidebar)?.textContent?.trim() || '';
    const caseName = $('.lx-case-name', sidebar), caseCode = $('.lx-case-code', sidebar);
    if (caseName && caseName.textContent !== name) caseName.textContent = name;
    if (caseCode && caseCode.textContent !== code) caseCode.textContent = code;
    const routeTab = currentTab();
    $$('.lx-case-item', sidebar).forEach(button => {
      const active = (routeTab === 'materials' && button.dataset.go === 'materials') || (routeTab === 'archive' && button.dataset.go === 'archive') || (['drafts','review','seal','delivery'].includes(routeTab) && button.dataset.go === 'documents');
      button.classList.toggle('active', active);
      if (active) button.setAttribute('aria-current','page'); else button.removeAttribute('aria-current');
    });
  }

  function enhanceTopbar() {
    const top = $('.top'); if (!top) return;
    const legacy = $('span:first-child', top);
    if (!top.querySelector('.lx-top-switcher')) {
      const shell = document.createElement('div'); shell.className = 'lx-top-switcher';
      shell.innerHTML = `<span class="lx-top-breadcrumb">${icon('briefcase')}<span>案件工作台</span>${icon('chevron')}<b>当前案件</b></span>
        <label class="lx-top-case"><span class="sr-only">切换案件</span><select aria-label="切换当前案件"><option value="A">澄禾设备采购争议</option><option value="B">青岚仓储交付争议</option></select><span class="lx-top-chevron">⌄</span></label>`;
      legacy?.classList.add('lx-legacy-top-context');
      const review = $('.reviewlink', top); top.insertBefore(shell, review || null);
      const newSelect = $('select', shell), oldSelect = $('.context select');
      newSelect.addEventListener('change', () => {
        if (!oldSelect) return;
        const setter = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value')?.set;
        setter ? setter.call(oldSelect, newSelect.value) : oldSelect.value = newSelect.value;
        oldSelect.dispatchEvent(new Event('change', { bubbles: true }));
      });
    }
    const oldSelect = $('.context select'), newSelect = $('.lx-top-case select');
    if (oldSelect && newSelect && newSelect.value !== oldSelect.value) newSelect.value = oldSelect.value;
  }

  function currentTab() {
    const path = (location.hash.split('?')[0] || '').split('/');
    const routeTab = path[3] || '';
    if (['drafts','review','seal','delivery','materials','archive'].includes(routeTab)) return routeTab;
    const active = $('.tabs a.on');
    const href = active?.getAttribute('href') || '';
    return Object.keys(labelForTab).find(key => href.includes('/' + key + '/')) || 'review';
  }

  function enhanceMain() {
    const content = $('.content'); if (!content) return;
    const tabs = $('.tabs', content); if (tabs) tabs.classList.add('lx-legacy-tabs');
    const routeTab = currentTab();
    const sectionTitle = routeTab === 'materials' ? '材料原件' : routeTab === 'archive' ? '归档引用' : '文书与交付';
    const pageTitle = $('h1', content); if (pageTitle && pageTitle.textContent !== sectionTitle) pageTitle.textContent = sectionTitle;
    const heading = $('.sectionhead h2', content); if (heading && heading.textContent !== sectionTitle) heading.textContent = sectionTitle;
    const eyebrow = $('.sectionhead small', content); if (eyebrow) { eyebrow.style.display = 'block'; eyebrow.textContent = routeTab === 'materials' ? '固定版本原件' : routeTab === 'archive' ? '交付历史引用' : '当前案件工作区'; }
    const queue = $('.queue', content);
    if (queue) {
      const title = $('.qhead strong', queue); if (title && title.textContent !== '工作对象') title.textContent = '工作对象';
      const qhead = $('.qhead', queue);
      if (qhead && !$('.lx-view-switch', qhead)) {
        const wrap = document.createElement('label'); wrap.className = 'lx-view-switch';
        wrap.innerHTML = `<span>工作视图</span><select aria-label="工作对象类型"><option value="drafts">文书起草</option><option value="review">逐版复核</option><option value="seal">用印</option><option value="delivery">实际交付</option></select>`;
        qhead.append(wrap);
        const select = $('select', wrap);
        select.addEventListener('change', () => {
          const anchor = $$('.tabs a').find(a => (a.getAttribute('href') || '').includes('/' + select.value + '/'));
          anchor?.click();
        });
      }
      const switchWrap = $('.lx-view-switch', qhead || queue);
      const switcher = $('select', switchWrap || queue);
      if (switchWrap) switchWrap.hidden = !Object.keys(labelForTab).includes(routeTab);
      if (switcher && Object.keys(labelForTab).includes(routeTab) && switcher.value !== routeTab) switcher.value = routeTab;
    }
    const sideImport = hiddenOriginalButton('工作区模板');
    const section = $('.sectionhead', content);
    if (section && sideImport && !$('.lx-import-template', section)) {
      const button = document.createElement('button'); button.type = 'button'; button.className = 'lx-import-template';
      button.innerHTML = `${icon('file')}<span>导入模板</span>`;
      button.addEventListener('click', () => sideImport.click());
      section.append(button);
    }
    const importButton = $('.lx-import-template', section || content); if (importButton) importButton.hidden = !['drafts','review','seal','delivery'].includes(routeTab);
    const board = $('.board', content);
    if (board) ensureThreePane(board);
  }

  function ensureThreePane(board) {
    if (!board.querySelector('.lx-inspector')) {
      const inspector = document.createElement('aside'); inspector.className = 'lx-inspector'; inspector.setAttribute('aria-label', '检查信息');
      board.append(inspector); lastInspectorSignature = '';
    }
    if (!board.querySelector('.lx-splitter-list')) {
      const splitter = document.createElement('div'); splitter.className = 'lx-splitter lx-splitter-list'; splitter.setAttribute('role', 'separator'); splitter.setAttribute('aria-orientation', 'vertical'); splitter.setAttribute('aria-label', '调整对象列表宽度'); splitter.tabIndex = 0;
      board.append(splitter); attachSplitter(splitter, board, 'list');
    }
    if (!board.querySelector('.lx-splitter-inspector')) {
      const splitter = document.createElement('div'); splitter.className = 'lx-splitter lx-splitter-inspector'; splitter.setAttribute('role', 'separator'); splitter.setAttribute('aria-orientation', 'vertical'); splitter.setAttribute('aria-label', '调整检查信息宽度'); splitter.tabIndex = 0;
      board.append(splitter); attachSplitter(splitter, board, 'inspector');
    }
    board.classList.add('lx-three-pane');
  }

  function attachSplitter(handle, board, kind) {
    if (handle.dataset.bound) return; handle.dataset.bound = '1';
    const variable = kind === 'list' ? '--lx-list-width' : '--lx-inspector-width';
    const initial = kind === 'list' ? 300 : 276;
    const read = () => parseFloat(getComputedStyle(board).getPropertyValue(variable)) || initial;
    const clamp = value => kind === 'list' ? Math.max(250, Math.min(420, value)) : Math.max(230, Math.min(370, value));
    handle.addEventListener('pointerdown', event => {
      event.preventDefault(); handle.setPointerCapture?.(event.pointerId);
      panePointer = { board, kind, variable, x: event.clientX, width: read() };
      handle.classList.add('dragging');
    });
    handle.addEventListener('pointermove', event => {
      if (!panePointer || panePointer.board !== board || panePointer.kind !== kind) return;
      const delta = event.clientX - panePointer.x;
      const next = clamp(panePointer.width + (kind === 'list' ? delta : -delta));
      board.style.setProperty(variable, `${next}px`);
      handle.setAttribute('aria-valuenow', String(Math.round(next)));
    });
    const end = () => { if (panePointer?.board === board && panePointer.kind === kind) { panePointer = null; handle.classList.remove('dragging'); } };
    handle.addEventListener('pointerup', end); handle.addEventListener('pointercancel', end);
    handle.addEventListener('keydown', event => {
      if (!['ArrowLeft','ArrowRight'].includes(event.key)) return;
      event.preventDefault(); const delta = event.key === 'ArrowRight' ? 18 : -18;
      const next = clamp(read() + (kind === 'list' ? delta : -delta)); board.style.setProperty(variable, `${next}px`); handle.setAttribute('aria-valuenow', String(Math.round(next)));
    });
  }

  function updateInspector() {
    const board = $('.board.lx-three-pane'); if (!board) return;
    const inspector = $('.lx-inspector', board), detail = $('.detail', board), selected = $('.row.sel', board);
    if (!inspector || !detail) return;
    const title = $('h2', detail)?.textContent?.trim() || selected?.querySelector('.rowmain strong')?.textContent?.trim() || '';
    const status = $('.eyeline .pill', detail)?.textContent?.trim() || selected?.querySelector('.pill')?.textContent?.trim() || '';
    const id = $('code', detail)?.textContent?.trim() || '';
    const facts = $$('.facts .kv', detail).map(kv => ({ label: $('span', kv)?.textContent?.trim() || '', value: $('div', kv)?.textContent?.trim() || '' })).filter(x => x.label && x.value);
    const tags = $('.tags', detail)?.textContent?.trim() || '';
    const latest = $('.timeline li', detail)?.textContent?.trim() || '';
    const original = $('.original a, .facts a, .paper a', detail);
    const access = $('.empty h3', detail)?.textContent?.trim() || '';
    const signature = JSON.stringify({ title, status, id, facts, tags, latest, access, tab: currentTab(), readonly: $('.userbox small')?.textContent || '' });
    if (signature === lastInspectorSignature) return;
    lastInspectorSignature = signature;
    inspector.replaceChildren();
    const header = document.createElement('div'); header.className = 'lx-inspector-header';
    header.innerHTML = `<div><span>检查信息</span><small>INSPECTOR</small></div><span class="lx-inspector-dot"></span>`;
    inspector.append(header);
    if (!title && !selected) {
      const empty = document.createElement('div'); empty.className = 'lx-inspector-empty';
      empty.innerHTML = `${icon('file')}<strong>选择一条记录</strong><p>在左侧选择文书、用印申请或交付清单，这里显示对象属性、固定版本和历史入口。</p>`;
      inspector.append(empty); return;
    }
    const object = document.createElement('section'); object.className = 'lx-inspector-section lx-inspector-object';
    const h = document.createElement('h3'); h.textContent = '当前对象'; object.append(h);
    const name = document.createElement('strong'); name.className = 'lx-inspector-title'; name.textContent = title || '记录不可查看'; object.append(name);
    if (id) { const code = document.createElement('code'); code.textContent = id; object.append(code); }
    if (status) { const pill = document.createElement('span'); pill.className = 'lx-inspector-status'; pill.textContent = status; object.append(pill); }
    if (tags) { const meta = document.createElement('small'); meta.className = 'lx-inspector-meta'; meta.textContent = tags; object.append(meta); }
    inspector.append(object);
    if (facts.length) {
      const attrs = document.createElement('section'); attrs.className = 'lx-inspector-section';
      const h2 = document.createElement('h3'); h2.textContent = '对象属性'; attrs.append(h2);
      facts.forEach(item => { const line = document.createElement('div'); line.className = 'lx-inspector-kv'; const k = document.createElement('span'); k.textContent = item.label; const v = document.createElement('strong'); v.textContent = item.value; line.append(k,v); attrs.append(line); });
      inspector.append(attrs);
    }
    if (original) {
      const links = document.createElement('section'); links.className = 'lx-inspector-section';
      const h3 = document.createElement('h3'); h3.textContent = '固定原件'; links.append(h3);
      const a = document.createElement('a'); a.className = 'lx-inspector-link'; a.href = original.getAttribute('href') || '#'; a.innerHTML = `${icon('file')}<span>${original.textContent.trim()}</span>`; a.addEventListener('click', event => { if (!event.ctrlKey && !event.metaKey) { event.preventDefault(); original.click(); } }); links.append(a); inspector.append(links);
    }
    if (latest) {
      const activity = document.createElement('section'); activity.className = 'lx-inspector-section';
      const h4 = document.createElement('h3'); h4.textContent = '最近记录'; const p = document.createElement('p'); p.textContent = latest; activity.append(h4,p); inspector.append(activity);
    }
    if (access) {
      const note = document.createElement('section'); note.className = 'lx-inspector-section lx-inspector-warning';
      note.textContent = access; inspector.append(note);
    }
    const foot = document.createElement('section'); foot.className = 'lx-inspector-section lx-inspector-foot';
    foot.innerHTML = `<span>当前工作区</span><strong>${$('.userbox small')?.textContent?.trim() || '个人工作空间'}</strong>`;
    inspector.append(foot);
  }

  function enhanceTemplateWorkspace() {
    const sheet = $('[data-slot="sheet-content"]');
    if (!sheet) { templateEnhanced = null; return; }
    const title = $('.sheetHead h2', sheet)?.textContent?.trim();
    if (title !== '从模板起草') { if (templateEnhanced && !document.body.contains(templateEnhanced)) templateEnhanced = null; return; }
    if (templateEnhanced === sheet && sheet.classList.contains('lx-template-workspace')) { updateTemplateWorkspace(sheet); return; }
    templateEnhanced = sheet; sheet.classList.add('lx-template-workspace');
    const overlay = $('[data-slot="sheet-overlay"]'); if (overlay) overlay.classList.add('lx-template-overlay');
    const head = $('.sheetHead', sheet);
    if (head && !$('.lx-template-breadcrumb', head)) {
      const crumb = document.createElement('div'); crumb.className = 'lx-template-breadcrumb'; crumb.textContent = '当前案件  /  文书与交付  /  从模板起草';
      const titleNode = $('h2', head); if (titleNode) titleNode.textContent = '从模板起草';
      const desc = document.createElement('p'); desc.className = 'lx-template-description'; desc.textContent = '选择适用模板，核对本案主体、程序与字段，生成新的文书工作稿。';
      const steps = document.createElement('div'); steps.className = 'lx-template-steps';
      steps.innerHTML = `<div data-step="1"><b>1</b><span>选择模板</span></div><i></i><div data-step="2"><b>2</b><span>补充本案字段</span></div><i></i><div data-step="3"><b>3</b><span>核对并生成</span></div>`;
      head.prepend(crumb); head.append(desc, steps);
    }
    const form = $('form.forms', sheet);
    if (form) {
      form.classList.add('lx-template-form');
      const templateField = $$('.field', form).find(field => field.textContent.includes('适用模板'));
      const select = templateField && $('select', templateField);
      if (select && !sheet.querySelector('.lx-template-picker')) {
        templateField.classList.add('lx-template-source-select');
        const picker = document.createElement('aside'); picker.className = 'lx-template-picker';
        picker.innerHTML = `<div class="lx-template-picker-head"><span>本案模板库</span><small>仅显示当前工作区可用模板</small></div><div class="lx-template-cards"></div><div class="lx-template-picker-foot">模板原件与模板版本独立管理；已生成文书不随模板更新而改写。</div>`;
        const cards = $('.lx-template-cards', picker);
        [...select.options].filter(option => option.value).forEach((option, index) => {
          const card = document.createElement('button'); card.type = 'button'; card.className = 'lx-template-card'; card.dataset.value = option.value;
          card.innerHTML = `${icon('file')}<span><strong></strong><small>${index === 0 ? '法律意见与案件分析' : '诉讼代理与程序文书'}</small></span><span class="lx-template-card-check">✓</span>`;
          $('strong', card).textContent = option.textContent;
          card.addEventListener('click', () => {
            const setter = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value')?.set;
            setter ? setter.call(select, option.value) : select.value = option.value;
            select.dispatchEvent(new Event('input', { bubbles: true })); select.dispatchEvent(new Event('change', { bubbles: true }));
            updateTemplateWorkspace(sheet);
          });
          cards.append(card);
        });
        sheet.append(picker);
      }
      if (!sheet.querySelector('.lx-template-inspector')) {
        const inspector = document.createElement('aside'); inspector.className = 'lx-template-inspector';
        inspector.innerHTML = `<div class="lx-template-inspector-head"><strong>生成前检查</strong><small>本次文书，不修改案件主数据</small></div><div class="lx-template-checks"></div><div class="lx-template-result"><b>生成结果</b><p>生成后进入本案材料，作为新的 V1 草稿；尚未送审、批准或交付。</p></div>`;
        sheet.append(inspector);
      }
    }
    updateTemplateWorkspace(sheet);
  }

  function updateTemplateWorkspace(sheet) {
    if (!sheet || !sheet.classList.contains('lx-template-workspace')) return;
    const form = $('form.forms', sheet); if (!form) return;
    const fields = $$('.field', form);
    const findField = label => fields.find(field => field.textContent.includes(label));
    const templateSelect = $('select', findField('适用模板') || form);
    const procSelect = $('select', findField('所属程序') || form);
    const titleInput = $('input', findField('文书名称') || form);
    const bodyInput = $('textarea', form);
    const checkbox = $('input[type="checkbox"]', form);
    const prepared = !!checkbox;
    const template = templateSelect?.selectedOptions?.[0]?.textContent?.trim() || '尚未选择';
    const proc = procSelect?.selectedOptions?.[0]?.textContent?.trim() || '尚未选择';
    const title = titleInput?.value?.trim() || '';
    const body = bodyInput?.value?.trim() || '';
    const checked = !!checkbox?.checked;
    const cards = $$('.lx-template-card', sheet);
    cards.forEach(card => card.classList.toggle('selected', !!templateSelect?.value && card.dataset.value === templateSelect.value));
    const step = !templateSelect?.value ? 1 : !prepared ? 2 : 3;
    $$('.lx-template-steps [data-step]', sheet).forEach(node => { const n = Number(node.dataset.step); node.classList.toggle('active', n === step); node.classList.toggle('complete', n < step || (n === 3 && checked)); });
    const checks = $('.lx-template-checks', sheet);
    if (checks) {
      checks.replaceChildren();
      const subjectValue = $('.kv div', form)?.textContent?.trim() || '本案委托主体';
      const rows = [
        ['适用模板', template, !!templateSelect?.value],
        ['委托主体', subjectValue, true],
        ['所属程序', proc, !!procSelect?.value],
        ['文书名称', title || '待填写', !!title],
        ['文书内容', body ? '已填写' : '待补充', !!body],
        ['人工核对', checked ? '已确认' : prepared ? '待确认' : '待核对字段', checked]
      ];
      rows.forEach(([label,value,ok]) => { const row = document.createElement('div'); row.className = 'lx-template-check-row'; row.innerHTML = `<span class="lx-template-check-icon">${ok ? '✓' : '·'}</span><span><small></small><strong></strong></span>`; $('small', row).textContent = label; $('strong', row).textContent = value; checks.append(row); });
    }
  }

  function runEnhancement() {
    enhanceSidebar(); enhanceTopbar(); enhanceMain(); enhanceTemplateWorkspace(); updateInspector();
  }
  function schedule() {
    if (observerQueued) return; observerQueued = true;
    requestAnimationFrame(() => { observerQueued = false; try { runEnhancement(); } catch (error) { console.warn('LexOrder preview enhancement', error); } });
  }
  const observer = new MutationObserver(schedule);
  observer.observe(document.body, { childList: true, subtree: true });
  document.addEventListener('input', event => { if (event.target.closest('.lx-template-workspace')) updateTemplateWorkspace(event.target.closest('.lx-template-workspace')); }, true);
  document.addEventListener('change', event => { if (event.target.closest('.lx-template-workspace')) updateTemplateWorkspace(event.target.closest('.lx-template-workspace')); }, true);
  window.addEventListener('hashchange', schedule);
  window.addEventListener('popstate', schedule);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', schedule, { once: true }); else schedule();
})();

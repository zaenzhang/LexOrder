import PizZip from 'pizzip'
import {caseInfo,latest,unique,history,stamp,rawFile} from './data'
const safe=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;')
export function fileBytes(f,c){
 if(f.title.endsWith('.docx')){
 const z=new PizZip();z.file('[Content_Types].xml','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>')
 z.file('_rels/.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>')
 z.file('word/document.xml','<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>'+[f.title,caseInfo[c].name,f.subject,f.body].map(x=>'<w:p><w:r><w:t>'+safe(x)+'</w:t></w:r></w:p>').join('')+'</w:body></w:document>')
 for(const e of Object.values(z.files))e.date=new Date(2026,0,1,12)
 return z.generate({type:'uint8array'})
 }
 const content='BT /F1 12 Tf 50 750 Td (SYNTHETIC CASE '+c+' - '+f.id+' - version '+f.version+') Tj ET'
 const objs=['<< /Type /Catalog /Pages 2 0 R >>','<< /Type /Pages /Kids [3 0 R] /Count 1 >>','<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>','<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>','<< /Length '+content.length+' >>\nstream\n'+content+'\nendstream']
 let pdf='%PDF-1.4\n',offsets=[];objs.forEach((o,i)=>{offsets.push(pdf.length);pdf+=(i+1)+' 0 obj\n'+o+'\nendobj\n'});const end=pdf.length;pdf+='xref\n0 6\n0000000000 65535 f \n'+offsets.map(x=>String(x).padStart(10,'0')+' 00000 n \n').join('')+'trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n'+end+'\n%%EOF';return new TextEncoder().encode(pdf)
}
export function saveBytes(name,bytes){const a=document.createElement('a');const url=URL.createObjectURL(new Blob([bytes]));a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),8000)}
export function makeZip(c,p,d){const z=new PizZip();z.file('材料/01_'+d.title,fileBytes(d,c));z.file('清单.json',JSON.stringify({matterId:c,deliveryId:p.id,documentId:d.id,version:d.version,recipient:p.recipient},null,2));return z.generate({type:'uint8array'})}
const requireThat=(ok,msg)=>{if(!ok)throw Error(msg)}
export function apply(db,ctx,act,f){
 const {caseId:c,id,scene,snapshot}=ctx,m=db[c],doc=m.docs.find(x=>x.id===id),p=m.packs.find(x=>x.id===id),s=m.seals.find(x=>x.id===id)
 requireThat(scene!=='readonly'&&scene!=='error','本案只读，无法写入。')
 const ev=(kind,extra={})=>({id:unique(c,'E'),kind,at:stamp(),recorded:stamp(),...extra})
 const note=String(f.note??'').trim(),text=(k,msg)=>{const v=String(f[k]??'').trim();requireThat(v,msg);return v}
 const allowed=d=>d&&d.id.startsWith(c+'-')&&!(scene==='withdrawDoc'&&d.id===c+'-D01')
 if(act==='importTemplate'){const name=text('title','填写模板名称。');requireThat(f.sample==='docx','选择合成 DOCX 模板。');requireThat(!m.templates.includes(name),'已有同名模板。');Object.values(db).forEach(data=>data.templates.push(name));return ['drafts','']}
 if(act==='template'){
 requireThat(f.checked&&f.prepared,'请先核对主体、程序和实际字段。')
 const title=text('title','填写文书名称。').replace(/\.docx$/,'')+'.docx'
 const d={id:unique(c,'D'),family:unique(c,'F'),title,version:1,status:'DRAFT',proc:Number(f.proc),subject:caseInfo[c].client,origin:f.template,body:text('body','填写文书要点。'),issues:[],history:[history('生成工作稿','本案字段已核对。')],rev:1};m.docs.unshift(d);return ['drafts',d.id]}
 if(['submit','return','approve','issue','respond','check','version'].includes(act)){
 requireThat(doc&&allowed(doc),'当前案件没有这个文书版本。');requireThat(snapshot===doc.rev&&scene!=='stale','核对时的版本或问题已变化。关闭后重新读取并逐项核对。')
 if(act==='submit'){requireThat(latest(m,doc)&&doc.status==='DRAFT','只能提交本人的当前草稿。');doc.status='PENDING_REVIEW';doc.history.push(history('送审'))}
 if(act==='return'||act==='approve'){requireThat(doc.status==='PENDING_REVIEW'&&(act==='return'||latest(m,doc)),'本版当前不能决定。');requireThat(f.checked&&(act==='return'||doc.issues.every(i=>f['seen'+i.id])),'请确认固定版本，并逐项核对列出的问题。');if(act==='return')text('note','填写退回原因。');doc.status=act==='return'?'DRAFT':'APPROVED';doc.history.push(history(act==='return'?'退回草稿':'批准本版',note))}
 if(act==='issue'){requireThat(doc.status==='PENDING_REVIEW'&&latest(m,doc),'当前不能提出问题。');doc.issues.push({id:unique(c,'I'),title:text('title','填写问题。'),location:text('location','填写位置。'),basis:text('basis','填写依据。'),status:'OPEN',events:['提出问题']})}
 if(act==='respond'||act==='check'){const i=doc.issues.find(i=>i.id===f.issue);requireThat(i&&i.status===(act==='respond'?'OPEN':'WAITING_CHECK'),'问题状态已变化。');text('note','填写处理说明。');i.status=act==='respond'?'WAITING_CHECK':f.resolve==='退回再处理'?'OPEN':'RESOLVED';i.events.push((act==='respond'?'作者回应 · '+f.disposition:'复核 · '+f.resolve)+' · '+note)}
 if(act==='version'){requireThat(latest(m,doc)&&doc.status!=='PENDING_REVIEW','在审或历史稿不能登记新版。');const d={...doc,id:unique(c,'D'),status:'DRAFT',parent:doc.id,version:doc.version+1,body:text('body','填写模拟回传正文。'),issues:[],history:[history('Editor 登记后继版本','基线 '+doc.id)],rev:1};m.docs.unshift(d);return ['review',d.id]}
 doc.rev++;return ['review',doc.id]}
 if(act==='freeze'||act==='sup'){
 const d=m.docs.find(x=>x.id===f.doc);requireThat(allowed(d)&&d.status==='APPROVED','选择本案可读、已批准的固定版本。')
 if(act==='sup')requireThat(p,'原清单不属于本案。')
 const item={id:unique(c,'P'),title:text('title','填写交付目的。'),doc:d.id,recipient:text('recipient','填写接收人。'),contact:text('contact','填写联系方式或地点。'),scope:text('scope','填写披露范围。'),parent:act==='sup'?p.id:null,events:[]};m.packs.unshift(item);return ['delivery',item.id]}
 if(p&&['export','SENT','RECEIVED','SEND_CORRECTION','REPLIED','CONTENT_CONFIRMED'].includes(act)){
 const d=rawFile(m,p.doc);requireThat(allowed(d),'固定原件已撤回，无法导出或登记。')
 if(act==='export'){saveBytes(p.title+'.zip',makeZip(c,p,d));p.events.push(ev('EXPORTED'));return ['delivery',p.id]}
 const sent=p.events.find(e=>e.kind==='SENT')
 requireThat(act==='SENT'?!sent:!!sent,act==='SENT'?'已登记送出，请追加更正。':'请先登记实际送出。')
 const at=new Date((f.at||'')+':00+08:00').getTime();requireThat(Number.isFinite(at)&&at<=Date.now()+60000,'发生时间须为有效的上海时间且不能晚于现在。')
 if(act==='SEND_CORRECTION')requireThat(p.events.some(e=>e.id===f.corrects&&['SENT','SEND_CORRECTION'].includes(e.kind)),'选择本清单要更正的原登记。')
 if(act==='SENT'||act==='SEND_CORRECTION')text('channel','填写实际渠道。');text('note','填写实际发生情况。')
 if(f.proof)requireThat(m.files.some(q=>q.id===f.proof)&&!(scene==='withdrawProof'&&f.proof===c+'-M01'),'凭据不属于本案或已撤回。')
 p.events.push(ev(act,{at:stamp(at),channel:f.channel,proof:f.proof||null,note,corrects:f.corrects||null}));return ['delivery',p.id]}
 if(act==='sealNew'){requireThat(f.draft===c+'-M02'&&+f.pages>0&&+f.copies>0,'请选择待盖章 PDF，并填写页数和份数。');const n={id:unique(c,'S'),title:text('title','填写文书名称。'),status:'PENDING',draft:f.draft,stamp:null,note:text('note','填写用印事由。'),pages:f.pages,copies:f.copies,history:[history('提交用印申请',f.purpose)]};m.seals.unshift(n);return ['seal',n.id]}
 if(s&&['sealOk','sealNo','sealCancel','stamp'].includes(act)){requireThat(s.status===(act==='stamp'?'APPROVED':'PENDING'),'申请状态已经变化。');if(act==='sealNo')text('note','填写驳回原因。');if(act==='stamp'){requireThat(f.stamped===c+'-M03','请选实际章后 PDF。');s.stamp=f.stamped} s.status={sealOk:'APPROVED',sealNo:'REJECTED',sealCancel:'CANCELLED',stamp:'STAMPED'}[act];s.history.push(history({sealOk:'本人确认申请',sealNo:'驳回申请',sealCancel:'申请人撤销',stamp:'登记实际盖章'}[act],note));return ['seal',s.id]}
 throw Error('未找到可办理的同案对象。')
}

from pathlib import Path
from playwright.sync_api import sync_playwright, expect

root=Path('/mnt/data/lexorder_review_source')
html=(root/'index.html').read_text(encoding='utf-8')
results=[]
def ok(name): results.append('PASS '+name); print('PASS '+name)
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox','--disable-dev-shm-usage'])
    page=browser.new_page(viewport={'width':1536,'height':1000}, device_scale_factor=1)
    page.set_content(html, wait_until='load')
    page.evaluate("location.hash='#/matters/A/review/A-D02'")
    page.wait_for_selector('.board .detail')
    page.wait_for_timeout(500)
    page.screenshot(path=str(root/'rendered/workbench-polish-v2.png'), full_page=False)
    # File preview opens from the fixed source link without changing the selected review route.
    original_hash=page.evaluate('location.hash')
    fixed=page.locator('.detail a[href*="/materials/"]').first
    expect(fixed).to_be_visible()
    fixed.click()
    expect(page.locator('#lex-file-preview')).to_be_visible()
    expect(page.locator('#lx-preview-select')).to_be_visible()
    assert page.evaluate('location.hash')==original_hash
    current_text=page.locator('.lx-preview-paper p').inner_text()
    select=page.locator('#lx-preview-select')
    opts=select.locator('option')
    assert opts.count() >= 5
    # Duplicate filenames remain distinguishable by version and ID.
    option_texts=opts.all_text_contents()
    assert any('法律意见书.docx · V1 · A-D01' in x for x in option_texts)
    assert any('法律意见书.docx · V2 · A-D02' in x for x in option_texts)
    select.select_option('A-D01')
    expect(page.locator('.lx-preview-paper p')).to_contain_text('第一版')
    assert page.evaluate('location.hash')==original_hash
    page.locator('[data-preview-prev]').click()
    expect(page.locator('.lx-preview-paper p')).to_contain_text('待补充事实与理由')
    page.locator('[data-preview-next]').click()
    expect(page.locator('.lx-preview-paper p')).to_contain_text('第一版')
    assert page.evaluate('location.hash')==original_hash
    page.screenshot(path=str(root/'rendered/file-preview-switchable.png'), full_page=False)
    page.locator('[data-preview-close]').click()
    expect(page.locator('#lex-file-preview')).to_have_count(0)
    expect(page.locator('.detail h2')).to_contain_text('法律意见书')
    ok('file preview opens in the content pane; V1/V2 with identical filenames can be switched; current review route and object remain unchanged')

    # Materials route opens a switchable viewer; close remains closed until navigation changes.
    page.locator('#lex-matter-nav [data-nav-key="materials"]').click()
    expect(page.locator('#lex-file-preview')).to_be_visible()
    page.locator('[data-preview-close]').click()
    page.wait_for_timeout(250)
    expect(page.locator('#lex-file-preview')).to_have_count(0)
    ok('materials page opens the selected file preview and explicit close does not auto-reopen')

    # Short actions are centered dialogs, not right-edge drawers.
    page.locator('#lex-matter-nav [data-parent="documents"]').click()
    page.locator('#lex-matter-nav [data-nav-child="delivery"]').click()
    page.wait_for_timeout(300)
    send=page.get_by_role('button',name='从模板起草',exact=True).first
    expect(send).to_be_visible()
    # Navigate to an editable document detail then open a short action.
    page.evaluate("location.hash='#/matters/A/review/A-D02'")
    page.wait_for_timeout(300)
    action=page.get_by_role('button',name='更多操作',exact=True)
    if action.count():
        action.click()
        page.wait_for_timeout(100)
        # pick a menu action (e.g. simulate successor version) if available
        candidate=page.get_by_role('button',name='提出问题',exact=True)
        if candidate.count(): candidate.click()
        dialog=page.locator('[data-slot="sheet-content"]')
        expect(dialog).to_be_visible()
        box=dialog.bounding_box(); viewport=page.viewport_size
        assert abs((box['x']+box['width']/2)-viewport['width']/2)<8, box
        assert abs((box['y']+box['height']/2)-viewport['height']/2)<30, box
        expect(page.locator('[data-slot="sheet-overlay"]')).to_be_visible()
        page.screenshot(path=str(root/'rendered/centered-dialog.png'), full_page=False)
        page.keyboard.press('Escape')
        page.wait_for_timeout(150)
        ok('short operation uses a centered modal dialog rather than a right-side drawer')
    else:
        # Open the common schedule action which uses the same Base UI Sheet primitive.
        page.locator('.lex-doc-actions').get_by_role('button',name='程序与期限').click()
        dialog=page.locator('[data-slot="sheet-content"]')
        expect(dialog).to_be_visible()
        box=dialog.bounding_box(); viewport=page.viewport_size
        assert abs((box['x']+box['width']/2)-viewport['width']/2)<8, box
        assert abs((box['y']+box['height']/2)-viewport['height']/2)<30, box
        page.keyboard.press('Escape')
        ok('short operation uses a centered modal dialog rather than a right-side drawer')

    # Full-page template wizard remains a page; typography and summary are simplified.
    page.evaluate("location.hash='#/matters/A/review/A-D02'")
    page.wait_for_timeout(300)
    page.get_by_role('button',name='从模板起草',exact=True).first.click()
    expect(page.locator('#lex-template-overlay')).to_be_visible()
    expect(page.locator('[data-slot="sheet-content"]')).to_have_count(0)
    page.screenshot(path=str(root/'rendered/template-step1-polish-v2.png'), full_page=False)
    expect(page.locator('.lex-template-inspector')).to_contain_text('保存卷宗')
    expect(page.locator('.lex-template-inspector')).not_to_contain_text('生成前检查')
    page.locator('[data-template-next]').click()
    expect(page.locator('#lex-template-title')).to_be_visible()
    # Confirm body and controls are readable sizes.
    font=page.locator('#lex-template-title').evaluate('(el)=>getComputedStyle(el).fontSize')
    assert float(font.replace('px',''))>=15, font
    page.screenshot(path=str(root/'rendered/template-step2-readable.png'), full_page=False)
    page.locator('[data-template-next]').click()
    expect(page.locator('[data-template-recheck]')).to_be_visible()
    page.locator('[data-template-recheck]').click()
    page.locator('#lex-template-checked').check()
    expect(page.locator('[data-template-generate]')).to_be_enabled()
    page.screenshot(path=str(root/'rendered/template-step3-polish-v2.png'), full_page=False)
    page.locator('[data-template-close]').click()
    page.wait_for_timeout(150)
    ok('template wizard remains a full page; inspector is factual and concise; form input typography is readable')

    # Ensure no mutation-observer render loop or console errors.
    page.wait_for_timeout(500)
    assert page.locator('body').count()==1
    ok('page remains stable after repeated preview and dialog interactions')
    browser.close()
Path('/mnt/data/lexorder_review_source/verification-v2.txt').write_text('\n'.join(results)+'\n',encoding='utf-8')

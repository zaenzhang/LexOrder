from pathlib import Path
p=Path('/mnt/data/lexorder_review_source/source/src/postprocess.js')
s=p.read_text()

# Add state for independent, switchable file preview.
s=s.replace(
"  const state = { type: '全部', status: '全部', search: '', lastGroup: '', template: null, templateSnapshot: null, templateDirty: false, templateHistory: false, observer: null, timer: null, paneWidths: null, lastActiveCaseParent: null, lastActiveGlobalParent: null };",
"  const state = { type: '全部', status: '全部', search: '', lastGroup: '', template: null, templateSnapshot: null, templateDirty: false, templateHistory: false, observer: null, timer: null, paneWidths: null, lastActiveCaseParent: null, lastActiveGlobalParent: null, previewFileId: null, previewRoute: null, previewFocus: null };"
)

# Add restrained, readable UI overrides after all existing style layers.
marker="  function installStyle() {"
css=r'''  const usabilityPolishCss = `
    /* Short actions are dialogs, not edge drawers. */
    [data-slot="sheet-overlay"]{z-index:100;background:color-mix(in oklch,var(--foreground) 28%,transparent);backdrop-filter:blur(1px)}
    [data-slot="sheet-content"]{position:fixed!important;inset:auto!important;top:50%!important;left:50%!important;right:auto!important;bottom:auto!important;width:min(560px,calc(100vw - 40px))!important;max-height:min(82dvh,760px)!important;overflow:auto!important;padding:24px!important;border:1px solid var(--border)!important;border-radius:10px!important;background:var(--card)!important;box-shadow:var(--surface-shadow-raised)!important;transform:translate(-50%,-50%)!important;transition:opacity .16s ease,transform .16s ease!important}
    [data-slot="sheet-content"][data-starting-style],[data-slot="sheet-content"][data-ending-style]{transform:translate(-50%,-47%)!important;opacity:0}
    .sheetHead{padding-right:36px;margin-bottom:18px}
    .sheetHead>span{font-size:13px!important}
    .sheetHead h2{font-size:21px!important}
    .sheetHead p{font-size:14px!important}
    .forms{gap:15px}
    .forms .field,.forms label{font-size:14px}
    .forms input,.forms textarea,.forms select,[data-slot="native-select"]{font-size:15px}
    .forms .btn{font-size:14px;min-height:36px}
    .forms p,.forms .muted{font-size:14px;line-height:1.6}
    .formFoot{padding-top:15px}

    /* Keep the Chronicle density, but stop rendering important metadata as footnotes. */
    .queue .qhead strong{font-size:16px}
    .queue .qhead span{font-size:13px}
    .queue .tools .search input,.queue .tools .lex-select{font-size:14px}
    .queue .row{padding:13px 12px}
    .queue .rowmain strong{font-size:15px;line-height:1.4}
    .queue .rowmain small{font-size:13px;line-height:1.45}
    .lex-pill{font-size:12px;padding:3px 8px}
    .inspectorHead,.lex-inspector-head{font-size:15px}
    .inspector section,.lex-template-inspector section{font-size:14px}
    .inspector section small,.lex-template-inspector section small{font-size:13px}
    .inspector section p,.lex-template-inspector section p{font-size:14px;line-height:1.55}
    .inspector section a{font-size:14px;line-height:1.5}
    .inspector section strong,.lex-template-inspector section strong{font-size:14px}
    .lx-nav-caption{font-size:12px}
    .lx-nav-item{font-size:14px;min-height:34px}
    .lx-subnav .lx-nav-item{font-size:13px;min-height:31px}
    .lx-switcher-copy strong{font-size:14px}
    .lx-switcher-copy small{font-size:12px}
    .lx-menu-caption{font-size:12px}
    .lx-switch-option{font-size:14px}
    #lex-case-meta strong{font-size:14px}
    #lex-case-meta small{font-size:12px}
    #lex-user-area .userbox strong{font-size:14px}
    #lex-user-area .userbox small{font-size:12px}

    /* Template work page: ordinary form typography, plain summary, no decorative AI-style cards. */
    .lex-template-page{gap:20px}
    .lex-template-page>header p{font-size:14px}
    .lex-template-page>header h1{font-size:28px}
    .lex-template-page>header span{font-size:14px}
    .lex-stepper li{font-size:14px;gap:10px}
    .lex-stepper li span{font-size:13px}
    .lex-template-main h2{font-size:20px}
    .lex-template-main p,.lex-template-main .fieldHint,.lx-form-note{font-size:14px;line-height:1.55}
    .lex-template-choice{padding:13px 14px;border-radius:6px;box-shadow:none!important}
    .lex-template-choice strong{font-size:15px}
    .lex-template-choice small{font-size:13px}
    .lex-template-choice-meta{font-size:13px}
    .lex-form-grid label,.lx-body-field{font-size:14px}
    .lex-form-grid label small{font-size:13px}
    .lex-form-grid input,.lex-form-grid select,.lex-form-grid textarea,.lx-body-field textarea{font-size:15px;min-height:40px}
    .lex-form-grid textarea,.lx-body-field textarea{min-height:180px}
    .lex-source-picker label{font-size:14px}
    .lex-source-picker label small{font-size:13px}
    .lex-template-inspector .lex-inspector-head{font-size:15px}
    .lex-template-inspector section small{font-size:13px}
    .lex-template-inspector section strong{font-size:14px}
    .lex-template-inspector section p,.lex-template-inspector dt{font-size:13px}
    .lex-template-inspector dd{font-size:14px;line-height:1.5}
    .lx-summary-group h3{font-size:15px}
    .lx-summary-group dl div,.lx-summary-group li,.lx-summary-body{font-size:14px;line-height:1.6}
    .lx-summary-group li small{font-size:13px}
    .lex-confirmed,.lex-check{font-size:14px}
    .lex-template-page>footer span{font-size:13px}
    .lex-template-page>footer .btn{font-size:14px;min-height:38px}
    .lex-discard{border-radius:8px}
    .lex-discard strong{font-size:16px}
    .lex-discard p{font-size:14px}

    /* Read-only file preview lives in the document pane and can switch files without changing the review target. */
    .detail.lex-preview-active{padding:0!important;overflow:hidden;display:flex;flex-direction:column}
    .detail.lex-preview-active>:not(#lex-file-preview){display:none!important}
    #lex-file-preview{display:flex;flex:1;min-height:480px;flex-direction:column;background:var(--background)}
    .lx-preview-toolbar{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 18px;border-bottom:1px solid var(--border);background:var(--card)}
    .lx-preview-file{display:grid;gap:3px;min-width:0}
    .lx-preview-file strong{font-size:16px;overflow-wrap:anywhere}
    .lx-preview-file span{font-size:13px;color:var(--muted-foreground)}
    .lx-preview-controls{display:flex;align-items:center;gap:7px;flex-wrap:wrap}
    .lx-preview-controls select{height:36px;min-width:220px;max-width:320px;border:1px solid var(--input);border-radius:6px;background:var(--card);padding:5px 30px 5px 9px;font-size:14px}
    .lx-preview-controls .btn{min-height:36px;font-size:14px}
    .lx-preview-context{display:flex;align-items:center;gap:8px;padding:10px 18px;border-bottom:1px solid var(--border);font-size:13px;color:var(--muted-foreground)}
    .lx-preview-context strong{font-size:14px;color:var(--foreground);font-weight:550}
    .lx-preview-canvas{flex:1;min-height:0;overflow:auto;padding:24px;background:var(--muted)}
    .lx-preview-paper{width:min(760px,100%);min-height:560px;margin:0 auto;padding:58px 64px;background:#fff;color:#20242b;border:1px solid #d9dde5;box-shadow:0 1px 3px #17243a0c}
    .lx-preview-paper .lx-paper-meta{font-size:13px;color:#687386;border-bottom:1px solid #e3e6ec;padding-bottom:13px;margin-bottom:30px}
    .lx-preview-paper h2{font-family:inherit;font-size:23px;font-weight:650;line-height:1.4;text-align:center;margin:0 0 32px;color:#20242b}
    .lx-preview-paper p{font-size:16px;line-height:2;white-space:pre-wrap;color:#303642;margin:0 0 16px}
    .lx-preview-footer{display:flex;justify-content:space-between;gap:12px;padding:10px 18px;border-top:1px solid var(--border);background:var(--card);font-size:13px;color:var(--muted-foreground)}
    .lx-preview-empty{width:min(760px,100%);margin:0 auto;padding:40px;background:var(--card);border:1px solid var(--border);font-size:15px}
    @media(max-width:1050px){.lx-preview-toolbar{align-items:flex-start;flex-direction:column}.lx-preview-controls{width:100%}.lx-preview-controls select{flex:1;min-width:0;max-width:none}}
    @media(max-width:780px){[data-slot="sheet-content"]{width:calc(100vw - 24px)!important;max-height:calc(100dvh - 24px)!important;padding:18px!important}.lx-preview-canvas{padding:12px}.lx-preview-paper{padding:32px 24px;min-height:420px}.lx-preview-paper h2{font-size:20px}.lx-preview-paper p{font-size:15px}}
    @media(prefers-reduced-motion:reduce){[data-slot="sheet-content"]{transition:none!important}}
  `;
'''
if marker not in s: raise SystemExit('installStyle marker missing')
s=s.replace(marker,css+marker,1)
s=s.replace('style.textContent = styleText + unifiedSidebarCss + productRefinementCss + emporiumFormCss;','style.textContent = styleText + unifiedSidebarCss + productRefinementCss + emporiumFormCss + usabilityPolishCss;',1)

# Replace overly verbose inspector copy with a factual, compact summary.
old='''    const inspector = `
      <aside class="lex-template-inspector" aria-label="本次起草检查信息">
        <div class="lex-inspector-head">本次起草</div>
        <section><small>当前案件</small><strong>${esc(caseInfo[t.caseId].name)}</strong><p>${esc(caseInfo[t.caseId].code)}</p></section>
        <section><small>适用模板</small><strong>${esc(selectedTemplate)}</strong><p>工作成果 · DOCX 模板</p></section>
        <section><small>本次范围</small><dl><div><dt>委托主体</dt><dd>${esc(caseInfo[t.caseId].client)}</dd></div><div><dt>程序</dt><dd>${esc(caseInfo[t.caseId].procedures[Number(t.proc) || 0])}</dd></div><div><dt>引用材料</dt><dd>${t.sources.length} 项</dd></div></dl></section>
        <section><small>生成前检查</small><p>主体、程序和引用材料变化后，需要重新核对实际字段。</p><p>未完成核对或文书名称、要点为空时，不允许生成。</p></section>
        <section><small>生成后</small><p>新工作稿进入文书台。Editor 负责打开正文、保存和登记后继版本。</p></section>
      </aside>`;'''
new='''    const inspector = `
      <aside class="lex-template-inspector" aria-label="本次起草信息">
        <div class="lex-inspector-head">本次起草</div>
        <section><small>案件</small><strong>${esc(caseInfo[t.caseId].name)}</strong><p>${esc(caseInfo[t.caseId].code)}</p></section>
        <section><small>模板</small><strong>${esc(selectedTemplate)}</strong></section>
        <section><small>委托主体</small><strong>${esc(caseInfo[t.caseId].client)}</strong></section>
        <section><small>程序</small><strong>${esc(caseInfo[t.caseId].procedures[Number(t.proc) || 0])}</strong></section>
        <section><small>引用材料</small><strong>${t.sources.length} 项</strong></section>
        <section><small>保存卷宗</small><strong>${esc(t.folder || '未指定')}</strong></section>
      </aside>`;'''
if old not in s: raise SystemExit('template inspector block missing')
s=s.replace(old,new,1)

# Remove explanatory filler from the wizard; retain the business-critical field names and instructions.
s=s.replace('<p>模板来自当前个人工作区。选择后再核对本案主体、程序和文书字段。</p>','',1)
s=s.replace('<p>先确定本次生成的文书名称和归档位置。</p>','',1)
s=s.replace('<p>从当前案件登记信息中选择本次文书对应的主体和程序。</p>','',1)
s=s.replace('<p>只选择本次起草需要引用的同案固定材料版本。</p>','',1)
s=s.replace('<p>填写本次起草的事实和论证重点。正文排版与后续编辑交由 Editor 处理。</p>','',1)
s=s.replace('<div class="lx-section-heading"><div><h2>生成前核对</h2><p>确认以下内容与本次拟生成的文书一致。</p></div></div>','<div class="lx-section-heading"><div><h2>核对内容</h2></div></div>',1)
s=s.replace('<span>选择模板，核对本案信息后生成新的工作稿版本。</span>','<span>案件文书 · 新建工作稿</span>',1)

# Add switchable file preview functions after renderInspector.
anchor='''  function renderPlaceholder(route) {'''
preview=r'''  function previewRouteKey(route) {
    return `${route.caseId}|${route.section}|${route.id}|${route.event || ''}`;
  }
  function clearFilePreview(restoreFocus = false) {
    const detail = document.querySelector('.board .detail');
    detail?.classList.remove('lex-preview-active');
    detail?.querySelector('#lex-file-preview')?.remove();
    const focus = state.previewFocus;
    state.previewFileId = null;
    state.previewRoute = null;
    state.previewFocus = null;
    if (restoreFocus && focus?.isConnected) focus.focus();
  }
  function openFilePreview(fileId, trigger, route = parseRoute()) {
    const db = readDb();
    const matter = db?.[route.caseId];
    const file = matter && [...matter.docs, ...matter.files].find(item => item.id === fileId);
    if (!file || isWithdrawn(fileId) || isProofWithdrawn(fileId)) return;
    state.previewFileId = fileId;
    state.previewRoute = previewRouteKey(route);
    state.previewFocus = trigger || document.activeElement;
    renderFilePreview(route, db);
  }
  function renderFilePreview(route, db) {
    if (!state.previewFileId || state.previewRoute !== previewRouteKey(route)) return;
    const board = document.querySelector('.board');
    const detail = board?.querySelector('.detail');
    const matter = db?.[route.caseId];
    if (!detail || !matter) return;
    const files = [...matter.docs, ...matter.files].filter(item => !isWithdrawn(item.id) && !isProofWithdrawn(item.id));
    const file = files.find(item => item.id === state.previewFileId);
    if (!file) {
      state.previewFileId = files[0]?.id || null;
      if (!state.previewFileId) { clearFilePreview(false); return; }
    }
    const selected = files.find(item => item.id === state.previewFileId);
    if (!selected) return;
    const index = files.findIndex(item => item.id === selected.id);
    const current = findSelected(db, route);
    const businessObject = current.doc ? `${current.doc.title} · V${current.doc.version}`
      : current.pack ? `交付清单 · ${current.pack.title}`
      : current.seal ? `用印申请 · ${current.seal.title}`
      : `${caseInfo[route.caseId].name} · ${caseInfo[route.caseId].code}`;
    let preview = detail.querySelector('#lex-file-preview');
    if (!preview) {
      preview = document.createElement('section');
      preview.id = 'lex-file-preview';
      preview.setAttribute('aria-label', '文件预览');
      detail.appendChild(preview);
    }
    detail.classList.add('lex-preview-active');
    const kind = (selected.title.split('.').pop() || '文件').toUpperCase();
    const options = files.map(item => `<option value="${esc(item.id)}" ${item.id === selected.id ? 'selected' : ''}>${esc(item.title)} · V${item.version || 1} · ${esc(item.id)}</option>`).join('');
    preview.innerHTML = `
      <header class="lx-preview-toolbar">
        <div class="lx-preview-file"><strong>${esc(selected.title)}</strong><span>${kind} · V${selected.version || 1} · ${esc(selected.id)}</span></div>
        <div class="lx-preview-controls">
          <button type="button" class="btn" data-preview-prev ${index <= 0 ? 'disabled' : ''}>上一份</button>
          <label class="sr-only" for="lx-preview-select">切换预览文件</label>
          <select id="lx-preview-select" aria-label="切换预览文件">${options}</select>
          <button type="button" class="btn" data-preview-next ${index >= files.length - 1 ? 'disabled' : ''}>下一份</button>
          <button type="button" class="btn" data-preview-close>返回详情</button>
        </div>
      </header>
      <div class="lx-preview-context"><span>当前业务对象</span><strong>${esc(businessObject)}</strong><span>·</span><span>切换预览不会更改当前复核或交付对象</span></div>
      <div class="lx-preview-canvas"><article class="lx-preview-paper">
        <div class="lx-paper-meta">${esc(caseInfo[route.caseId].code)}　/　${esc(caseInfo[route.caseId].name)}</div>
        <h2>${esc(selected.title.replace(/\.[^.]+$/, ''))}</h2>
        <p>${esc(selected.body || '此文件没有可显示的文本内容。')}</p>
      </article></div>
      <footer class="lx-preview-footer"><span>只读预览 · 合成文件内容</span><span>${index + 1} / ${files.length}</span></footer>`;
    preview.querySelector('#lx-preview-select')?.addEventListener('change', event => {
      state.previewFileId = event.target.value;
      renderFilePreview(route, db);
      preview.querySelector('#lx-preview-select')?.focus();
    });
    preview.querySelector('[data-preview-prev]')?.addEventListener('click', () => {
      if (index > 0) { state.previewFileId = files[index - 1].id; renderFilePreview(route, db); }
    });
    preview.querySelector('[data-preview-next]')?.addEventListener('click', () => {
      if (index < files.length - 1) { state.previewFileId = files[index + 1].id; renderFilePreview(route, db); }
    });
    preview.querySelector('[data-preview-close]')?.addEventListener('click', () => clearFilePreview(true));
  }
  function installFilePreviewDelegation() {
    if (window.__lexFilePreviewDelegation) return;
    window.__lexFilePreviewDelegation = true;
    document.addEventListener('click', event => {
      const link = event.target.closest('.detail a[href]');
      if (!link) return;
      const href = link.getAttribute('href') || '';
      const hash = href.includes('#') ? href.slice(href.indexOf('#') + 1) : href;
      const [path] = hash.split('?');
      const parts = path.split('/').filter(Boolean);
      const route = parseRoute();
      if (parts[0] !== 'matters' || parts[1] !== route.caseId || parts[2] !== 'materials' || !parts[3]) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      openFilePreview(parts[3], link, route);
    }, true);
  }
'''
if anchor not in s: raise SystemExit('renderPlaceholder anchor missing')
s=s.replace(anchor,preview+anchor,1)

# Ensure preview state follows the current route and auto-opens from the Materials page.
old='''    const route = parseRoute();
    ensureSidebar(); ensureTopbar(); captureLegacyTriggers(); removeOldNavigation(); setActiveNav(route);'''
new='''    const route = parseRoute();
    const routeKey = previewRouteKey(route);
    if (state.previewRoute && state.previewRoute !== routeKey) clearFilePreview(false);
    if (route.section === 'materials' && route.id && !state.previewFileId) {
      state.previewFileId = route.id;
      state.previewRoute = routeKey;
    }
    ensureSidebar(); ensureTopbar(); captureLegacyTriggers(); removeOldNavigation(); setActiveNav(route);'''
if old not in s: raise SystemExit('renderAll route anchor missing')
s=s.replace(old,new,1)
s=s.replace('''    renderQueue(route, db);
    renderInspector(route, db);
    ensureResizeHandles(board);''','''    renderQueue(route, db);
    renderInspector(route, db);
    renderFilePreview(route, db);
    ensureResizeHandles(board);''',1)

# Install delegated file preview listener before the app starts observing changes.
s=s.replace("  const boot = () => { installStyle(); renderAll(); startObserver(); if (new URLSearchParams(location.search).get('template') === '1') openTemplateWizard(true); };",
            "  const boot = () => { installStyle(); installFilePreviewDelegation(); renderAll(); startObserver(); if (new URLSearchParams(location.search).get('template') === '1') openTemplateWizard(true); };")

p.write_text(s)
print('Updated',p,'bytes',p.stat().st_size)

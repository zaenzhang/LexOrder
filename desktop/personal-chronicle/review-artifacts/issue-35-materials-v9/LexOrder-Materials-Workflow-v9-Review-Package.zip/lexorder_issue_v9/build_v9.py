from pathlib import Path
import re
src=Path('/mnt/data/LexOrder-Materials-Workflow-v8.html').read_text()
s=src
# Bump version and remove design-time microcopy from the visible product surface.
s=s.replace('材料分类与接件流程 v8','材料分类与接件流程 v9')
s=s.replace('隔离交互预览 v7 · 合成数据','预览数据')
s=s.replace('法院送达（已核实入卷）','法院送达')
s=s.replace('这是一个材料接件操作流，不是选完文件就立即上传：多选后逐件核对类别、来源、程序、环节和来源方；每个文件独立提交、查回执和重试。','先选文件，再逐件核对，确认后提交。每份材料单独记录结果，失败可重试。')
s=s.replace('多选或拖入，先进入暂存队列','拖入或选择文件')
s=s.replace('类别、来源、程序与环节','核对类别和归属')
s=s.replace('逐件结果、核对和重试','查看结果和重试')
s=s.replace('仅加入暂存队列，不会自动上传。后续逐件核对并提交；支持 PDF、DOCX、TXT、图片 · 20 MB','支持 PDF、DOCX、TXT、JPG、PNG；单件不超过 20 MB')
s=s.replace('共同默认值（可选） <span>仅应用到尚未提交的材料　⌄</span>','批量默认值 <span>应用到待提交文件　⌄</span>')
s=s.replace('使用合成样例','填入示例文件')
s=s.replace('法院短信、电子送达原文及其附件先进入独立「事务 → 法院来件」工作流，完成去重、案件匹配和建议确认后，附件才转为正式材料。这里的“法院送达”只是已核实入卷文件的来源字段，不等于法院来件处理队列。','法院短信、电子送达原文和待处理附件，先在「事务 → 法院来件」完成去重、案件匹配与附件处置。入卷材料可标记来源为「法院送达」；这个字段本身不代表来件流程已完成。')
s=s.replace('当前案件固定，不会跨案上传','当前案件')
s=s.replace('设计来源与真实字段','材料分类依据')
s=s.replace('分类、来源和上传交互以当前 LexOrder 服务为依据；样式参考公开组件范式。','材料分类与接件流程依据现有 LexOrder 业务字段。')
s=s.replace('DocumentSourceOrigin：当事人提供、法院送达、AI 识别、自行调取、团队产出；法院送达是已核实文件的来源标记','DocumentSourceOrigin：当事人提供、法院送达、AI 识别、自行调取、团队产出；这是来源标记，不代表法院来件工作流已处理')
s=s.replace('派生操作视图：草稿 + 团队产出 + 支持的 Office/TXT 格式 + 当前版本；不是 DocumentCategory','派生操作视图：草稿 + 团队产出 + 支持的 Office/TXT 格式 + 当前版本；不是材料类别')
s=s.replace('AI 识别生成','AI 识别')
# Reduce product-facing debug affordance; keep source references in the accompanying review note.
s=s.replace('.sources-btn{', '.sources-btn{display:none!important;')
# More legible Chronicle-like typography. Avoid changing the existing layout and component behavior.
css='''\n/* v9 visual refinement: fewer micro-labels, clearer reading hierarchy. */
body{font-size:14px;line-height:1.52}
.topbar{height:60px;padding-inline:26px}
.brand-wordmark{font-size:18px}
.brand-sub{font-size:13px}
.demo-label{font-size:12px}
.sidebar{width:232px;padding:16px 11px 12px}
.sidebar-heading{font-size:11.5px;letter-spacing:.55px;padding:11px 11px 8px;color:#7f8b9b}
.side-link{height:39px;font-size:13px;gap:12px}
.side-case-text strong{font-size:12.5px}
.side-case-text small{font-size:11px}
.side-count{font-size:11px}
.bottom-note{display:none}
.breadcrumbs{font-size:12px;margin-bottom:15px}
.title-area h1{font-size:25px;letter-spacing:-.45px}
.page-count{font-size:12px}
.case-hint{font-size:13px}
.btn{font-size:13px;height:36px}
.btn-sm{font-size:12px;height:31px}
.tab-nav{font-size:13px}
.list-title{font-size:14px}
.small-count{font-size:11px}
.search-control input{font-size:13px;height:34px}
.search-control kbd{font-size:11px}
.filter-tabs button{font-size:12px;height:28px}
.axis-filter{font-size:12px;gap:7px}
.axis-filter select{font-size:12px;height:32px;max-width:148px}
.sort-button{font-size:12px}
.volume-bar select{font-size:12px;max-width:132px}
.datatable th{font-size:11.5px;height:39px}
.datatable .table-sort{font-size:11px}
.doc-name{font-size:13.5px;letter-spacing:0}
.doc-sub{font-size:11.5px;margin-top:5px}
.file-meta .vol{font-size:11px;max-width:100px}
.version-pill{font-size:11px;line-height:18px}
.status-line{font-size:11px;margin-top:4px}
.empty-list strong{font-size:14px}
.empty-list span{font-size:12px}
.list-footer{font-size:11px;height:42px}
.viewer-file-name{font-size:13.5px;max-width:310px}
.viewer-context{font-size:11.5px}
.read-only-tag{font-size:11px}
.paper-topline{font-size:11.5px}
.paper-title{font-size:25px}
.paper-subtitle{font-size:13px}
.paper-intro,.paper-paragraph{font-size:14px;line-height:2.05}
.paper-table{font-size:13px}
.paper-table th{font-size:12px}
.paper-note{font-size:12px;line-height:1.7}
.paper-editor-tag{font-size:12px}
.paper-page,.paper-watermark{font-size:11px}
.viewer-footer{font-size:11px;height:44px}
.page-indicator{font-size:11.5px}
.workbench-bottom{font-size:11px}
.sources-btn{display:none!important}
.floating-menu .menu-caption{font-size:11.5px}
.menu-option{font-size:12.5px;height:37px}
.menu-option .key{font-size:11px}
.sheet-header{padding:22px 24px 17px}
.sheet-kicker{font-size:11px;letter-spacing:.6px}
.sheet-title{font-size:20px}
.sheet-sub{font-size:12.5px}
.kv-grid{font-size:12px;row-gap:14px}
.sheet-footer{padding:14px 24px}
.nav-row,.workspace-switcher{font-size:13px;min-height:35px}
.nav-sub .nav-row{font-size:12.5px;min-height:31px}
.group-label{font-size:12px;padding:9px 8px 5px}
.switch-label strong{font-size:12.5px}
.switch-label small{font-size:11px}
.header-crumb{font-size:12px}
.header-right .demo-label{font-size:11.5px}
.nav-preview-kicker{font-size:12px}
.nav-preview-title{font-size:26px}
.nav-preview-subtitle{font-size:13px}
.nav-preview-card h2{font-size:15px}
.nav-preview-card p{font-size:13px}
.nav-preview-case strong{font-size:13px}
.nav-preview-case small{font-size:11px}
.nav-preview-note{font-size:12px}
/* Dialogs are for short, task-focused actions; only the persistent case directory keeps a Sheet. */
.dialog-heading{font-size:20px}
.dialog-desc{font-size:13px;line-height:1.5;color:#6d7a8d}
.dialog-hint{font-size:12px}
.workflow-dialog{width:min(1020px,96vw);max-height:91vh}
.workflow-dialog .dialog-header{padding:20px 24px 15px}
.workflow-dialog .dialog-body{padding:18px 24px;}
.workflow-dialog .dialog-footer{padding:13px 24px}
.workflow-intro{font-size:13px;margin-bottom:14px}
.intake-steps{gap:10px;margin-bottom:16px}
.intake-steps li{padding:10px 12px;gap:10px}
.intake-steps li>span{width:25px;height:25px;font-size:12px}
.intake-steps strong{font-size:12.5px}
.intake-steps small{font-size:11.5px}
.workflow-layout{gap:16px;min-height:320px}
.workflow-list-head{font-size:13px;padding:11px 13px}
.workflow-list-items{max-height:50vh}
.workflow-file-item{padding:10px 9px;gap:10px}
.workflow-file-name{font-size:12.5px}
.workflow-file-meta{font-size:11px}
.workflow-state{font-size:10.5px;padding:3px 7px}
.workflow-detail{padding:16px}
.workflow-detail-head{padding-bottom:13px;margin-bottom:14px}
.workflow-detail-head strong{font-size:14px}
.workflow-detail-head small{font-size:11.5px}
.workflow-fields{gap:12px 14px}
.workflow-field{gap:6px}
.workflow-field label{font-size:12px}
.workflow-field input,.workflow-field select{height:36px;font-size:13px;padding-inline:10px}
.workflow-field .hint{font-size:11px;line-height:1.5}
.workflow-context{margin-top:14px;padding-top:13px}
.workflow-context-title{font-size:12px}
.workflow-context label{font-size:11.5px}
.workflow-message{font-size:12px;line-height:1.55;padding:9px 11px}
.workflow-actions{gap:8px;margin-top:14px;padding-top:12px}
.workflow-actions .btn{height:32px;font-size:12px}
.workflow-defaults{margin-bottom:14px}
.workflow-defaults summary{font-size:13px;padding:11px 13px}
.workflow-defaults-content{padding:0 13px 13px}
.workflow-warning{font-size:12px;line-height:1.6;padding:10px 12px;margin-top:13px}
.workflow-summary{font-size:12px;line-height:1.5}
.workflow-empty{font-size:13px;min-height:250px}
.dialog-detail-panel h3{font-size:12.5px}
.nested-confirm .dialog{width:min(460px,95%)}
@media(max-width:780px){.sidebar{width:200px}.workflow-dialog{width:96vw}.workflow-layout{grid-template-columns:1fr}.workflow-list-items{max-height:190px}.workflow-fields{grid-template-columns:1fr}.dialog-detail-grid{grid-template-columns:1fr}.filterline-axes{flex-wrap:wrap}.axis-filter select{max-width:140px}}
'''
s=s.replace('</style>',css+'</style>',1)
# Give the court-source filter and court-inbox process separate, accurate wording.
s=s.replace('法院送达（已核实入卷）','法院送达')
# Remove verbose internal explanatory footer line while keeping the concise status and safety information.
s=s.replace('文件名直接阅读 / 编辑；类别、来源、状态与卷宗分别记录；法院来件先走独立处理流程。','')
# Avoid visible technical field names in the preview's source panel; these remain documented in the issue package.
# The panel itself is kept for audit, but no longer promoted in the primary workspace.
out=Path('/mnt/data/LexOrder-Materials-Workflow-v9.html')
out.write_text(s)
print(out, out.stat().st_size)
